package br.com.rodripsi.memoria

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

data class AiMemory(
    val text: String,
    val subject: String,
    val people: List<String>,
    val type: String,
    val remindAt: Long?
)

data class AiEvent(val title: String, val startMs: Long, val durationMin: Int, val reminderMin: Int?)

data class AiResult(val say: String, val ask: Boolean, val memory: AiMemory?, val event: AiEvent?)

class AiException(message: String) : Exception(message)

object Ai {
    private val PT = Locale("pt", "BR")
    private val TYPES = setOf("tarefa", "ideia", "fato", "promessa", "aguardando")

    fun systemPrompt(
        now: ZonedDateTime,
        subjects: List<String>,
        people: List<String>,
        relevant: List<Memory>
    ): String {
        val agora = now.format(DateTimeFormatter.ofPattern("EEEE, dd/MM/yyyy HH:mm", PT)) + " (" + now.zone.id + ")"
        val dias = (0..9).joinToString("; ") { i ->
            val d = now.toLocalDate().plusDays(i.toLong())
            d.format(DateTimeFormatter.ofPattern("EEEE dd/MM/yyyy", PT)) +
                (if (i == 0) " (hoje)" else if (i == 1) " (amanhã)" else "")
        }
        val mem = if (relevant.isEmpty()) "(nenhuma)" else relevant.joinToString("\n") { m ->
            val meta = listOf(
                m.subject,
                m.people.joinToString(", "),
                m.type,
                if (m.remindAt != null) "lembrete " + Ai.fmt(m.remindAt) else ""
            ).filter { it.isNotBlank() }.joinToString("; ")
            "- [" + Ai.fmt(m.ts) + (if (meta.isNotEmpty()) "; $meta" else "") + "] " + m.text
        }
        return """
Você é a assistente de voz do app pessoal "Memória" do Rodrigo, psicólogo e pesquisador. Fale em português do Brasil, com frases curtas, porque tudo o que você escrever em "say" será lido em voz alta.

Agora: $agora.

Seu trabalho: ouvir o que ele diz e organizar em memórias e compromissos na agenda do Google.
- Se faltar uma informação essencial (principalmente o horário de um compromisso), faça UMA pergunta curta em "say", com "ask": true, e deixe "memory" e "event" nulos.
- Quando tiver o suficiente, preencha "memory" e, se houver data e hora, também "event". Confirme em "say" de forma breve (exemplo: "Anotei. Amanhã às 9, levar a Marina ao médico.").
- Nunca invente horário. Use SEMPRE as datas exatas do CALENDÁRIO abaixo. Para "quinta", "na quinta" ou "quinta que vem", use a próxima quinta-feira depois de hoje (só use hoje se ele disser "hoje").
- A verificação de conflito com a agenda é feita pelo app. Nunca diga que ele já tem algo marcado nem que o horário está ocupado.
- Em "say", escreva horas e números por extenso, como se fossem falados (exemplos: "vinte e duas horas", "oito de outubro"), com o gênero certo ("uma hora", "duas horas").
- Em "say", confirme sempre com dia da semana, dia e mês e hora (exemplo: "Marquei barbeiro na quinta, 8 de outubro, às 10 horas.").
- Se ele só perguntar algo, responda usando apenas as MEMÓRIAS RELEVANTES abaixo e deixe "memory" e "event" nulos. Se não souber, diga que não encontrou.
- Escolha "subject" entre os ASSUNTOS CONHECIDOS quando servir; senão crie um assunto curto. "people" lista os nomes citados. "type" é um de: tarefa, ideia, fato, promessa (algo que ele disse a alguém que faria) ou aguardando (algo que depende da resposta de outra pessoa; use "remind_at" no prazo para cobrar e, se ele não disser o prazo, pergunte). Em tarefa e promessa com prazo, preencha "remind_at".
- Não peça nem repita dados clínicos ou nomes de pacientes.

Responda SOMENTE com um objeto JSON neste formato:
{"say":"...","ask":false,"memory":null,"event":null}
onde memory = {"text":"...","subject":"...","people":["..."],"type":"tarefa|ideia|fato|promessa|aguardando","remind_at":"AAAA-MM-DDTHH:MM"} (remind_at pode ser null)
e event = {"title":"...","start":"AAAA-MM-DDTHH:MM","duration_min":60,"reminder_min":30}.

ASSUNTOS CONHECIDOS: ${if (subjects.isEmpty()) "(nenhum ainda)" else subjects.joinToString(", ")}
PESSOAS CONHECIDAS: ${if (people.isEmpty()) "(nenhuma ainda)" else people.joinToString(", ")}
CALENDÁRIO DOS PRÓXIMOS DIAS: $dias
MEMÓRIAS RELEVANTES:
$mem
""".trim()
    }

    fun fmt(ts: Long): String =
        java.time.Instant.ofEpochMilli(ts).atZone(ZoneId.systemDefault())
            .format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"))

    fun buildRequest(model: String, system: String, history: List<Pair<String, String>>, user: String): String {
        val msgs = JSONArray()
        msgs.put(JSONObject().put("role", "system").put("content", system))
        history.forEach { msgs.put(JSONObject().put("role", it.first).put("content", it.second)) }
        msgs.put(JSONObject().put("role", "user").put("content", user))
        return JSONObject()
            .put("model", model)
            .put("messages", msgs)
            .put("response_format", JSONObject().put("type", "json_object"))
            .toString()
    }

    fun extractContent(body: String): String =
        JSONObject(body).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")

    private fun parseTime(s: String?): Long? {
        if (s.isNullOrBlank()) return null
        val t = s.trim().replace(' ', 'T')
        return try {
            LocalDateTime.parse(t).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        } catch (e: Exception) {
            null
        }
    }

    fun parseContent(content: String): AiResult {
        val a = content.indexOf('{')
        val b = content.lastIndexOf('}')
        if (a < 0 || b <= a) return AiResult(content.trim().ifEmpty { "Pronto." }, false, null, null)
        val o = JSONObject(content.substring(a, b + 1))
        val say = o.optString("say", "").trim().ifEmpty { "Pronto." }
        val ask = o.optBoolean("ask", false)

        val mo = o.optJSONObject("memory")
        val memory = if (mo != null && mo.optString("text", "").isNotBlank()) {
            val ppl = ArrayList<String>()
            val arr = mo.optJSONArray("people")
            if (arr != null) for (i in 0 until arr.length()) {
                val p = arr.optString(i, "").trim()
                if (p.isNotEmpty()) ppl.add(p)
            }
            val type = mo.optString("type", "fato").trim().lowercase(Locale.ROOT)
            AiMemory(
                mo.optString("text").trim(),
                mo.optString("subject", "").trim(),
                ppl,
                if (type in TYPES) type else "fato",
                parseTime(if (mo.isNull("remind_at")) null else mo.optString("remind_at"))
            )
        } else null

        val eo = o.optJSONObject("event")
        val event = if (eo != null) {
            val start = parseTime(if (eo.isNull("start")) null else eo.optString("start"))
            val title = eo.optString("title", "").trim()
            if (start != null && title.isNotEmpty()) {
                AiEvent(
                    title,
                    start,
                    eo.optInt("duration_min", 60).coerceIn(5, 1440),
                    if (eo.isNull("reminder_min")) 30 else eo.optInt("reminder_min", 30).coerceIn(0, 10080)
                )
            } else null
        } else null

        return AiResult(say, ask, memory, event)
    }

    /** Chama a API da OpenAI e devolve o corpo da resposta. */
    fun call(key: String, body: String): String {
        try {
            val c = URL("https://api.openai.com/v1/chat/completions").openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 20000
            c.readTimeout = 60000
            c.doOutput = true
            c.setRequestProperty("Authorization", "Bearer $key")
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            if (code == 200) {
                val text = c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                c.disconnect()
                return text
            }
            val err = try {
                c.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            } catch (e: Exception) { "" }
            c.disconnect()
            val msg = try { JSONObject(err).getJSONObject("error").optString("message", "") } catch (e: Exception) { "" }
            throw AiException(
                when (code) {
                    401 -> "Chave da IA inválida."
                    429 -> "A IA recusou: limite ou saldo esgotado."
                    404 -> "Modelo da IA não encontrado. Confira o nome do modelo."
                    else -> "A IA recusou o pedido (código $code)." + (if (msg.isNotEmpty()) " " + msg.take(110) else "")
                }
            )
        } catch (e: AiException) {
            throw e
        } catch (e: Exception) {
            throw AiException("Sem conexão com a IA.")
        }
    }
}
