package br.com.rodripsi.memoria

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Guarda as memórias num arquivo privado do app (não sai do aparelho). */
class Store(ctx: Context) {
    private val file = File(ctx.filesDir, "memorias.json")

    fun load(): List<Memory> = try {
        if (!file.exists()) emptyList() else fromJson(file.readText())
    } catch (e: Exception) {
        emptyList()
    }

    fun save(list: List<Memory>) {
        try {
            file.writeText(toJson(list))
        } catch (e: Exception) {
            // sem espaço ou erro de disco: ignora nesta versão
        }
    }

    companion object {
        fun fromJson(s: String): List<Memory> {
            val arr = JSONArray(s)
            return (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                val ppl = ArrayList<String>()
                val pa = o.optJSONArray("people")
                if (pa != null) for (i in 0 until pa.length()) ppl.add(pa.optString(i))
                Memory(
                    o.getString("id"),
                    o.getString("text"),
                    o.getLong("ts"),
                    o.optString("subject", ""),
                    ppl,
                    o.optString("type", "fato"),
                    if (o.has("remindAt") && !o.isNull("remindAt")) o.getLong("remindAt") else null,
                    o.optBoolean("done", false)
                )
            }
        }

        fun toJson(list: List<Memory>): String {
            val arr = JSONArray()
            list.forEach { m ->
                val o = JSONObject()
                    .put("id", m.id).put("text", m.text).put("ts", m.ts)
                    .put("subject", m.subject)
                    .put("people", JSONArray(m.people))
                    .put("type", m.type)
                    .put("done", m.done)
                if (m.remindAt != null) o.put("remindAt", m.remindAt)
                arr.put(o)
            }
            return arr.toString(2)
        }
    }
}
