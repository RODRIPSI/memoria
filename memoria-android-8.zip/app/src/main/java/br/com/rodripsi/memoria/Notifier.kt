package br.com.rodripsi.memoria

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

/** Agenda e mostra os avisos de lembretes (notificação no horário marcado). */
object Notifier {
    const val CHANNEL = "lembretes"
    const val ACTION_ALARM = "br.com.rodripsi.memoria.ALARM"
    const val ACTION_DONE = "br.com.rodripsi.memoria.DONE"
    const val ACTION_SNOOZE = "br.com.rodripsi.memoria.SNOOZE"
    const val EXTRA_ID = "memory_id"
    const val EXTRA_FOCUS = "focus_id"

    fun ensureChannel(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) == null) {
            val ch = NotificationChannel(CHANNEL, "Lembretes", NotificationManager.IMPORTANCE_HIGH)
            ch.description = "Avisos de lembretes e retornos pendentes"
            nm.createNotificationChannel(ch)
        }
    }

    private fun alarmIntent(ctx: Context, id: String): PendingIntent {
        val i = Intent(ctx, ReminderReceiver::class.java).setAction(ACTION_ALARM).putExtra(EXTRA_ID, id)
        return PendingIntent.getBroadcast(
            ctx, id.hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun cancel(ctx: Context, id: String) {
        try {
            ctx.getSystemService(AlarmManager::class.java).cancel(alarmIntent(ctx, id))
            NotificationManagerCompat.from(ctx).cancel(id.hashCode())
        } catch (e: Exception) {
            // sem alarme para cancelar
        }
    }

    fun canExact(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 31 || ctx.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()

    fun schedule(ctx: Context, m: Memory) {
        val at = m.remindAt
        if (at == null || m.done) {
            cancel(ctx, m.id)
            return
        }
        val now = System.currentTimeMillis()
        if (at < now - 60_000L) return // já passou: aparece como "atrasado" no Meu dia
        val am = ctx.getSystemService(AlarmManager::class.java)
        val pi = alarmIntent(ctx, m.id)
        try {
            if (canExact(ctx)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    fun rescheduleAll(ctx: Context, list: List<Memory>) {
        list.forEach { schedule(ctx, it) }
    }

    fun notify(ctx: Context, m: Memory) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        ensureChannel(ctx)
        val sig = Config(ctx).sigilos.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        val text = when {
            isSigilosoMemory(m, sig) -> "Você tem um lembrete."
            m.type == "aguardando" -> "Aguardando retorno: " + m.text + ". Já respondeu?"
            else -> m.text
        }
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val open = PendingIntent.getActivity(
            ctx, m.id.hashCode(),
            Intent(ctx, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra(EXTRA_FOCUS, m.id),
            flags
        )
        val done = PendingIntent.getBroadcast(
            ctx, m.id.hashCode() + 1,
            Intent(ctx, ActionReceiver::class.java).setAction(ACTION_DONE).putExtra(EXTRA_ID, m.id), flags
        )
        val snooze = PendingIntent.getBroadcast(
            ctx, m.id.hashCode() + 2,
            Intent(ctx, ActionReceiver::class.java).setAction(ACTION_SNOOZE).putExtra(EXTRA_ID, m.id), flags
        )
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("Memória")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setContentIntent(open)
            .addAction(0, "Feito", done)
            .addAction(0, "Adiar 1 h", snooze)
            .build()
        NotificationManagerCompat.from(ctx).notify(m.id.hashCode(), n)
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getStringExtra(Notifier.EXTRA_ID) ?: return
        val m = Store(ctx).load().firstOrNull { it.id == id } ?: return
        if (!m.done) Notifier.notify(ctx, m)
    }
}

class ActionReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getStringExtra(Notifier.EXTRA_ID) ?: return
        val store = Store(ctx)
        val list = store.load()
        val updated = when (intent.action) {
            Notifier.ACTION_DONE -> list.map { if (it.id == id) it.copy(done = true) else it }
            Notifier.ACTION_SNOOZE ->
                list.map { if (it.id == id) it.copy(remindAt = System.currentTimeMillis() + 3_600_000L) else it }
            else -> list
        }
        store.save(updated)
        val m = updated.firstOrNull { it.id == id }
        if (m != null) Notifier.schedule(ctx, m)
        NotificationManagerCompat.from(ctx).cancel(id.hashCode())
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            Notifier.rescheduleAll(ctx, Store(ctx).load())
        }
    }
}
