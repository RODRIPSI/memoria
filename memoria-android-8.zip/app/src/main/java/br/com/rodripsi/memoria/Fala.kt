package br.com.rodripsi.memoria

/**
 * Prepara o texto para ser falado: escreve números por extenso, com o gênero certo
 * ("vinte e duas horas", "uma hora", "duas memórias") e datas como "oito de outubro".
 */
object Fala {
    private val U = arrayOf(
        "zero", "um", "dois", "três", "quatro", "cinco", "seis", "sete", "oito", "nove", "dez",
        "onze", "doze", "treze", "catorze", "quinze", "dezesseis", "dezessete", "dezoito", "dezenove"
    )
    private val D = arrayOf("", "", "vinte", "trinta", "quarenta", "cinquenta", "sessenta", "setenta", "oitenta", "noventa")
    private val C = arrayOf(
        "", "cento", "duzentos", "trezentos", "quatrocentos", "quinhentos",
        "seiscentos", "setecentos", "oitocentos", "novecentos"
    )
    private val CF = arrayOf(
        "", "cento", "duzentas", "trezentas", "quatrocentas", "quinhentas",
        "seiscentas", "setecentas", "oitocentas", "novecentas"
    )
    private val MESES = arrayOf(
        "", "janeiro", "fevereiro", "março", "abril", "maio", "junho",
        "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"
    )

    private fun below1000(n: Int, fem: Boolean): String {
        if (n < 20) return if (fem && n == 1) "uma" else if (fem && n == 2) "duas" else U[n]
        if (n < 100) {
            val u = n % 10
            return D[n / 10] + (if (u == 0) "" else " e " + below1000(u, fem))
        }
        if (n == 100) return "cem"
        val r = n % 100
        return (if (fem) CF[n / 100] else C[n / 100]) + (if (r == 0) "" else " e " + below1000(r, fem))
    }

    fun cardinal(n: Int, fem: Boolean = false): String {
        if (n < 0 || n > 999_999) return n.toString()
        if (n < 1000) return below1000(n, fem)
        val th = n / 1000
        val r = n % 1000
        val head = if (th == 1) "mil" else below1000(th, fem) + " mil"
        if (r == 0) return head
        return head + (if (r < 100 || r % 100 == 0) " e " else " ") + below1000(r, fem)
    }

    private fun horas(h: Int): String = when (h) {
        0 -> "meia-noite"
        1 -> "uma hora"
        else -> cardinal(h, true) + " horas"
    }

    private fun hora(h: Int, mi: Int): String {
        if (mi == 0) return horas(h)
        val base = horas(h)
        return base + " e " + cardinal(mi) + (if (mi == 1) " minuto" else " minutos")
    }

    private val FEM_NOUNS =
        "horas?|memórias?|pessoas?|semanas?|vezes|consultas?|sessões|tarefas?|promessas?|reuniões|agendas?|ideias?|mensagens?|notas?"

    fun paraFala(text: String): String {
        var s = text

        // 22:30 -> vinte e duas horas e trinta minutos
        s = Regex("""\b(\d{1,2}):(\d{2})\b""").replace(s) { m ->
            val h = m.groupValues[1].toInt()
            val mi = m.groupValues[2].toInt()
            if (h in 0..24 && mi in 0..59) hora(h, mi) else m.value
        }
        // 22h, 9h30 -> vinte e duas horas, nove horas e trinta minutos
        s = Regex("""\b(\d{1,2})\s?h(?:(\d{2}))?\b""", RegexOption.IGNORE_CASE).replace(s) { m ->
            val h = m.groupValues[1].toInt()
            val mi = if (m.groupValues[2].isEmpty()) 0 else m.groupValues[2].toInt()
            if (h in 0..24 && mi in 0..59) hora(h, mi) else m.value
        }
        // 08/10 ou 08/10/2026 -> oito de outubro
        s = Regex("""\b(\d{1,2})/(\d{1,2})(?:/(\d{4}))?\b""").replace(s) { m ->
            val d = m.groupValues[1].toInt()
            val mo = m.groupValues[2].toInt()
            if (d in 1..31 && mo in 1..12) {
                (if (d == 1) "primeiro" else cardinal(d)) + " de " + MESES[mo] +
                    (if (m.groupValues[3].isNotEmpty()) " de " + cardinal(m.groupValues[3].toInt()) else "")
            } else m.value
        }
        // "dia 1 de" -> "dia primeiro de"
        s = Regex("""\b([Dd]ia) 1(?= de )""").replace(s) { it.groupValues[1] + " primeiro" }
        // número + substantivo feminino: 2 memórias -> duas memórias
        s = Regex("""(?<![\d.,])(\d{1,6})(\s+)($FEM_NOUNS)\b""", RegexOption.IGNORE_CASE).replace(s) { m ->
            cardinal(m.groupValues[1].toInt(), true) + m.groupValues[2] + m.groupValues[3]
        }
        s = s.replace("%", " por cento")
        // demais números inteiros
        s = Regex("""(?<![\d.,])(\d{1,6})(?!\d|[.,]\d)""").replace(s) { cardinal(it.groupValues[1].toInt()) }

        // concordância da preposição com "uma hora"
        s = s.replace("às uma hora", "à uma hora").replace("Às uma hora", "À uma hora").replace("das uma hora", "da uma hora")
            .replace("às meia-noite", "à meia-noite").replace("Às meia-noite", "À meia-noite").replace("das meia-noite", "da meia-noite").replace("Das meia-noite", "Da meia-noite").replace("Das uma hora", "Da uma hora")
        return s
    }
}
