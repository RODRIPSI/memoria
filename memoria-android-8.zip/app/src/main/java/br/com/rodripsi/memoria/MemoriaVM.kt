package br.com.rodripsi.memoria

import android.app.Application
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.UUID

private enum class Pending { SAVE, DELETE, CONFIRM_EVENT }

class MemoriaVM(app: Application) : AndroidViewModel(app) {

    private val store = Store(app)
    private val config = Config(app)
    private val main = Handler(Looper.getMainLooper())

    var memories by mutableStateOf(store.load())
        private set
    var status by mutableStateOf("Toque para falar")
        private set
    var heard by mutableStateOf("")
        private set
    var answerHead by mutableStateOf<String?>(null)
        private set
    var answerItems by mutableStateOf<List<Memory>>(emptyList())
        private set
    var answerLines by mutableStateOf<List<String>>(emptyList())
        private set
    var listening by mutableStateOf(false)
        private set
    var speaking by mutableStateOf(false)
        private set
    var loop by mutableStateOf(false)
    var filter by mutableStateOf<String?>(null)

    // voz do ElevenLabs
    var apiKey: String = config.apiKey
        private set
    var voiceId: String = config.voiceId
        private set
    var model: String = config.model
        private set
    var useMyVoice by mutableStateOf(config.useMyVoice)
        private set

    // IA, agenda e sigilo
    var aiKey: String = config.aiKey
        private set
    var aiModel: String = config.aiModel
        private set
    var useAi by mutableStateOf(config.useAi)
        private set
    var useCalendar by mutableStateOf(config.useCalendar)
        private set
    var sigilos: String = config.sigilos
        private set

    var voiceNote by mutableStateOf<String?>(null)
        private set

    private var pending: Pending? = null
    private var pendingAi: AiResult? = null
    private var focusId: String? = null
    private var lastError = false
    private var listenAfter = false
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var currentUtt: String? = null
    private var player: MediaPlayer? = null
    private val chat = ArrayList<Pair<String, String>>()
    private var lastChatAt = 0L

    init {
        Notifier.ensureChannel(app)
        Notifier.rescheduleAll(app, memories)
        tts = TextToSpeech(app) { st ->
            if (st == TextToSpeech.SUCCESS) {
                val res = tts?.setLanguage(Locale("pt", "BR"))
                ttsReady = res != TextToSpeech.LANG_MISSING_DATA && res != TextToSpeech.LANG_NOT_SUPPORTED
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        main.post { if (utteranceId == currentUtt) { speaking = true; status = "Falando…" } }
                    }
                    override fun onDone(utteranceId: String?) {
                        main.post { if (utteranceId == currentUtt) finishSpeaking() }
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        main.post { if (utteranceId == currentUtt) finishSpeaking() }
                    }
                })
            }
        }
    }

    private fun sigiloList(): List<String> =
        sigilos.split(",").map { it.trim() }.filter { it.isNotEmpty() }

    // ---------- configuração ----------

    fun saveAll(elKey: String, elId: String, elModel: String, openKey: String, openModel: String, sig: String) {
        val firstVoice = apiKey.isBlank() || voiceId.isBlank()
        val firstAi = aiKey.isBlank()
        apiKey = elKey.trim()
        voiceId = elId.trim()
        model = elModel
        aiKey = openKey.trim()
        aiModel = openModel.trim().ifEmpty { "gpt-5.4-mini" }
        sigilos = sig.trim()
        config.apiKey = apiKey
        config.voiceId = voiceId
        config.model = model
        config.aiKey = aiKey
        config.aiModel = aiModel
        config.sigilos = sigilos
        if (firstVoice && apiKey.isNotEmpty() && voiceId.isNotEmpty()) changeMyVoice(true)
        if (firstAi && aiKey.isNotEmpty()) changeAi(true)
        voiceNote = null
        status = "Configuração salva."
    }

    fun changeMyVoice(v: Boolean) {
        useMyVoice = v
        config.useMyVoice = v
        voiceNote = if (v && (apiKey.isBlank() || voiceId.isBlank()))
            "Preencha a chave e o ID da voz, em Configurações, e toque em Salvar." else null
    }

    fun changeAi(v: Boolean) {
        useAi = v
        config.useAi = v
        voiceNote = if (v && aiKey.isBlank())
            "Cole a chave da IA, em Configurações, e toque em Salvar." else null
    }

    fun changeCalendar(v: Boolean) {
        val ok = v && Agenda.hasPermission(getApplication<Application>())
        useCalendar = ok
        config.useCalendar = ok
        voiceNote = if (v && !ok)
            "Sem permissão da agenda. Libere em Configurações do Android > Apps > Memória > Permissões." else null
    }

    fun testVoice() {
        if (apiKey.isBlank() || voiceId.isBlank()) {
            voiceNote = "Preencha a chave e o ID da voz."
            return
        }
        stopSpeaking()
        speak("Olá! Esta é a minha voz no aplicativo Memória.", true, false)
    }

    // ---------- voz: saída ----------

    private fun speak(rawText: String, forceEleven: Boolean, forceAndroid: Boolean) {
        val text = Fala.paraFala(rawText)
        val id = "u" + System.nanoTime()
        currentUtt = id
        speaking = true
        val wantEleven = (useMyVoice || forceEleven) && apiKey.isNotBlank() && voiceId.isNotBlank() && !forceAndroid
        if (wantEleven) {
            status = "Gerando voz…"
            speakEleven(text, id)
        } else {
            speakAndroid(text, id)
        }
    }

    private fun speakAndroid(text: String, id: String) {
        if (!ttsReady) {
            speaking = false
            currentUtt = null
            status = "Toque para falar"
            return
        }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
    }

    private fun speakEleven(text: String, id: String) {
        val key = apiKey
        val voice = voiceId
        val mdl = model
        val cache = File(getApplication<Application>().cacheDir, "voz.mp3")
        Thread {
            var err: String? = null
            try {
                val url = URL(
                    "https://api.elevenlabs.io/v1/text-to-speech/" +
                        URLEncoder.encode(voice, "UTF-8") + "?output_format=mp3_44100_128"
                )
                val c = url.openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.connectTimeout = 15000
                c.readTimeout = 40000
                c.doOutput = true
                c.setRequestProperty("xi-api-key", key)
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("Accept", "audio/mpeg")
                val body = JSONObject().put("text", text).put("model_id", mdl).toString()
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                val code = c.responseCode
                if (code == 200) {
                    c.inputStream.use { input -> cache.outputStream().use { out -> input.copyTo(out) } }
                } else {
                    err = when (code) {
                        401 -> "Chave do ElevenLabs inválida ou sem créditos."
                        429 -> "Limite do ElevenLabs atingido. Tente de novo em instantes."
                        400, 404, 422 -> "ID da voz ou modelo inválido (código $code)."
                        else -> "O ElevenLabs recusou o pedido (código $code)."
                    }
                }
                c.disconnect()
            } catch (e: Exception) {
                err = "Sem conexão com o ElevenLabs."
            }
            main.post {
                if (id == currentUtt) {
                    if (err != null) {
                        voiceNote = err + " Usei a voz do Android."
                        speakAndroid(text, id)
                    } else {
                        playFile(cache, id, text)
                    }
                }
            }
        }.start()
    }

    private fun releasePlayer() {
        try { player?.release() } catch (e: Exception) { }
        player = null
    }

    private fun playFile(f: File, id: String, text: String) {
        releasePlayer()
        try {
            val p = MediaPlayer()
            p.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            p.setDataSource(f.absolutePath)
            p.setOnPreparedListener { mp ->
                if (id == currentUtt) { status = "Falando…"; mp.start() }
            }
            p.setOnCompletionListener {
                releasePlayer()
                if (id == currentUtt) finishSpeaking()
            }
            p.setOnErrorListener { _, _, _ ->
                releasePlayer()
                if (id == currentUtt) {
                    voiceNote = "Não consegui tocar o áudio. Usei a voz do Android."
                    speakAndroid(text, id)
                }
                true
            }
            player = p
            p.prepareAsync()
        } catch (e: Exception) {
            releasePlayer()
            speakAndroid(text, id)
        }
    }

    private fun finishSpeaking() {
        if (!speaking) return
        speaking = false
        currentUtt = null
        status = "Toque para falar"
        val again = (loop || listenAfter) && !lastError
        listenAfter = false
        if (again) startListening()
    }

    private fun stopSpeaking() {
        currentUtt = null
        speaking = false
        releasePlayer()
        tts?.stop()
    }

    // ---------- voz: entrada ----------

    fun toggleListening() {
        if (listening) recognizer?.stopListening() else startListening()
    }

    fun permissionDenied() {
        status = "Sem permissão do microfone. Libere em Configurações > Apps > Memória > Permissões."
    }

    private fun startListening() {
        val ctx = getApplication<Application>()
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            status = "Este aparelho não tem reconhecimento de voz disponível."
            return
        }
        stopSpeaking()
        lastError = false
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { listening = true; status = "Ouvindo…"; heard = "" }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onPartialResults(partialResults: Bundle?) {
                val p = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!p.isNullOrBlank()) heard = p
            }
            override fun onResults(results: Bundle?) {
                listening = false
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t.isNullOrBlank()) status = "Não entendi. Toque e tente de novo." else handle(t)
            }
            override fun onError(error: Int) {
                listening = false
                lastError = true
                status = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                        "Não ouvi nada. Toque e tente de novo."
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                        "Sem permissão do microfone."
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                        "Sem internet e sem pacote de voz offline em português. Baixe-o nas configurações de voz do Google."
                    else -> "Erro de reconhecimento (código $error). Tente de novo."
                }
            }
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        recognizer = r
        r.startListening(intent)
    }

    // ---------- lógica ----------

    private fun reply(r: Reply, listenAfterSpeak: Boolean = false) {
        answerHead = r.head
        answerItems = r.items
        answerLines = r.lines
        listenAfter = listenAfterSpeak
        val sig = sigiloList()
        val sensitive = r.sensitive || isSigiloso(r.spoken, sig) || r.items.any { isSigilosoMemory(it, sig) }
        speak(r.spoken, false, sensitive)
    }

    private fun addMemoryQuiet(m: AiMemory): Memory {
        val mem = Memory(
            UUID.randomUUID().toString(),
            m.text.trim().replaceFirstChar { it.uppercase() },
            System.currentTimeMillis(),
            m.subject.trim().replaceFirstChar { it.uppercase() },
            m.people,
            m.type,
            m.remindAt
        )
        memories = memories + mem
        store.save(memories)
        Notifier.schedule(getApplication<Application>(), mem)
        return mem
    }

    private fun addMemory(raw: String, subject: String = "") {
        val m = addMemoryQuiet(AiMemory(raw, subject, emptyList(), "fato", null))
        reply(Reply("Guardado.", "Guardado.", listOf(m)))
    }

    fun myDay() {
        val ctx = getApplication<Application>()
        val zone = ZoneId.systemDefault()
        val today = LocalDate.now(zone)
        val from = today.atStartOfDay(zone).toInstant().toEpochMilli()
        val to = today.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli()
        val on = useCalendar && Agenda.hasPermission(ctx)
        val evs = if (on) Agenda.events(ctx, from, to) else emptyList()
        reply(buildDay(System.currentTimeMillis(), evs, memories, on, sigiloList()))
    }

    private fun askAi(text: String) {
        val now = System.currentTimeMillis()
        if (now - lastChatAt > 5 * 60_000L) chat.clear()
        lastChatAt = now
        status = "Pensando…"
        val sig = sigiloList()
        val pool = memories.filter { !isSigilosoMemory(it, sig) }
        val rel = searchList(pool, text, 5).ifEmpty { pool.takeLast(3) }
        val system = Ai.systemPrompt(
            ZonedDateTime.now(),
            pool.map { it.subject }.filter { it.isNotBlank() }.distinct(),
            pool.flatMap { it.people }.distinct(),
            rel
        )
        val key = aiKey
        val body = Ai.buildRequest(aiModel, system, chat.toList(), text)
        chat.add(Pair("user", text))
        Thread {
            var res: AiResult? = null
            var err: String? = null
            try {
                res = Ai.parseContent(Ai.extractContent(Ai.call(key, body)))
            } catch (e: AiException) {
                err = e.message
            } catch (e: Exception) {
                err = "Não consegui entender a resposta da IA."
            }
            main.post { onAi(text, res, err) }
        }.start()
    }

    private fun onAi(userText: String, res: AiResult?, err: String?) {
        if (res == null) {
            chat.clear()
            voiceNote = (err ?: "Não consegui falar com a IA.") + " Usei o modo simples."
            status = "Toque para falar"
            localHandle(parseCommand(userText))
            return
        }
        voiceNote = null
        val ev = res.event
        val ctx = getApplication<Application>()
        if (ev != null && useCalendar && Agenda.hasPermission(ctx)) {
            val end = ev.startMs + ev.durationMin * 60_000L
            val c = findConflict(Agenda.events(ctx, ev.startMs, end), ev.startMs, end)
            if (c != null) {
                pendingAi = res
                pending = Pending.CONFIRM_EVENT
                chat.clear()
                reply(
                    Reply(
                        "Você já tem " + c.title + " das " + clockLabel(c.start) + " às " + clockLabel(c.end) +
                            ". Quer marcar mesmo assim? Diga sim ou não."
                    ),
                    true
                )
                return
            }
        }
        commitAi(res)
    }

    private fun commitAi(res: AiResult) {
        var say = res.say
        val ev = res.event
        var mem = res.memory
        if (mem == null && ev != null) mem = AiMemory(ev.title, "", emptyList(), "tarefa", ev.startMs)
        val ctx = getApplication<Application>()
        var saved: Memory? = if (mem != null) addMemoryQuiet(mem) else null
        if (ev != null) {
            val ok = useCalendar && Agenda.addEvent(
                ctx, ev.title, ev.startMs, ev.durationMin, ev.reminderMin, "Criado pelo app Memória"
            )
            if (!ok) {
                say += " Não consegui criar na agenda. Ligue a agenda nas configurações."
            } else {
                // a agenda já avisa na hora: evita o aviso duplicado e a repetição no Meu dia
                val s0 = saved
                if (s0 != null) {
                    val s2 = s0.copy(remindAt = null)
                    memories = memories.map { if (it.id == s2.id) s2 else it }
                    store.save(memories)
                    Notifier.cancel(ctx, s2.id)
                    saved = s2
                }
            }
        }
        if (res.ask) {
            chat.add(Pair("assistant", res.say))
            while (chat.size > 10) chat.removeAt(0)
        } else {
            chat.clear()
        }
        reply(Reply(say, say, listOfNotNull(saved)), res.ask)
    }

    // ---------- lembretes: feito, adiar, retorno ----------

    fun reload() {
        memories = store.load()
        Notifier.rescheduleAll(getApplication<Application>(), memories)
    }

    private fun snoozeTo(m: Memory, t: Long) {
        val u = m.copy(remindAt = t, done = false)
        memories = memories.map { if (it.id == u.id) u else it }
        store.save(memories)
        Notifier.schedule(getApplication<Application>(), u)
    }

    private fun openPending(): List<Memory> = memories.filter {
        !it.done && (it.type == "tarefa" || it.type == "promessa" || it.type == "aguardando" || it.remindAt != null)
    }

    private fun doneByText(text: String) {
        val n = norm(text)
        val rest = n.replace(
            Regex("^(ja fiz|ja feito|feito|conclui|concluido|concluida|terminei|ja enviei|ja mandei|ja liguei|ja resolvi|resolvido|ja respondeu|ja me respondeu|me respondeu|respondeu)\\s*"),
            ""
        )
        if (rest.isBlank()) {
            reply(Reply("Diga o que já foi feito, por exemplo: já fiz o capítulo."))
            return
        }
        val target = searchList(openPending(), rest, 1).firstOrNull()
        if (target == null) {
            reply(Reply("Não achei esse pendente."))
            return
        }
        markDone(target.id)
        reply(Reply("Marquei como feito: " + target.text + ".", "Feito", listOf(target)))
    }

    private fun snoozeByText(text: String) {
        val n = norm(text)
        val rest = n.replace(
            Regex("^(adia|adie|adiar|soneca|me lembra de novo|me avisa de novo|lembra de novo)\\s*"), ""
        )
        val pool = memories.filter { !it.done && it.remindAt != null }
        val target = (if (rest.isBlank()) null else searchList(pool, rest, 1).firstOrNull())
            ?: (if (pool.size == 1) pool[0] else null)
        if (target == null) {
            reply(Reply("Qual lembrete você quer adiar? Diga, por exemplo: adia o capítulo para amanhã."))
            return
        }
        val now = System.currentTimeMillis()
        val t = parseSnooze(n, now, target.remindAt) ?: (now + 3_600_000L)
        snoozeTo(target, t)
        reply(Reply("Adiei para " + whenLabel(t) + ".", "Adiado", listOf(target.copy(remindAt = t))))
    }

    /** Aberto pela notificação: fala o lembrete e pergunta se já foi feito. */
    fun focusReminder(id: String) {
        memories = store.load()
        val m = memories.firstOrNull { it.id == id } ?: return
        focusId = id
        val ask = if (m.type == "aguardando")
            "Aguardando retorno: " + m.text + ". Já respondeu? Diga sim, ou adie, por exemplo, amanhã."
        else
            "Lembrete: " + m.text + ". Já fez? Diga feito, ou adie, por exemplo, daqui a uma hora."
        reply(Reply(ask, ask, listOf(m)), true)
    }

    fun testAgenda() {
        answerHead = "Teste da agenda"
        answerItems = emptyList()
        answerLines = Agenda.info(getApplication<Application>())
        status = "Teste da agenda"
    }

    private fun localHandle(cmd: Command) {
        when (cmd) {
            is Command.Save -> addMemory(cmd.text, cmd.subject)
            is Command.AskSave -> { pending = Pending.SAVE; reply(Reply("O que devo guardar?"), true) }
            is Command.AskDelete -> {
                if (memories.isEmpty()) reply(Reply("Não há memórias para apagar."))
                else {
                    pending = Pending.DELETE
                    reply(Reply("Apagar a última memória: " + memories.last().text + ". Confirma? Diga sim ou não."), true)
                }
            }
            is Command.Help -> reply(Reply(
                "Para guardar, diga: guarda que, e o que quer lembrar. " +
                "Para perguntar, diga por exemplo: o que eu guardei ontem. " +
                "Para ouvir o seu dia, diga: meu dia. " +
                "Para apagar, diga: apaga a última."
            ))
            is Command.ListRecent -> reply(recent(memories))
            is Command.MyDay -> myDay()
            is Command.Done -> doneByText(cmd.text)
            is Command.Snooze -> snoozeByText(cmd.text)
            is Command.Ask -> reply(search(memories, cmd.text))
        }
    }

    fun handle(raw: String) {
        val text = raw.trim()
        if (text.isEmpty()) return
        heard = text
        val n = norm(text)

        if (pending == Pending.DELETE) {
            pending = null
            if (Regex("^(sim|pode|confirma|confirmo|isso)\\b").containsMatchIn(n) && memories.isNotEmpty()) {
                val gone = memories.last()
                memories = memories.dropLast(1)
                store.save(memories)
                reply(Reply("Apaguei a última memória.", "Apaguei: " + gone.text))
            } else {
                reply(Reply("Tudo bem, não apaguei nada."))
            }
            return
        }
        if (pending == Pending.CONFIRM_EVENT) {
            pending = null
            val r = pendingAi
            pendingAi = null
            if (r != null && Regex("^(sim|pode|confirma|confirmo|marca|isso)\\b").containsMatchIn(n)) commitAi(r)
            else reply(Reply("Tudo bem, não marquei."))
            return
        }
        if (pending == Pending.SAVE) {
            pending = null
            if (Regex("^(cancela|cancelar|deixa|esquece|nao)\\b").containsMatchIn(n)) reply(Reply("Cancelado."))
            else addMemory(text)
            return
        }

        val f = focusId
        if (f != null) {
            focusId = null
            val fm = memories.firstOrNull { it.id == f }
            if (fm != null && n.split(" ").size <= 6) {
                if (isDoneWord(n)) {
                    markDone(f)
                    reply(Reply("Feito. Marquei como concluído."))
                    return
                }
                val t = parseSnooze(n, System.currentTimeMillis(), fm.remindAt)
                if (t != null) {
                    snoozeTo(fm, t)
                    reply(Reply("Certo. Adiei para " + whenLabel(t) + "."))
                    return
                }
                if (Regex("^(nao|ainda nao)\\b").containsMatchIn(n)) {
                    focusId = f
                    reply(Reply("Tudo bem. Quer adiar? Diga, por exemplo, daqui a uma hora, ou amanhã."), true)
                    return
                }
            }
        }

        val cmd = parseCommand(text)
        val aiOk = useAi && aiKey.isNotBlank() &&
            (cmd is Command.Save || cmd is Command.Ask) &&
            !isSigiloso(text, sigiloList())
        if (aiOk) askAi(text) else localHandle(cmd)
    }

    fun markDone(id: String) {
        memories = memories.map { if (it.id == id) it.copy(done = true) else it }
        store.save(memories)
        Notifier.cancel(getApplication<Application>(), id)
    }

    fun delete(id: String) {
        memories = memories.filter { it.id != id }
        store.save(memories)
        Notifier.cancel(getApplication<Application>(), id)
    }

    fun backupJson(): String = Store.toJson(memories)

    fun note(t: String) { status = t }

    override fun onCleared() {
        releasePlayer()
        recognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onCleared()
    }
}
