# Memória (Android)

App pessoal de memória por voz: você fala, ele guarda; você pergunta, ele responde falando.

- Kotlin + Jetpack Compose, minSdk 26
- Voz: SpeechRecognizer (pt-BR, prefere offline) e TextToSpeech
- Dados: arquivo JSON privado no aparelho (sem nuvem)
- Compilação: GitHub Actions (aba Actions > Compilar APK > artefato "memoria-apk")
