package br.com.rodripsi.memoria

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.ZoneId

private fun Memory.at(): Long = remindAt ?: Long.MAX_VALUE

private val CATEGORIAS = listOf(
    "todos" to "Todos",
    "tarefa" to "Tarefas",
    "promessa" to "Promessas",
    "aguardando" to "Aguardando",
    "ideia" to "Ideias",
    "fato" to "Fatos"
)

/** Painel de lembretes no estilo da Central: contadores Hoje / Próximos / Atrasados, categorias e botão Novo lembrete. */
@Composable
fun LembretesPainel(vm: MemoriaVM) {
    val colors = MaterialTheme.colorScheme
    var tile by remember { mutableStateOf("todos") }
    var cat by remember { mutableStateOf("todos") }
    var novo by remember { mutableStateOf(false) }
    var texto by remember { mutableStateOf("") }

    val zone = ZoneId.systemDefault()
    val agora = System.currentTimeMillis()
    val d0 = LocalDate.now(zone).atStartOfDay(zone).toInstant().toEpochMilli()
    val d1 = d0 + 86_400_000L

    val abertos = vm.memories.filter { !it.done && it.remindAt != null }
    val daCategoria = abertos.filter { cat == "todos" || it.type == cat }
    val nHoje = daCategoria.count { it.at() >= agora && it.at() < d1 }
    val nProx = daCategoria.count { it.at() >= d1 }
    val nAtr = daCategoria.count { it.at() < agora }
    val lista = daCategoria
        .filter {
            when (tile) {
                "hoje" -> it.at() >= agora && it.at() < d1
                "prox" -> it.at() >= d1
                "atr" -> it.at() < agora
                else -> true
            }
        }
        .sortedBy { it.at() }
        .take(30)

    if (novo) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { novo = false },
            title = { Text("Novo lembrete") },
            text = {
                Column {
                    Text("Escreva com o dia e a hora. Ex.: amanhã às 9 comprar carregador de smartwatch", fontSize = 13.sp)
                    OutlinedTextField(
                        value = texto, onValueChange = { texto = it },
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val t = texto.trim()
                    texto = ""
                    novo = false
                    if (t.isNotEmpty()) vm.handle(t)
                }) { Text("Salvar") }
            },
            dismissButton = { TextButton(onClick = { novo = false }) { Text("Cancelar") } }
        )
    }

    Column(Modifier.fillMaxWidth().padding(top = 28.dp)) {
        Text("Lembretes", fontSize = 22.sp, fontWeight = FontWeight.SemiBold, color = colors.onBackground)
        Text(
            "Seus recados em um só lugar",
            fontSize = 14.sp, color = colors.onBackground.copy(alpha = 0.7f),
            modifier = Modifier.padding(top = 2.dp, bottom = 12.dp)
        )

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Contador("Hoje", nHoje, tile == "hoje", false, Modifier.weight(1f)) { tile = if (tile == "hoje") "todos" else "hoje" }
            Contador("Próximos", nProx, tile == "prox", false, Modifier.weight(1f)) { tile = if (tile == "prox") "todos" else "prox" }
            Contador("Atrasados", nAtr, tile == "atr", true, Modifier.weight(1f)) { tile = if (tile == "atr") "todos" else "atr" }
        }

        Button(
            onClick = { novo = true },
            modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
        ) { Text("+  Novo lembrete") }

        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(top = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            CATEGORIAS.forEach { (k, nome) ->
                if (cat == k) Button(onClick = { }) { Text(nome) }
                else OutlinedButton(onClick = { cat = k }) { Text(nome) }
            }
        }

        if (lista.isEmpty()) {
            Text(
                "Nenhum lembrete pendente. Quando você criar um recado com data e hora, ele aparecerá aqui.",
                color = colors.onBackground.copy(alpha = 0.7f), textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(vertical = 20.dp)
            )
        }

        lista.forEach { m ->
            val atrasado = m.at() < agora
            Column(Modifier.fillMaxWidth()) {
                HorizontalDivider(
                    color = colors.onBackground.copy(alpha = 0.12f),
                    modifier = Modifier.padding(top = 10.dp)
                )
                Text(
                    whenLabel(m.at()),
                    fontSize = 13.sp, fontWeight = FontWeight.Bold,
                    color = if (atrasado) colors.error else colors.primary,
                    modifier = Modifier.padding(top = 10.dp)
                )
                Text(m.text, fontSize = 17.sp, color = colors.onBackground)
                Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.markDone(m.id) }) { Text("Feito") }
                    OutlinedButton(onClick = { vm.snoozeId(m.id, System.currentTimeMillis() + 3_600_000L) }) { Text("Adiar 1 h") }
                }
            }
        }
    }
}

@Composable
private fun Contador(
    nome: String, n: Int, marcado: Boolean, alerta: Boolean, modifier: Modifier, onClick: () -> Unit
) {
    val colors = MaterialTheme.colorScheme
    val fundo = when {
        marcado -> colors.primary.copy(alpha = 0.25f)
        alerta && n > 0 -> colors.error.copy(alpha = 0.18f)
        else -> colors.surface
    }
    Card(
        colors = CardDefaults.cardColors(containerColor = fundo),
        modifier = modifier.clickable { onClick() }
    ) {
        Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.Start) {
            Text(nome, fontSize = 14.sp, color = colors.onSurface)
            Text(n.toString(), fontSize = 26.sp, fontWeight = FontWeight.Medium, color = colors.onSurface)
        }
    }
}
