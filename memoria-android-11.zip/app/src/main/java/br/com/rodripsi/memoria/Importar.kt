package br.com.rodripsi.memoria

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Locale

data class ImportItem(
    val name: String,
    val hour: Int,
    val minute: Int,
    val date: LocalDate?,
    val notes: String
)

data class ImportDraft(val items: List<ImportItem>, val ignored: List<String>, val declared: Int?)

private val PT_IMP = Locale("pt", "BR")

private val NAO_PACIENTE = setOf(
    "almoco", "intervalo", "livre", "folga", "bloqueado", "bloqueio", "fechado",
    "indisponivel", "janta", "jantar", "lanche", "descanso"
)

private val DATE_RE = Regex("""(\d{1,2})/(\d{1,2})(?:/(\d{2,4}))?""")
private val HOUR_RE = Regex("""^(\d{1,2})\s*(?:h|:)\s*(\d{2})?\s*(?:[-–—:]\s*)?(.*)$""", RegexOption.IGNORE_CASE)
private val COUNT_RE = Regex("""^(\d{1,3})\s*[-–—]?\s*pacientes?\b""", RegexOption.IGNORE_CASE)
private val PART_SPLIT = Regex("""\s+[-–—]\s*|\s*[-–—]\s+""")

private val MESES_NORM = mapOf(
    "janeiro" to 1, "fevereiro" to 2, "marco" to 3, "abril" to 4, "maio" to 5, "junho" to 6,
    "julho" to 7, "agosto" to 8, "setembro" to 9, "outubro" to 10, "novembro" to 11, "dezembro" to 12
)

private val DIAS_NORM = mapOf(
    "domingo" to DayOfWeek.SUNDAY, "segunda" to DayOfWeek.MONDAY, "terca" to DayOfWeek.TUESDAY,
    "quarta" to DayOfWeek.WEDNESDAY, "quinta" to DayOfWeek.THURSDAY, "sexta" to DayOfWeek.FRIDAY,
    "sabado" to DayOfWeek.SATURDAY
)

private val NUM_DIA = mapOf(
    "um" to 1, "primeiro" to 1, "dois" to 2, "tres" to 3, "quatro" to 4, "cinco" to 5, "seis" to 6,
    "sete" to 7, "oito" to 8, "nove" to 9, "dez" to 10, "onze" to 11, "doze" to 12, "treze" to 13,
    "catorze" to 14, "quatorze" to 14, "quinze" to 15, "dezesseis" to 16, "dezessete" to 17,
    "dezoito" to 18, "dezenove" to 19, "vinte" to 20, "trinta" to 30
)

/** Mantém só letras, números, espaços e pontuação simples (tira emojis e símbolos). */
private fun clean(line: String): String =
    line.filter { it.isLetterOrDigit() || it in " :-–—/.,()" }
        .replace(Regex("\\s+"), " ")
        .trim()

private fun makeDate(d: Int, m: Int, y: Int?, today: LocalDate): LocalDate? {
    return try {
        if (y != null) {
            LocalDate.of(if (y < 100) 2000 + y else y, m, d)
        } else {
            val c = LocalDate.of(today.year, m, d)
            if (c.isBefore(today.minusMonths(6))) c.plusYears(1) else c
        }
    } catch (e: Exception) {
        null
    }
}

/** Entende "sábado", "hoje", "amanhã", "3 de outubro", "03/10", "dia 3". */
fun parseDay(n: String, today: LocalDate): LocalDate? {
    if (Regex("\\bdepois de amanha\\b").containsMatchIn(n)) return today.plusDays(2)
    if (Regex("\\bamanha\\b").containsMatchIn(n)) return today.plusDays(1)
    if (Regex("\\bhoje\\b").containsMatchIn(n)) return today
    val dm = DATE_RE.find(n)
    if (dm != null) {
        val y = dm.groupValues[3].ifEmpty { null }?.toIntOrNull()
        val r = makeDate(dm.groupValues[1].toInt(), dm.groupValues[2].toInt(), y, today)
        if (r != null) return r
    }
    // "3 de outubro", "tres de outubro"
    val mm = Regex("\\b(\\d{1,2}|[a-z]+) de (janeiro|fevereiro|marco|abril|maio|junho|julho|agosto|setembro|outubro|novembro|dezembro)\\b").find(n)
    if (mm != null) {
        val d = mm.groupValues[1].toIntOrNull() ?: NUM_DIA[mm.groupValues[1]]
        if (d != null) {
            val r = makeDate(d, MESES_NORM[mm.groupValues[2]]!!, null, today)
            if (r != null) return r
        }
    }
    for ((k, dow) in DIAS_NORM) {
        if (Regex("\\b$k\\b").containsMatchIn(n)) {
            val diff = (dow.value - today.dayOfWeek.value + 7) % 7
            return today.plusDays(diff.toLong())
        }
    }
    val dd = Regex("\\bdia (\\d{1,2})\\b").find(n)
    if (dd != null) {
        val d = dd.groupValues[1].toInt()
        var r = makeDate(d, today.monthValue, null, today)
        if (r != null && r.isBefore(today)) r = makeDate(d, today.plusMonths(1).monthValue, today.plusMonths(1).year, today)
        return r
    }
    return null
}

/** Como parseDay, mas também entende datas com barra ("03/10") no texto original. */
fun parseDayText(raw: String, today: LocalDate): LocalDate? {
    val dm = DATE_RE.find(raw)
    if (dm != null) {
        val y = dm.groupValues[3].ifEmpty { null }?.toIntOrNull()
        val r = makeDate(dm.groupValues[1].toInt(), dm.groupValues[2].toInt(), y, today)
        if (r != null) return r
    }
    return parseDay(norm(raw), today)
}

fun describeDay(d: LocalDate): String =
    d.dayOfWeek.getDisplayName(TextStyle.FULL, PT_IMP) + ", " + d.dayOfMonth + " de " +
        d.month.getDisplayName(TextStyle.FULL, PT_IMP)

/**
 * Lê uma mensagem de agenda colada do WhatsApp (linhas como "9h - Nome - 💰").
 * Devolve null se a mensagem não parece uma agenda.
 */
fun parseAgendaMessage(text: String, today: LocalDate): ImportDraft? {
    var current: LocalDate? = null
    var declared: Int? = null
    val items = ArrayList<ImportItem>()
    val ignored = ArrayList<String>()

    for (raw in text.split(Regex("[\\r\\n]+"))) {
        val line = clean(raw)
        if (line.isEmpty()) continue

        val h = HOUR_RE.find(line)
        if (h != null) {
            val hour = h.groupValues[1].toInt()
            val min = if (h.groupValues[2].isEmpty()) 0 else h.groupValues[2].toInt()
            if (hour !in 0..23 || min !in 0..59) continue
            val parts = h.groupValues[3].split(PART_SPLIT)
                .map { it.trim(' ', '.', ',', '-', '–', '—') }
                .filter { it.isNotEmpty() }
            val name = parts.firstOrNull() ?: continue
            if (!name.any { it.isLetter() }) continue
            val nn = norm(name)
            if (nn in NAO_PACIENTE || nn.split(" ").first() in NAO_PACIENTE) {
                ignored.add(name)
                continue
            }
            items.add(ImportItem(name, hour, min, current, parts.drop(1).joinToString(", ")))
            continue
        }

        val c = COUNT_RE.find(line)
        if (c != null) {
            if (declared == null) declared = c.groupValues[1].toInt()
            continue
        }

        if (line.length <= 40) {
            val d = parseDayText(line, today)
            if (d != null) current = d
        }
    }
    val ok = items.size >= 2 || (items.size == 1 && items[0].date != null)
    return if (ok) ImportDraft(items, ignored, declared) else null
}
