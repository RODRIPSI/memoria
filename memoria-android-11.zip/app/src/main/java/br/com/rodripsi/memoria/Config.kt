package br.com.rodripsi.memoria

import android.content.Context

/** Configurações guardadas só no aparelho (armazenamento privado do app). */
class Config(ctx: Context) {
    private val sp = ctx.getSharedPreferences("config", Context.MODE_PRIVATE)

    var apiKey: String
        get() = sp.getString("apiKey", "") ?: ""
        set(v) { sp.edit().putString("apiKey", v).apply() }

    var voiceId: String
        get() = sp.getString("voiceId", "") ?: ""
        set(v) { sp.edit().putString("voiceId", v).apply() }

    var model: String
        get() = sp.getString("model", "eleven_flash_v2_5") ?: "eleven_flash_v2_5"
        set(v) { sp.edit().putString("model", v).apply() }

    var useMyVoice: Boolean
        get() = sp.getBoolean("useMyVoice", false)
        set(v) { sp.edit().putBoolean("useMyVoice", v).apply() }

    var aiKey: String
        get() = sp.getString("aiKey", "") ?: ""
        set(v) { sp.edit().putString("aiKey", v).apply() }

    var aiModel: String
        get() = sp.getString("aiModel", "gpt-5.4-mini") ?: "gpt-5.4-mini"
        set(v) { sp.edit().putString("aiModel", v).apply() }

    var useAi: Boolean
        get() = sp.getBoolean("useAi", false)
        set(v) { sp.edit().putBoolean("useAi", v).apply() }

    var useCalendar: Boolean
        get() = sp.getBoolean("useCalendar", false)
        set(v) { sp.edit().putBoolean("useCalendar", v).apply() }

    /** Agenda escolhida para criar compromissos (-1 = automática). */
    var calendarId: Long
        get() = sp.getLong("calendarId", -1L)
        set(v) { sp.edit().putLong("calendarId", v).apply() }

    /** Assuntos sigilosos, separados por vírgula. */
    var sigilos: String
        get() = sp.getString("sigilos", "Consultório") ?: "Consultório"
        set(v) { sp.edit().putString("sigilos", v).apply() }

    /** Nomes importados da agenda do WhatsApp: contam como sigilosos (um por linha). */
    var patients: String
        get() = sp.getString("patients", "") ?: ""
        set(v) { sp.edit().putString("patients", v).apply() }

    fun addPatients(names: List<String>) {
        val cur = patients.split("\n").filter { it.isNotBlank() }.toMutableSet()
        cur.addAll(names.map { it.trim() }.filter { it.isNotEmpty() })
        patients = cur.joinToString("\n")
    }

    /** Assuntos sigilosos escolhidos + nomes importados. */
    fun sigiloList(): List<String> =
        sigilos.split(",").map { it.trim() }.filter { it.isNotEmpty() } +
            patients.split("\n").map { it.trim() }.filter { it.isNotEmpty() }
}
