package br.com.rodripsi.memoria

import android.Manifest
import android.content.ClipData
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PersistableBundle
import android.provider.Settings
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private val vm: MemoriaVM by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MemoriaTheme { Screen(vm) } }
        handleIntent(intent)
        addOnNewIntentListener { handleIntent(it) }
    }

    override fun onResume() {
        super.onResume()
        vm.reload()
    }

    private fun handleIntent(i: Intent?) {
        if (i != null && i.action == Intent.ACTION_SEND) {
            val t = i.getStringExtra(Intent.EXTRA_TEXT)
            i.action = null
            if (!t.isNullOrBlank()) vm.handle(t)
        }
        val id = i?.getStringExtra(Notifier.EXTRA_FOCUS)
        if (id != null) {
            vm.focusReminder(id)
            i?.removeExtra(Notifier.EXTRA_FOCUS)
        }
    }
}

private fun copySensitive(ctx: Context, text: String) {
    val cm = ctx.getSystemService(ClipboardManager::class.java)
    val clip = ClipData.newPlainText("Memória", text)
    if (Build.VERSION.SDK_INT >= 33) {
        clip.description.extras = PersistableBundle().apply {
            putBoolean(ClipDescription.EXTRA_IS_SENSITIVE, true)
        }
    }
    cm.setPrimaryClip(clip)
}

private fun readClipboard(ctx: Context): String? {
    val cm = ctx.getSystemService(ClipboardManager::class.java)
    val clip = cm.primaryClip ?: return null
    if (clip.itemCount == 0) return null
    return clip.getItemAt(0).coerceToText(ctx)?.toString()
}

private fun openExact(ctx: Context) {
    try {
        if (Build.VERSION.SDK_INT >= 31) {
            ctx.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + ctx.packageName)))
        }
    } catch (e: Exception) {
        // tela indisponível neste aparelho
    }
}

private fun openBattery(ctx: Context) {
    try {
        ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
    } catch (e: Exception) {
        // tela indisponível neste aparelho
    }
}

@Composable
fun MemoriaTheme(content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        primary = Color(0xFFE3B15C), onPrimary = Color(0xFF1A1405),
        secondary = Color(0xFF59B6FF), onSecondary = Color(0xFF06101F),
        background = Color(0xFF0A1022), onBackground = Color(0xFFEDE6D6),
        surface = Color(0xFF141C36), onSurface = Color(0xFFEDE6D6),
        onSurfaceVariant = Color(0xFFB9B2A0), outline = Color(0xFF5B6280),
        error = Color(0xFFFF8A80)
    )
    MaterialTheme(colorScheme = scheme, content = content)
}

private fun metaLine(m: Memory): String {
    val parts = ArrayList<String>()
    if (m.subject.isNotBlank()) parts.add(m.subject)
    if (m.people.isNotEmpty()) parts.add(m.people.joinToString(", "))
    if (m.type != "fato") parts.add(m.type)
    val r = m.remindAt
    if (r != null) parts.add("lembrete " + whenLabel(r).lowercase())
    if (m.done) parts.add("feito")
    return parts.joinToString(" · ")
}

@Composable
fun Screen(vm: MemoriaVM) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var typed by remember { mutableStateOf("") }
    var showConfig by remember { mutableStateOf(false) }
    var showCals by remember { mutableStateOf(false) }
    var keyField by remember { mutableStateOf(vm.apiKey) }
    var idField by remember { mutableStateOf(vm.voiceId) }
    var modelField by remember { mutableStateOf(vm.model) }
    var aiKeyField by remember { mutableStateOf(vm.aiKey) }
    var aiModelField by remember { mutableStateOf(vm.aiModel) }
    var sigField by remember { mutableStateOf(vm.sigilos) }

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) vm.toggleListening() else vm.permissionDenied()
    }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
    val calLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        vm.changeCalendar(res.values.all { it })
    }

    fun onMic() {
        val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (granted) vm.toggleListening() else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    fun send() {
        val t = typed
        typed = ""
        if (t.isNotBlank()) vm.handle(t)
    }

    fun doSave() {
        vm.saveAll(keyField, idField, modelField, aiKeyField, aiModelField, sigField)
    }

    val colors = MaterialTheme.colorScheme
    val micColor = when {
        vm.listening -> colors.secondary
        vm.speaking -> colors.onBackground
        else -> colors.primary
    }
    val subjects = vm.memories.map { it.subject }.filter { it.isNotBlank() }.distinct()
    val shown = vm.memories
        .filter { vm.filter == null || it.subject.equals(vm.filter, ignoreCase = true) }
        .reversed()

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(colors.background),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 28.dp)
    ) {
        item {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Image(
                    painter = painterResource(R.drawable.banner),
                    contentDescription = "Memória",
                    modifier = Modifier.widthIn(max = 460.dp).fillMaxWidth().clip(RoundedCornerShape(20.dp)),
                    contentScale = ContentScale.FillWidth
                )
                Text(
                    "Memória", fontSize = 38.sp, fontFamily = FontFamily.Serif,
                    color = colors.primary, modifier = Modifier.padding(top = 16.dp)
                )
                Text(
                    "Fale e eu organizo. Pergunte e eu respondo em voz alta.",
                    color = colors.onBackground.copy(alpha = 0.75f), textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 4.dp, bottom = 28.dp)
                )
            }
        }

        item {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    modifier = Modifier
                        .size(148.dp)
                        .clip(CircleShape)
                        .background(micColor)
                        .semantics { contentDescription = if (vm.listening) "Parar de ouvir" else "Falar" }
                        .clickable { onMic() },
                    contentAlignment = Alignment.Center
                ) {
                    Text("🎤", fontSize = 56.sp)
                }
                Spacer(Modifier.height(16.dp))
                Text(vm.status, fontWeight = FontWeight.Bold, color = colors.onBackground, textAlign = TextAlign.Center)
                val vn = vm.voiceNote
                if (vn != null) {
                    Text(
                        vn, color = colors.error, fontSize = 13.sp, textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }
                if (vm.heard.isNotEmpty()) {
                    Text(
                        vm.heard,
                        color = colors.onBackground.copy(alpha = 0.7f),
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }
                Button(onClick = { vm.myDay() }, modifier = Modifier.padding(top = 16.dp)) {
                    Text("Meu dia")
                }
            }
        }

        val head = vm.answerHead
        if (head != null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = colors.surface),
                    modifier = Modifier.fillMaxWidth().padding(top = 18.dp)
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text(head, color = colors.onSurface, fontSize = 17.sp)
                        vm.answerLines.forEach { line ->
                            Text(line, color = colors.onSurface, fontSize = 16.sp, modifier = Modifier.padding(top = 8.dp))
                        }
                        if (vm.importing) {
                            Row(Modifier.padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { vm.confirmImport() }) { Text("Lançar na agenda") }
                                OutlinedButton(onClick = { vm.cancelImport() }) { Text("Cancelar") }
                            }
                        }
                        vm.answerItems.forEach { m ->
                            Text(
                                whenLabel(m.ts),
                                color = colors.primary, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(top = 12.dp)
                            )
                            val meta = metaLine(m)
                            if (meta.isNotEmpty()) Text(meta, color = colors.primary, fontSize = 13.sp)
                            Text(m.text, color = colors.onSurface, fontSize = 17.sp)
                        }
                    }
                }
            }
        }

        item {
            Column {
                Row(
                    Modifier.fillMaxWidth().padding(top = 22.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = typed,
                        onValueChange = { typed = it },
                        placeholder = { Text("Ou escreva ou cole aqui") },
                        singleLine = false,
                        maxLines = 4,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(onSend = { send() }),
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = { send() }) { Text("Enviar") }
                }
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(top = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(onClick = { vm.handle("Amanhã às 9 levar a Marina no médico") }) { Text("Amanhã às 9 levar a Marina…") }
                    OutlinedButton(onClick = { vm.handle("O que guardei hoje?") }) { Text("O que guardei hoje?") }
                    OutlinedButton(onClick = { vm.handle("O que tenho com a Marina?") }) { Text("O que tenho com a Marina?") }
                }
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = vm.loop, onCheckedChange = { vm.loop = it })
                    Text("Continuar ouvindo depois de responder", color = colors.onBackground)
                }
                Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = vm.useAi, onCheckedChange = { vm.changeAi(it) })
                    Text("  Usar IA para organizar", color = colors.onBackground)
                }
                Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = vm.useMyVoice, onCheckedChange = { vm.changeMyVoice(it) })
                    Text("  Usar minha voz (ElevenLabs)", color = colors.onBackground)
                }
                Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Switch(
                        checked = vm.useCalendar,
                        onCheckedChange = { on ->
                            if (!on) vm.changeCalendar(false)
                            else if (Agenda.hasPermission(ctx)) vm.changeCalendar(true)
                            else calLauncher.launch(
                                arrayOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR)
                            )
                        }
                    )
                    Text("  Ligar com o Google Agenda", color = colors.onBackground)
                }
            }
        }

        item {
            Column {
                Text(
                    "Memórias guardadas" + if (vm.memories.isNotEmpty()) " (${vm.memories.size})" else "",
                    fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = colors.onBackground,
                    modifier = Modifier.padding(top = 32.dp, bottom = 8.dp)
                )
                if (subjects.isNotEmpty()) {
                    Row(
                        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(bottom = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (vm.filter == null) {
                            Button(onClick = { }) { Text("Todos") }
                        } else {
                            OutlinedButton(onClick = { vm.filter = null }) { Text("Todos") }
                        }
                        subjects.forEach { s ->
                            if (vm.filter == s) {
                                Button(onClick = { }) { Text(s) }
                            } else {
                                OutlinedButton(onClick = { vm.filter = s }) { Text(s) }
                            }
                        }
                    }
                }
                if (vm.memories.isEmpty()) {
                    Text(
                        "Nenhuma memória ainda. Toque no microfone e diga, por exemplo: “amanhã às 9 levar a Marina no médico”.",
                        color = colors.onBackground.copy(alpha = 0.7f)
                    )
                }
            }
        }

        items(shown, key = { it.id }) { m ->
            Column {
                HorizontalDivider(color = colors.onBackground.copy(alpha = 0.12f))
                Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.Top) {
                    Column(Modifier.weight(1f)) {
                        Text(whenLabel(m.ts), fontSize = 13.sp, color = colors.onBackground.copy(alpha = 0.7f))
                        val meta = metaLine(m)
                        if (meta.isNotEmpty()) Text(meta, fontSize = 13.sp, color = colors.primary)
                        Text(m.text, fontSize = 17.sp, color = colors.onBackground)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        if ((m.type == "tarefa" || m.type == "promessa" || m.type == "aguardando") && !m.done) {
                            TextButton(onClick = { vm.markDone(m.id) }) { Text("Feito") }
                        }
                        TextButton(onClick = { vm.delete(m.id) }) { Text("Apagar", color = colors.error) }
                    }
                }
            }
        }

        item {
            Column {
                OutlinedButton(onClick = { showConfig = !showConfig }, modifier = Modifier.padding(top = 20.dp)) {
                    Text(if (showConfig) "Fechar configurações" else "Configurações")
                }
                if (showConfig) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = colors.surface),
                        modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Text("Minha voz (ElevenLabs)", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = colors.onSurface)
                            Text(
                                "O texto de cada resposta é enviado ao ElevenLabs para virar áudio.",
                                fontSize = 13.sp, color = colors.onSurface.copy(alpha = 0.7f),
                                modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                            )
                            OutlinedTextField(
                                value = keyField, onValueChange = { keyField = it },
                                label = { Text("Chave da API (ElevenLabs)") }, singleLine = true,
                                visualTransformation = PasswordVisualTransformation(),
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(Modifier.height(8.dp))
                            OutlinedTextField(
                                value = idField, onValueChange = { idField = it },
                                label = { Text("ID da voz") }, singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                if (modelField == "eleven_flash_v2_5") {
                                    Button(onClick = { }) { Text("Rápido") }
                                } else {
                                    OutlinedButton(onClick = { modelField = "eleven_flash_v2_5" }) { Text("Rápido") }
                                }
                                if (modelField == "eleven_multilingual_v2") {
                                    Button(onClick = { }) { Text("Mais natural") }
                                } else {
                                    OutlinedButton(onClick = { modelField = "eleven_multilingual_v2" }) { Text("Mais natural") }
                                }
                            }

                            Text(
                                "IA (OpenAI)", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = colors.onSurface,
                                modifier = Modifier.padding(top = 24.dp)
                            )
                            Text(
                                "O que você diz (fora dos assuntos sigilosos) é enviado à OpenAI para organizar memórias e agenda.",
                                fontSize = 13.sp, color = colors.onSurface.copy(alpha = 0.7f),
                                modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                            )
                            OutlinedTextField(
                                value = aiKeyField, onValueChange = { aiKeyField = it },
                                label = { Text("Chave da API (OpenAI)") }, singleLine = true,
                                visualTransformation = PasswordVisualTransformation(),
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(Modifier.height(8.dp))
                            OutlinedTextField(
                                value = aiModelField, onValueChange = { aiModelField = it },
                                label = { Text("Modelo da IA") }, singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )

                            Text(
                                "Agenda", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = colors.onSurface,
                                modifier = Modifier.padding(top = 24.dp)
                            )
                            Text(
                                "Escolha em qual agenda os compromissos novos são criados.",
                                fontSize = 13.sp, color = colors.onSurface.copy(alpha = 0.7f),
                                modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                            )
                            OutlinedButton(onClick = { vm.loadCalendars(); showCals = !showCals }) {
                                Text(if (showCals) "Fechar lista" else "Escolher agenda")
                            }
                            if (showCals) {
                                if (vm.calendarOptions.isEmpty()) {
                                    Text(
                                        "Nenhuma agenda com escrita encontrada. Ligue o Google Agenda primeiro.",
                                        fontSize = 13.sp, color = colors.error, modifier = Modifier.padding(top = 8.dp)
                                    )
                                }
                                vm.calendarOptions.forEach { o ->
                                    if (o.id == vm.calendarId) {
                                        Button(onClick = { }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp)) { Text(o.label) }
                                    } else {
                                        OutlinedButton(
                                            onClick = { vm.pickCalendar(o.id) },
                                            modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
                                        ) { Text(o.label) }
                                    }
                                }
                            }

                            Text(
                                "Lembretes", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = colors.onSurface,
                                modifier = Modifier.padding(top = 24.dp)
                            )
                            Text(
                                "Para o aviso tocar na hora certa, permita alarmes exatos e libere o Memória da economia de bateria.",
                                fontSize = 13.sp, color = colors.onSurface.copy(alpha = 0.7f),
                                modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { openExact(ctx) }) { Text("Alarmes exatos") }
                                OutlinedButton(onClick = { openBattery(ctx) }) { Text("Bateria") }
                            }

                            Text(
                                "Sigilo", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = colors.onSurface,
                                modifier = Modifier.padding(top = 24.dp)
                            )
                            Text(
                                "Assuntos que nunca vão à IA, ao ElevenLabs nem à agenda. Separe por vírgula. Palavras como paciente e atendimento já valem sempre.",
                                fontSize = 13.sp, color = colors.onSurface.copy(alpha = 0.7f),
                                modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                            )
                            OutlinedTextField(
                                value = sigField, onValueChange = { sigField = it },
                                label = { Text("Assuntos sigilosos") }, singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )

                            Text(
                                "Backup das configurações", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = colors.onSurface,
                                modifier = Modifier.padding(top = 24.dp)
                            )
                            Text(
                                "Copia as suas chaves e ajustes num texto, para colar de volta depois de reinstalar o app. Guarde esse texto num lugar seguro e não o envie a ninguém.",
                                fontSize = 13.sp, color = colors.onSurface.copy(alpha = 0.7f),
                                modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = {
                                    copySensitive(ctx, vm.exportSettings())
                                    vm.note("Configurações copiadas. Guarde num lugar seguro.")
                                }) { Text("Copiar configurações") }
                                OutlinedButton(onClick = {
                                    val t = readClipboard(ctx)
                                    if (t != null && vm.importSettings(t)) {
                                        keyField = vm.apiKey
                                        idField = vm.voiceId
                                        modelField = vm.model
                                        aiKeyField = vm.aiKey
                                        aiModelField = vm.aiModel
                                        sigField = vm.sigilos
                                    } else {
                                        vm.note("Não achei configurações válidas na área de transferência.")
                                    }
                                }) { Text("Colar configurações") }
                            }

                            Row(Modifier.padding(top = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { doSave() }) { Text("Salvar") }
                                OutlinedButton(onClick = { doSave(); vm.testVoice() }) { Text("Testar voz") }
                                OutlinedButton(onClick = { vm.testAgenda() }) { Text("Testar agenda") }
                            }
                        }
                    }
                }
                Row(Modifier.padding(top = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        copySensitive(ctx, vm.backupJson())
                        vm.note("Backup das memórias copiado. Guarde num lugar seguro.")
                    }) { Text("Copiar backup") }
                    OutlinedButton(onClick = {
                        val t = readClipboard(ctx)
                        val n = if (t == null) -1 else vm.restoreBackup(t)
                        vm.note(if (n >= 0) "Memórias restauradas: " + n + "." else "Não achei um backup válido na área de transferência.")
                    }) { Text("Restaurar backup") }
                }
                Text(
                    "As memórias ficam só neste aparelho. Comandos: “guarda que…”, “o que guardei ontem?”, “meu dia”, “apaga a última”, “ajuda”.",
                    fontSize = 13.sp, color = colors.onBackground.copy(alpha = 0.7f),
                    modifier = Modifier.padding(top = 20.dp)
                )
            }
        }
    }
}
