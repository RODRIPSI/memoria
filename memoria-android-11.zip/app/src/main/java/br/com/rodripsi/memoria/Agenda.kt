package br.com.rodripsi.memoria

import android.Manifest
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.CalendarContract
import androidx.core.content.ContextCompat
import java.time.Instant
import java.time.ZoneId
import java.time.ZoneOffset
import java.util.TimeZone

/** Lê e cria compromissos na agenda do aparelho (a do Google, se estiver configurada). */
data class CalOption(val id: Long, val label: String)

object Agenda {

    fun hasPermission(ctx: Context): Boolean =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_CALENDAR) == PackageManager.PERMISSION_GRANTED

    /** Compromissos que tocam o intervalo. Cancelados e recusados ficam de fora. */
    fun events(ctx: Context, from: Long, to: Long): List<AgendaItem> {
        if (!hasPermission(ctx)) return emptyList()
        val b = CalendarContract.Instances.CONTENT_URI.buildUpon()
        ContentUris.appendId(b, from)
        ContentUris.appendId(b, to)
        val uri = b.build()
        val full = arrayOf(
            CalendarContract.Instances.TITLE,
            CalendarContract.Instances.BEGIN,
            CalendarContract.Instances.END,
            CalendarContract.Instances.ALL_DAY,
            CalendarContract.Events.AVAILABILITY,
            CalendarContract.Events.STATUS,
            CalendarContract.Events.SELF_ATTENDEE_STATUS
        )
        val out: List<AgendaItem> = try {
            read(ctx, uri, full, true)
        } catch (e: Exception) {
            try {
                read(ctx, uri, full.copyOfRange(0, 4), false)
            } catch (e2: Exception) {
                emptyList()
            }
        }
        return out.sortedBy { it.start }
    }

    private fun read(ctx: Context, uri: Uri, proj: Array<String>, extended: Boolean): List<AgendaItem> {
        val out = ArrayList<AgendaItem>()
        val z = ZoneId.systemDefault()
        ctx.contentResolver.query(uri, proj, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val allDay = c.getInt(3) == 1
                var start = c.getLong(1)
                var end = c.getLong(2)
                if (allDay) {
                    // eventos de dia inteiro vêm em UTC: converte para o dia local certo
                    start = Instant.ofEpochMilli(start).atZone(ZoneOffset.UTC).toLocalDate()
                        .atStartOfDay(z).toInstant().toEpochMilli()
                    end = Instant.ofEpochMilli(end).atZone(ZoneOffset.UTC).toLocalDate()
                        .atStartOfDay(z).toInstant().toEpochMilli()
                }
                var busy = true
                if (extended) {
                    val availability = if (c.isNull(4)) 0 else c.getInt(4)
                    val status = if (c.isNull(5)) 0 else c.getInt(5)
                    val self = if (c.isNull(6)) 0 else c.getInt(6)
                    if (status == CalendarContract.Events.STATUS_CANCELED) continue
                    if (self == CalendarContract.Attendees.ATTENDEE_STATUS_DECLINED) continue
                    busy = availability != CalendarContract.Events.AVAILABILITY_FREE
                }
                out.add(AgendaItem(c.getString(0) ?: "(sem título)", start, end, allDay, busy))
            }
        }
        return out
    }

    private data class Cal(val id: Long, val label: String)

    /** Agendas em que dá para criar compromissos (para o usuário escolher). */
    fun writableCalendars(ctx: Context): List<CalOption> {
        if (!hasPermission(ctx)) return emptyList()
        val out = ArrayList<CalOption>()
        try {
            val proj = arrayOf(
                CalendarContract.Calendars._ID,
                CalendarContract.Calendars.CALENDAR_DISPLAY_NAME,
                CalendarContract.Calendars.ACCOUNT_NAME
            )
            ctx.contentResolver.query(
                CalendarContract.Calendars.CONTENT_URI,
                proj,
                CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL + " >= ?",
                arrayOf(CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR.toString()),
                null
            )?.use { c ->
                while (c.moveToNext()) {
                    out.add(CalOption(c.getLong(0), (c.getString(1) ?: "?") + " — " + (c.getString(2) ?: "?")))
                }
            }
        } catch (e: Exception) {
            // sem acesso
        }
        return out
    }

    private fun chooseCalendar(ctx: Context): Cal? {
        val saved = Config(ctx).calendarId
        if (saved >= 0) {
            val opt = writableCalendars(ctx).firstOrNull { it.id == saved }
            if (opt != null) return Cal(opt.id, opt.label)
        }
        val proj = arrayOf(
            CalendarContract.Calendars._ID,
            CalendarContract.Calendars.ACCOUNT_TYPE,
            CalendarContract.Calendars.ACCOUNT_NAME,
            CalendarContract.Calendars.OWNER_ACCOUNT
        )
        var best: Cal? = null
        var bestScore = -1
        ctx.contentResolver.query(
            CalendarContract.Calendars.CONTENT_URI,
            proj,
            CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL + " >= ?",
            arrayOf(CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR.toString()),
            null
        )?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                val type = c.getString(1) ?: ""
                val acc = c.getString(2) ?: ""
                val owner = c.getString(3) ?: ""
                var score = 0
                if (type == "com.google") score += 2
                if (owner == acc) score += 1
                if (score > bestScore) {
                    bestScore = score
                    best = Cal(id, acc + " (" + type + ")")
                }
            }
        }
        return best
    }

    fun addEvent(
        ctx: Context,
        title: String,
        startMs: Long,
        durationMin: Int,
        reminderMin: Int?,
        description: String
    ): Boolean {
        if (!hasPermission(ctx)) return false
        return try {
            val cal = chooseCalendar(ctx) ?: return false
            val values = ContentValues().apply {
                put(CalendarContract.Events.DTSTART, startMs)
                put(CalendarContract.Events.DTEND, startMs + durationMin * 60_000L)
                put(CalendarContract.Events.TITLE, title)
                put(CalendarContract.Events.DESCRIPTION, description)
                put(CalendarContract.Events.CALENDAR_ID, cal.id)
                put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().id)
                put(CalendarContract.Events.HAS_ALARM, if (reminderMin != null) 1 else 0)
            }
            val uri = ctx.contentResolver.insert(CalendarContract.Events.CONTENT_URI, values) ?: return false
            val evId = uri.lastPathSegment?.toLongOrNull()
            if (evId != null && reminderMin != null) {
                val r = ContentValues().apply {
                    put(CalendarContract.Reminders.EVENT_ID, evId)
                    put(CalendarContract.Reminders.MINUTES, reminderMin)
                    put(CalendarContract.Reminders.METHOD, CalendarContract.Reminders.METHOD_ALERT)
                }
                ctx.contentResolver.insert(CalendarContract.Reminders.CONTENT_URI, r)
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Texto de diagnóstico para a tela: quais agendas existem e qual será usada. */
    fun info(ctx: Context): List<String> {
        if (!hasPermission(ctx)) return listOf("Sem permissão da agenda.")
        val lines = ArrayList<String>()
        try {
            val proj = arrayOf(
                CalendarContract.Calendars.CALENDAR_DISPLAY_NAME,
                CalendarContract.Calendars.ACCOUNT_NAME,
                CalendarContract.Calendars.ACCOUNT_TYPE,
                CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL,
                CalendarContract.Calendars.VISIBLE
            )
            var n = 0
            ctx.contentResolver.query(CalendarContract.Calendars.CONTENT_URI, proj, null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    n++
                    val w = if (c.getInt(3) >= CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR) "escrita sim" else "só leitura"
                    val v = if (c.getInt(4) == 1) "visível" else "oculta"
                    lines.add("• " + (c.getString(0) ?: "?") + " — " + (c.getString(1) ?: "?") + " (" + (c.getString(2) ?: "?") + "), " + w + ", " + v)
                }
            }
            if (n == 0) lines.add("Nenhuma agenda encontrada no aparelho.")
            val chosen = chooseCalendar(ctx)
            lines.add("Para criar compromissos o app usa: " + (chosen?.label ?: "nenhuma (sem agenda com escrita)"))
            val now = System.currentTimeMillis()
            val evs = events(ctx, now, now + 7 * 86_400_000L)
            lines.add("Compromissos nos próximos 7 dias: " + evs.size + " (" + evs.count { it.allDay } + " de dia inteiro)")
        } catch (e: Exception) {
            lines.add("Erro ao ler a agenda: " + (e.message ?: e.javaClass.simpleName))
        }
        return lines
    }
}
