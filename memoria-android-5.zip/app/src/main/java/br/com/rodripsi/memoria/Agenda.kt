package br.com.rodripsi.memoria

import android.Manifest
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CalendarContract
import androidx.core.content.ContextCompat
import java.util.TimeZone

/** Lê e cria compromissos na agenda do aparelho (a do Google, se estiver configurada). */
object Agenda {

    fun hasPermission(ctx: Context): Boolean =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_CALENDAR) == PackageManager.PERMISSION_GRANTED

    fun events(ctx: Context, from: Long, to: Long): List<AgendaItem> {
        if (!hasPermission(ctx)) return emptyList()
        val out = ArrayList<AgendaItem>()
        try {
            val b = CalendarContract.Instances.CONTENT_URI.buildUpon()
            ContentUris.appendId(b, from)
            ContentUris.appendId(b, to)
            val proj = arrayOf(
                CalendarContract.Instances.TITLE,
                CalendarContract.Instances.BEGIN,
                CalendarContract.Instances.END,
                CalendarContract.Instances.ALL_DAY
            )
            ctx.contentResolver.query(b.build(), proj, null, null, CalendarContract.Instances.BEGIN + " ASC")?.use { c ->
                while (c.moveToNext()) {
                    out.add(AgendaItem(c.getString(0) ?: "(sem título)", c.getLong(1), c.getLong(2), c.getInt(3) == 1))
                }
            }
        } catch (e: Exception) {
            // sem acesso: devolve o que tiver
        }
        return out
    }

    private fun calendarId(ctx: Context): Long? {
        val proj = arrayOf(
            CalendarContract.Calendars._ID,
            CalendarContract.Calendars.ACCOUNT_TYPE,
            CalendarContract.Calendars.ACCOUNT_NAME,
            CalendarContract.Calendars.OWNER_ACCOUNT
        )
        var best: Long? = null
        var bestScore = -1
        ctx.contentResolver.query(
            CalendarContract.Calendars.CONTENT_URI,
            proj,
            CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL + " >= ?",
            arrayOf(CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR.toString()),
            null
        )?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                val type = c.getString(1) ?: ""
                val acc = c.getString(2) ?: ""
                val owner = c.getString(3) ?: ""
                var score = 0
                if (type == "com.google") score += 2
                if (owner == acc) score += 1
                if (score > bestScore) {
                    bestScore = score
                    best = id
                }
            }
        }
        return best
    }

    fun addEvent(
        ctx: Context,
        title: String,
        startMs: Long,
        durationMin: Int,
        reminderMin: Int?,
        description: String
    ): Boolean {
        if (!hasPermission(ctx)) return false
        return try {
            val calId = calendarId(ctx) ?: return false
            val values = ContentValues().apply {
                put(CalendarContract.Events.DTSTART, startMs)
                put(CalendarContract.Events.DTEND, startMs + durationMin * 60_000L)
                put(CalendarContract.Events.TITLE, title)
                put(CalendarContract.Events.DESCRIPTION, description)
                put(CalendarContract.Events.CALENDAR_ID, calId)
                put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().id)
                put(CalendarContract.Events.HAS_ALARM, if (reminderMin != null) 1 else 0)
            }
            val uri = ctx.contentResolver.insert(CalendarContract.Events.CONTENT_URI, values) ?: return false
            val evId = uri.lastPathSegment?.toLongOrNull()
            if (evId != null && reminderMin != null) {
                val r = ContentValues().apply {
                    put(CalendarContract.Reminders.EVENT_ID, evId)
                    put(CalendarContract.Reminders.MINUTES, reminderMin)
                    put(CalendarContract.Reminders.METHOD, CalendarContract.Reminders.METHOD_ALERT)
                }
                ctx.contentResolver.insert(CalendarContract.Reminders.CONTENT_URI, r)
            }
            true
        } catch (e: Exception) {
            false
        }
    }
}
