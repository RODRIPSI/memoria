package br.com.rodripsi.memoria

import android.app.Application
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.UUID

private enum class Pending { SAVE, DELETE }

class MemoriaVM(app: Application) : AndroidViewModel(app) {

    private val store = Store(app)
    private val config = Config(app)
    private val main = Handler(Looper.getMainLooper())

    var memories by mutableStateOf(store.load())
        private set
    var status by mutableStateOf("Toque para falar")
        private set
    var heard by mutableStateOf("")
        private set
    var answerHead by mutableStateOf<String?>(null)
        private set
    var answerItems by mutableStateOf<List<Memory>>(emptyList())
        private set
    var answerLines by mutableStateOf<List<String>>(emptyList())
        private set
    var listening by mutableStateOf(false)
        private set
    var speaking by mutableStateOf(false)
        private set
    var loop by mutableStateOf(false)
    var filter by mutableStateOf<String?>(null)

    // voz do ElevenLabs
    var apiKey: String = config.apiKey
        private set
    var voiceId: String = config.voiceId
        private set
    var model: String = config.model
        private set
    var useMyVoice by mutableStateOf(config.useMyVoice)
        private set

    // IA, agenda e sigilo
    var aiKey: String = config.aiKey
        private set
    var aiModel: String = config.aiModel
        private set
    var useAi by mutableStateOf(config.useAi)
        private set
    var useCalendar by mutableStateOf(config.useCalendar)
        private set
    var sigilos: String = config.sigilos
        private set

    var voiceNote by mutableStateOf<String?>(null)
        private set

    private var pending: Pending? = null
    private var lastError = false
    private var listenAfter = false
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var currentUtt: String? = null
    private var player: MediaPlayer? = null
    private val chat = ArrayList<Pair<String, String>>()
    private var lastChatAt = 0L

    init {
        tts = TextToSpeech(app) { st ->
            if (st == TextToSpeech.SUCCESS) {
                val res = tts?.setLanguage(Locale("pt", "BR"))
                ttsReady = res != TextToSpeech.LANG_MISSING_DATA && res != TextToSpeech.LANG_NOT_SUPPORTED
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        main.post { if (utteranceId == currentUtt) { speaking = true; status = "Falando…" } }
                    }
                    override fun onDone(utteranceId: String?) {
                        main.post { if (utteranceId == currentUtt) finishSpeaking() }
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        main.post { if (utteranceId == currentUtt) finishSpeaking() }
                    }
                })
            }
        }
    }

    private fun sigiloList(): List<String> =
        sigilos.split(",").map { it.trim() }.filter { it.isNotEmpty() }

    // ---------- configuração ----------

    fun saveAll(elKey: String, elId: String, elModel: String, openKey: String, openModel: String, sig: String) {
        val firstVoice = apiKey.isBlank() || voiceId.isBlank()
        val firstAi = aiKey.isBlank()
        apiKey = elKey.trim()
        voiceId = elId.trim()
        model = elModel
        aiKey = openKey.trim()
        aiModel = openModel.trim().ifEmpty { "gpt-5.4-mini" }
        sigilos = sig.trim()
        config.apiKey = apiKey
        config.voiceId = voiceId
        config.model = model
        config.aiKey = aiKey
        config.aiModel = aiModel
        config.sigilos = sigilos
        if (firstVoice && apiKey.isNotEmpty() && voiceId.isNotEmpty()) changeMyVoice(true)
        if (firstAi && aiKey.isNotEmpty()) changeAi(true)
        voiceNote = null
        status = "Configuração salva."
    }

    fun changeMyVoice(v: Boolean) {
        useMyVoice = v
        config.useMyVoice = v
        voiceNote = if (v && (apiKey.isBlank() || voiceId.isBlank()))
            "Preencha a chave e o ID da voz, em Configurações, e toque em Salvar." else null
    }

    fun changeAi(v: Boolean) {
        useAi = v
        config.useAi = v
        voiceNote = if (v && aiKey.isBlank())
            "Cole a chave da IA, em Configurações, e toque em Salvar." else null
    }

    fun changeCalendar(v: Boolean) {
        val ok = v && Agenda.hasPermission(getApplication<Application>())
        useCalendar = ok
        config.useCalendar = ok
        voiceNote = if (v && !ok)
            "Sem permissão da agenda. Libere em Configurações do Android > Apps > Memória > Permissões." else null
    }

    fun testVoice() {
        if (apiKey.isBlank() || voiceId.isBlank()) {
            voiceNote = "Preencha a chave e o ID da voz."
            return
        }
        stopSpeaking()
        speak("Olá! Esta é a minha voz no aplicativo Memória.", true, false)
    }

    // ---------- voz: saída ----------

    private fun speak(text: String, forceEleven: Boolean, forceAndroid: Boolean) {
        val id = "u" + System.nanoTime()
        currentUtt = id
        speaking = true
        val wantEleven = (useMyVoice || forceEleven) && apiKey.isNotBlank() && voiceId.isNotBlank() && !forceAndroid
        if (wantEleven) {
            status = "Gerando voz…"
            speakEleven(text, id)
        } else {
            speakAndroid(text, id)
        }
    }

    private fun speakAndroid(text: String, id: String) {
        if (!ttsReady) {
            speaking = false
            currentUtt = null
            status = "Toque para falar"
            return
        }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
    }

    private fun speakEleven(text: String, id: String) {
        val key = apiKey
        val voice = voiceId
        val mdl = model
        val cache = File(getApplication<Application>().cacheDir, "voz.mp3")
        Thread {
            var err: String? = null
            try {
                val url = URL(
                    "https://api.elevenlabs.io/v1/text-to-speech/" +
                        URLEncoder.encode(voice, "UTF-8") + "?output_format=mp3_44100_128"
                )
                val c = url.openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.connectTimeout = 15000
                c.readTimeout = 40000
                c.doOutput = true
                c.setRequestProperty("xi-api-key", key)
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("Accept", "audio/mpeg")
                val body = JSONObject().put("text", text).put("model_id", mdl).toString()
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                val code = c.responseCode
                if (code == 200) {
                    c.inputStream.use { input -> cache.outputStream().use { out -> input.copyTo(out) } }
                } else {
                    err = when (code) {
                        401 -> "Chave do ElevenLabs inválida ou sem créditos."
                        429 -> "Limite do ElevenLabs atingido. Tente de novo em instantes."
                        400, 404, 422 -> "ID da voz ou modelo inválido (código $code)."
                        else -> "O ElevenLabs recusou o pedido (código $code)."
                    }
                }
                c.disconnect()
            } catch (e: Exception) {
                err = "Sem conexão com o ElevenLabs."
            }
            main.post {
                if (id == currentUtt) {
                    if (err != null) {
                        voiceNote = err + " Usei a voz do Android."
                        speakAndroid(text, id)
                    } else {
                        playFile(cache, id, text)
                    }
                }
            }
        }.start()
    }

    private fun releasePlayer() {
        try { player?.release() } catch (e: Exception) { }
        player = null
    }

    private fun playFile(f: File, id: String, text: String) {
        releasePlayer()
        try {
            val p = MediaPlayer()
            p.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            p.setDataSource(f.absolutePath)
            p.setOnPreparedListener { mp ->
                if (id == currentUtt) { status = "Falando…"; mp.start() }
            }
            p.setOnCompletionListener {
                releasePlayer()
                if (id == currentUtt) finishSpeaking()
            }
            p.setOnErrorListener { _, _, _ ->
                releasePlayer()
                if (id == currentUtt) {
                    voiceNote = "Não consegui tocar o áudio. Usei a voz do Android."
                    speakAndroid(text, id)
                }
                true
            }
            player = p
            p.prepareAsync()
        } catch (e: Exception) {
            releasePlayer()
            speakAndroid(text, id)
        }
    }

    private fun finishSpeaking() {
        if (!speaking) return
        speaking = false
        currentUtt = null
        status = "Toque para falar"
        val again = (loop || listenAfter) && !lastError
        listenAfter = false
        if (again) startListening()
    }

    private fun stopSpeaking() {
        currentUtt = null
        speaking = false
        releasePlayer()
        tts?.stop()
    }

    // ---------- voz: entrada ----------

    fun toggleListening() {
        if (listening) recognizer?.stopListening() else startListening()
    }

    fun permissionDenied() {
        status = "Sem permissão do microfone. Libere em Configurações > Apps > Memória > Permissões."
    }

    private fun startListening() {
        val ctx = getApplication<Application>()
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            status = "Este aparelho não tem reconhecimento de voz disponível."
            return
        }
        stopSpeaking()
        lastError = false
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { listening = true; status = "Ouvindo…"; heard = "" }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onPartialResults(partialResults: Bundle?) {
                val p = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!p.isNullOrBlank()) heard = p
            }
            override fun onResults(results: Bundle?) {
                listening = false
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t.isNullOrBlank()) status = "Não entendi. Toque e tente de novo." else handle(t)
            }
            override fun onError(error: Int) {
                listening = false
                lastError = true
                status = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                        "Não ouvi nada. Toque e tente de novo."
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                        "Sem permissão do microfone."
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                        "Sem internet e sem pacote de voz offline em português. Baixe-o nas configurações de voz do Google."
                    else -> "Erro de reconhecimento (código $error). Tente de novo."
                }
            }
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        recognizer = r
        r.startListening(intent)
    }

    // ---------- lógica ----------

    private fun reply(r: Reply, listenAfterSpeak: Boolean = false) {
        answerHead = r.head
        answerItems = r.items
        answerLines = r.lines
        listenAfter = listenAfterSpeak
        val sig = sigiloList()
        val sensitive = r.sensitive || isSigiloso(r.spoken, sig) || r.items.any { isSigilosoMemory(it, sig) }
        speak(r.spoken, false, sensitive)
    }

    private fun addMemoryQuiet(m: AiMemory): Memory {
        val mem = Memory(
            UUID.randomUUID().toString(),
            m.text.trim().replaceFirstChar { it.uppercase() },
            System.currentTimeMillis(),
            m.subject.trim().replaceFirstChar { it.uppercase() },
            m.people,
            m.type,
            m.remindAt
        )
        memories = memories + mem
        store.save(memories)
        return mem
    }

    private fun addMemory(raw: String, subject: String = "") {
        val m = addMemoryQuiet(AiMemory(raw, subject, emptyList(), "fato", null))
        reply(Reply("Guardado.", "Guardado.", listOf(m)))
    }

    fun myDay() {
        val ctx = getApplication<Application>()
        val zone = ZoneId.systemDefault()
        val today = LocalDate.now(zone)
        val from = today.atStartOfDay(zone).toInstant().toEpochMilli()
        val to = today.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli()
        val on = useCalendar && Agenda.hasPermission(ctx)
        val evs = if (on) Agenda.events(ctx, from, to) else emptyList()
        reply(buildDay(System.currentTimeMillis(), evs, memories, on, sigiloList()))
    }

    private fun busyLines(): List<String> {
        val ctx = getApplication<Application>()
        if (!useCalendar || !Agenda.hasPermission(ctx)) return emptyList()
        val now = System.currentTimeMillis()
        val z = ZoneId.systemDefault()
        val day = DateTimeFormatter.ofPattern("dd/MM")
        val full = DateTimeFormatter.ofPattern("dd/MM HH:mm")
        val hm = DateTimeFormatter.ofPattern("HH:mm")
        return Agenda.events(ctx, now, now + 7 * 86_400_000L).take(30).map {
            val s = Instant.ofEpochMilli(it.start).atZone(z)
            val e = Instant.ofEpochMilli(it.end).atZone(z)
            if (it.allDay) s.format(day) + " dia todo" else s.format(full) + "–" + e.format(hm)
        }
    }

    private fun askAi(text: String) {
        val now = System.currentTimeMillis()
        if (now - lastChatAt > 5 * 60_000L) chat.clear()
        lastChatAt = now
        status = "Pensando…"
        val sig = sigiloList()
        val pool = memories.filter { !isSigilosoMemory(it, sig) }
        val rel = searchList(pool, text, 5).ifEmpty { pool.takeLast(3) }
        val system = Ai.systemPrompt(
            ZonedDateTime.now(),
            pool.map { it.subject }.filter { it.isNotBlank() }.distinct(),
            pool.flatMap { it.people }.distinct(),
            busyLines(),
            rel
        )
        val key = aiKey
        val body = Ai.buildRequest(aiModel, system, chat.toList(), text)
        chat.add(Pair("user", text))
        Thread {
            var res: AiResult? = null
            var err: String? = null
            try {
                res = Ai.parseContent(Ai.extractContent(Ai.call(key, body)))
            } catch (e: AiException) {
                err = e.message
            } catch (e: Exception) {
                err = "Não consegui entender a resposta da IA."
            }
            main.post { onAi(text, res, err) }
        }.start()
    }

    private fun onAi(userText: String, res: AiResult?, err: String?) {
        if (res == null) {
            chat.clear()
            voiceNote = (err ?: "Não consegui falar com a IA.") + " Usei o modo simples."
            status = "Toque para falar"
            localHandle(parseCommand(userText))
            return
        }
        voiceNote = null
        var say = res.say
        val ev = res.event
        var mem = res.memory
        if (mem == null && ev != null) mem = AiMemory(ev.title, "", emptyList(), "tarefa", ev.startMs)
        var saved: Memory? = null
        if (mem != null) saved = addMemoryQuiet(mem)
        if (ev != null) {
            val ok = useCalendar && Agenda.addEvent(
                getApplication<Application>(), ev.title, ev.startMs, ev.durationMin, ev.reminderMin,
                "Criado pelo app Memória"
            )
            if (!ok) say += " Não consegui criar na agenda. Ligue a agenda nas configurações."
        }
        if (res.ask) {
            chat.add(Pair("assistant", res.say))
            while (chat.size > 10) chat.removeAt(0)
        } else {
            chat.clear()
        }
        reply(Reply(say, say, listOfNotNull(saved)), res.ask)
    }

    private fun localHandle(cmd: Command) {
        when (cmd) {
            is Command.Save -> addMemory(cmd.text, cmd.subject)
            is Command.AskSave -> { pending = Pending.SAVE; reply(Reply("O que devo guardar?"), true) }
            is Command.AskDelete -> {
                if (memories.isEmpty()) reply(Reply("Não há memórias para apagar."))
                else {
                    pending = Pending.DELETE
                    reply(Reply("Apagar a última memória: " + memories.last().text + ". Confirma? Diga sim ou não."), true)
                }
            }
            is Command.Help -> reply(Reply(
                "Para guardar, diga: guarda que, e o que quer lembrar. " +
                "Para perguntar, diga por exemplo: o que eu guardei ontem. " +
                "Para ouvir o seu dia, diga: meu dia. " +
                "Para apagar, diga: apaga a última."
            ))
            is Command.ListRecent -> reply(recent(memories))
            is Command.MyDay -> myDay()
            is Command.Ask -> reply(search(memories, cmd.text))
        }
    }

    fun handle(raw: String) {
        val text = raw.trim()
        if (text.isEmpty()) return
        heard = text
        val n = norm(text)

        if (pending == Pending.DELETE) {
            pending = null
            if (Regex("^(sim|pode|confirma|confirmo|isso)\\b").containsMatchIn(n) && memories.isNotEmpty()) {
                val gone = memories.last()
                memories = memories.dropLast(1)
                store.save(memories)
                reply(Reply("Apaguei a última memória.", "Apaguei: " + gone.text))
            } else {
                reply(Reply("Tudo bem, não apaguei nada."))
            }
            return
        }
        if (pending == Pending.SAVE) {
            pending = null
            if (Regex("^(cancela|cancelar|deixa|esquece|nao)\\b").containsMatchIn(n)) reply(Reply("Cancelado."))
            else addMemory(text)
            return
        }

        val cmd = parseCommand(text)
        val aiOk = useAi && aiKey.isNotBlank() &&
            (cmd is Command.Save || cmd is Command.Ask) &&
            !isSigiloso(text, sigiloList())
        if (aiOk) askAi(text) else localHandle(cmd)
    }

    fun markDone(id: String) {
        memories = memories.map { if (it.id == id) it.copy(done = true) else it }
        store.save(memories)
    }

    fun delete(id: String) {
        memories = memories.filter { it.id != id }
        store.save(memories)
    }

    fun backupJson(): String = Store.toJson(memories)

    fun note(t: String) { status = t }

    override fun onCleared() {
        releasePlayer()
        recognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onCleared()
    }
}
