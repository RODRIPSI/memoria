package br.com.rodripsi.memoria

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.util.UUID

/** Miniaturas de fotos e vídeos. O original continua na galeria; aqui fica só um quadradinho de ~360px. */
object Thumbs {
    private const val SIZE = 360

    fun dir(ctx: Context): File = File(ctx.filesDir, "midia").apply { mkdirs() }

    fun kindOf(ctx: Context, uri: Uri): String {
        val t = ctx.contentResolver.getType(uri) ?: ""
        return if (t.startsWith("video")) "video" else "image"
    }

    /** Cria a miniatura e devolve o nome do arquivo (ou null se não conseguiu). */
    fun make(ctx: Context, uri: Uri, kind: String): String? = try {
        val bmp: Bitmap? = if (kind == "video") videoFrame(ctx, uri) else imageThumb(ctx, uri)
        if (bmp == null) null else {
            val name = "m_" + UUID.randomUUID() + ".jpg"
            File(dir(ctx), name).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 82, it) }
            name
        }
    } catch (e: Exception) {
        null
    }

    private fun imageThumb(ctx: Context, uri: Uri): Bitmap? {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        var sample = 1
        while (opts.outWidth / (sample * 2) >= SIZE && opts.outHeight / (sample * 2) >= SIZE) sample *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = sample }
        val raw = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) } ?: return null
        val deg = try {
            ctx.contentResolver.openInputStream(uri)?.use {
                when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            } ?: 0f
        } catch (e: Exception) {
            0f
        }
        return scale(raw, deg)
    }

    private fun videoFrame(ctx: Context, uri: Uri): Bitmap? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, uri)
            val f = r.getFrameAtTime(1_000_000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: r.getFrameAtTime(0)
            f?.let { scale(it, 0f) }
        } finally {
            try { r.release() } catch (e: Exception) {}
        }
    }

    private fun scale(b: Bitmap, deg: Float): Bitmap {
        val k = SIZE.toFloat() / maxOf(b.width, b.height)
        val m = Matrix()
        if (k < 1f) m.postScale(k, k)
        if (deg != 0f) m.postRotate(deg)
        return Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
    }

    fun load(ctx: Context, name: String): Bitmap? =
        if (name.isBlank()) null else try { BitmapFactory.decodeFile(File(dir(ctx), name).path) } catch (e: Exception) { null }

    fun delete(ctx: Context, name: String) {
        if (name.isNotBlank()) try { File(dir(ctx), name).delete() } catch (e: Exception) {}
    }
}
