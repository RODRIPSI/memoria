package br.com.rodripsi.memoria

import android.content.Context
import java.io.File

/** Guarda as memórias num arquivo privado do app (não sai do aparelho). */
class Store(ctx: Context) {
    private val file = File(ctx.filesDir, "memorias.json")

    fun load(): List<Memory> = try {
        if (!file.exists()) emptyList() else fromJson(file.readText())
    } catch (e: Exception) {
        emptyList()
    }

    fun save(list: List<Memory>) {
        try {
            file.writeText(toJson(list))
        } catch (e: Exception) {
            // sem espaço ou erro de disco: ignora nesta versão
        }
    }

    companion object {
        fun fromJson(s: String): List<Memory> = MemoryJson.fromJson(s)
        fun toJson(list: List<Memory>): String = MemoryJson.toJson(list)
    }
}
