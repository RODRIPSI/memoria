package br.com.rodripsi.memoria

import java.io.File
import java.security.MessageDigest

/**
 * Guarda no aparelho os MP3 de frases curtas e repetidas ("Guardado."), para não gastar créditos do ElevenLabs de novo.
 * Chave = texto + voz + modelo. Teto de tamanho: apaga os mais antigos primeiro.
 * Frases longas (agenda do dia, respostas da IA) não entram: mudam toda vez.
 */
class AudioCache(private val dir: File, private val maxBytes: Long = 30L * 1024 * 1024) {
    companion object {
        const val MAX_CHARS = 80

        fun key(text: String, voice: String, model: String): String {
            val d = MessageDigest.getInstance("SHA-256").digest((text + "\u0000" + voice + "\u0000" + model).toByteArray(Charsets.UTF_8))
            return d.joinToString("") { "%02x".format(it) }
        }

        fun eligible(text: String): Boolean = text.isNotBlank() && text.length <= MAX_CHARS
    }

    private fun file(key: String) = File(dir, "$key.mp3")

    /** Devolve o arquivo guardado, ou null. Marca como usado recentemente. */
    fun get(text: String, voice: String, model: String): File? {
        if (!eligible(text)) return null
        val f = file(key(text, voice, model))
        if (!f.exists() || f.length() == 0L) return null
        f.setLastModified(System.currentTimeMillis())
        return f
    }

    /** Guarda uma cópia do áudio recém-gerado. */
    fun put(text: String, voice: String, model: String, source: File) {
        if (!eligible(text) || !source.exists() || source.length() == 0L) return
        try {
            dir.mkdirs()
            source.copyTo(file(key(text, voice, model)), overwrite = true)
            trim()
        } catch (e: Exception) {
            // cache é só economia: se falhar, segue sem ele
        }
    }

    private fun files(): List<File> = dir.listFiles { f -> f.name.endsWith(".mp3") }?.toList() ?: emptyList()

    private fun trim() {
        var total = files().sumOf { it.length() }
        for (f in files().sortedBy { it.lastModified() }) {
            if (total <= maxBytes) break
            total -= f.length()
            f.delete()
        }
    }

    fun size(): Long = files().sumOf { it.length() }

    fun count(): Int = files().size

    fun clear() {
        files().forEach { it.delete() }
    }
}
