package br.com.rodripsi.memoria

import android.content.Context
import android.graphics.BitmapFactory
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

/** Rede do Spotify: só consulta o oEmbed público (sem login, sem chave). */
object SpotifyNet {
    private fun get(url: String): ByteArray? = try {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        c.instanceFollowRedirects = true
        if (c.responseCode in 200..299) c.inputStream.use { it.readBytes() } else null
    } catch (e: Exception) {
        null
    }

    /** Devolve a música com título e capa. Se estiver sem internet, guarda só o link. */
    fun fetch(ctx: Context, rawUrl: String): SongRef {
        val url = Spotify.clean(rawUrl)
        val body = get(Spotify.oembedUrl(url))?.toString(Charsets.UTF_8)
        val info = body?.let { Spotify.parseOembed(it) }
        var thumbName = ""
        val tu = info?.second
        if (!tu.isNullOrBlank()) {
            val bytes = get(tu)
            if (bytes != null && BitmapFactory.decodeByteArray(bytes, 0, bytes.size) != null) {
                thumbName = "capa_" + UUID.randomUUID() + ".jpg"
                File(Thumbs.dir(ctx), thumbName).writeBytes(bytes)
            }
        }
        return SongRef(url, info?.first ?: "Música no Spotify", thumbName)
    }
}
