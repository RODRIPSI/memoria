package br.com.rodripsi.memoria

import org.json.JSONArray
import org.json.JSONObject

/** Leitura/escrita do arquivo de memórias (lógica pura, testável fora do Android). Aceita arquivos antigos sem mídia. */
object MemoryJson {
    fun fromJson(s: String): List<Memory> {
        val arr = JSONArray(s)
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            val ppl = ArrayList<String>()
            val pa = o.optJSONArray("people")
            if (pa != null) for (i in 0 until pa.length()) ppl.add(pa.optString(i))
            val media = ArrayList<MediaRef>()
            val ma = o.optJSONArray("media")
            if (ma != null) for (i in 0 until ma.length()) {
                val mo = ma.optJSONObject(i) ?: continue
                media.add(MediaRef(mo.optString("uri"), mo.optString("kind", "image"), mo.optString("thumb")))
            }
            val so = o.optJSONObject("song")
            val song = if (so != null) SongRef(so.optString("url"), so.optString("title"), so.optString("thumb")) else null
            Memory(
                o.getString("id"),
                o.getString("text"),
                o.getLong("ts"),
                o.optString("subject", ""),
                ppl,
                o.optString("type", "fato"),
                if (o.has("remindAt") && !o.isNull("remindAt")) o.getLong("remindAt") else null,
                o.optBoolean("done", false),
                media,
                song
            )
        }
    }

    fun toJson(list: List<Memory>): String {
        val arr = JSONArray()
        list.forEach { m ->
            val o = JSONObject()
                .put("id", m.id).put("text", m.text).put("ts", m.ts)
                .put("subject", m.subject)
                .put("people", JSONArray(m.people))
                .put("type", m.type)
                .put("done", m.done)
            if (m.remindAt != null) o.put("remindAt", m.remindAt)
            if (m.media.isNotEmpty()) {
                val ma = JSONArray()
                m.media.forEach { ma.put(JSONObject().put("uri", it.uri).put("kind", it.kind).put("thumb", it.thumb)) }
                o.put("media", ma)
            }
            val sg = m.song
            if (sg != null) o.put("song", JSONObject().put("url", sg.url).put("title", sg.title).put("thumb", sg.thumb))
            arr.put(o)
        }
        return arr.toString(2)
    }
}
