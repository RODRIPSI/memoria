package br.com.rodripsi.memoria

import org.json.JSONObject

/** Ajuda com links do Spotify (parte pura, testável). */
object Spotify {
    private val rx = Regex("https?://(?:open\\.spotify\\.com|spotify\\.link)/[^\\s]+", RegexOption.IGNORE_CASE)

    /** Acha o primeiro link do Spotify num texto compartilhado. */
    fun extractUrl(text: String): String? = rx.find(text)?.value?.trimEnd('.', ',', ')', ']', '>')

    /** Tira o rastreio (?si=...) do link. */
    fun clean(url: String): String = url.substringBefore('?').substringBefore('#')

    /** Lê a resposta do oEmbed público do Spotify: título e capa. */
    fun parseOembed(json: String): Pair<String, String>? = try {
        val o = JSONObject(json)
        val t = o.optString("title", "").trim()
        if (t.isEmpty()) null else Pair(t, o.optString("thumbnail_url", ""))
    } catch (e: Exception) {
        null
    }

    fun oembedUrl(url: String): String =
        "https://open.spotify.com/oembed?url=" + java.net.URLEncoder.encode(url, "UTF-8")
}
