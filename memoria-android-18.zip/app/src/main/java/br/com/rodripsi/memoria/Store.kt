package br.com.rodripsi.memoria

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import java.io.File
import java.time.LocalDate

/**
 * Guarda as memórias num arquivo privado do app.
 * Proteções: gravação em arquivo temporário, cópia de segurança do último arquivo bom,
 * um backup por dia (os 7 mais recentes) e nunca descarta um arquivo ilegível sem guardar uma cópia.
 */
class Store(ctx: Context) {
    private val app = ctx.applicationContext
    private val file = File(ctx.filesDir, "memorias.json")
    private val bak = File(ctx.filesDir, "memorias.bak")
    private val tmp = File(ctx.filesDir, "memorias.tmp")
    private val dir = File(ctx.filesDir, "backups")

    /** Aviso para mostrar na tela quando algo precisou ser recuperado. */
    var loadNote: String? = null
        private set

    fun load(): List<Memory> {
        if (!file.exists()) {
            if (!bak.exists()) return emptyList()
            return try {
                val r = fromJson(bak.readText())
                loadNote = "O arquivo das memórias não foi encontrado. Recuperei a cópia de segurança."
                r
            } catch (e: Exception) {
                emptyList()
            }
        }
        return try {
            fromJson(file.readText())
        } catch (e: Exception) {
            // arquivo ilegível: guarda uma cópia para não perder nada e tenta a cópia de segurança
            try {
                file.copyTo(File(app.filesDir, "memorias-ilegivel-" + System.currentTimeMillis() + ".json"), overwrite = true)
            } catch (e2: Exception) {
                // sem espaço
            }
            try {
                val r = fromJson(bak.readText())
                loadNote = "O arquivo das memórias estava ilegível. Recuperei a cópia de segurança."
                r
            } catch (e3: Exception) {
                loadNote = "O arquivo das memórias estava ilegível. Guardei uma cópia dele; procure ajuda antes de apagar o app."
                emptyList()
            }
        }
    }

    fun save(list: List<Memory>) {
        synchronized(this) {
            try {
                val json = toJson(list)
                // 1. cópia de segurança do arquivo atual, só se ele estiver bom
                if (file.exists()) {
                    try {
                        fromJson(file.readText())
                        file.copyTo(bak, overwrite = true)
                    } catch (e: Exception) {
                        // não substitui uma cópia boa por um arquivo ruim
                    }
                }
                // 2. um backup por dia
                backupDiario(json)
                // 3. grava num temporário e só então troca o arquivo
                tmp.writeText(json)
                if (!tmp.renameTo(file)) file.writeText(json)
            } catch (e: Exception) {
                Handler(Looper.getMainLooper()).post {
                    Toast.makeText(app, "Não consegui salvar. Verifique o espaço do aparelho.", Toast.LENGTH_LONG).show()
                }
            }
        }
        // espelha os lembretes na agenda "Lembretes" (a Central lê dali), fora da tela principal
        val copia = list.toList()
        Thread {
            try {
                Agenda.syncLembretes(app, copia, Config(app).sigiloList())
            } catch (e: Exception) {
                // tenta de novo na próxima gravação
            }
        }.start()
    }

    private fun backupDiario(json: String) {
        try {
            dir.mkdirs()
            val hoje = File(dir, "memorias-" + LocalDate.now().toString() + ".json")
            if (!hoje.exists()) hoje.writeText(json)
            val antigos = (dir.listFiles() ?: emptyArray()).sortedBy { it.name }
            if (antigos.size > 7) antigos.take(antigos.size - 7).forEach { it.delete() }
        } catch (e: Exception) {
            // backup do dia é um extra
        }
    }

    /** Escreve todas as memórias no arquivo escolhido pelo usuário (pode ser no Google Drive). */
    fun exportTo(uri: Uri, list: List<Memory>): Boolean = try {
        val out = app.contentResolver.openOutputStream(uri, "wt")
        if (out == null) false else {
            out.use { it.write(toJson(list).toByteArray(Charsets.UTF_8)) }
            true
        }
    } catch (e: Exception) {
        false
    }

    /** Lê um backup e devolve a lista atual com os registros que faltavam (nunca apaga nem troca os existentes). */
    fun mergeFrom(uri: Uri, current: List<Memory>): Pair<List<Memory>, List<Memory>>? = try {
        val txt = app.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
        if (txt == null) null else {
            val ids = current.map { it.id }.toSet()
            val novos = fromJson(txt).filter { it.id !in ids }
            Pair((current + novos).sortedBy { it.ts }, novos)
        }
    } catch (e: Exception) {
        null
    }

    companion object {
        fun fromJson(s: String): List<Memory> = MemoryJson.fromJson(s)
        fun toJson(list: List<Memory>): String = MemoryJson.toJson(list)
    }
}
