package br.com.rodripsi.memoria

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.ZoneId

/** Um lembrete na lista: do próprio Memória ([mem] != null) ou vindo de outro app pela agenda Lembretes. */
class LItem(val key: String, val texto: String, val quando: Long, val tag: String, val mem: Memory?, val tipo: String)

fun todosLembretes(vm: MemoriaVM): List<LItem> {
    val a = vm.memories.filter { !it.done && it.remindAt != null }.map {
        LItem(it.id, it.text, it.remindAt ?: 0L, it.subject, it, it.type)
    }
    val b = vm.externos.map {
        LItem(it.key, it.titulo, it.quando, nomeApp(it.app), null, "app")
    }
    return (a + b).sortedBy { it.quando }
}

private fun nomeApp(t: String): String = when (t) {
    "" -> "Outro app"
    "bloco" -> "Entrelaços"
    "saude" -> "Saúde"
    "financeiro" -> "Financeiro"
    "mercado" -> "Mercado"
    "central" -> "Geral"
    "consultorio" -> "Consultório"
    else -> t.replaceFirstChar { it.uppercase() }
}

private val CATEGORIAS = listOf(
    "todos" to "Todos",
    "tarefa" to "Tarefas",
    "promessa" to "Promessas",
    "aguardando" to "Aguardando",
    "app" to "Outros apps"
)

/** Chip compacto: sem corte e com toque fácil. */
@Composable
fun Chip(texto: String, marcado: Boolean, onClick: () -> Unit) {
    val c = MaterialTheme.colorScheme
    Box(
        Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (marcado) c.primary else c.surface)
            .border(BorderStroke(1.dp, if (marcado) c.primary else c.outline), RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(
            texto, fontSize = 13.sp, maxLines = 1,
            fontWeight = if (marcado) FontWeight.Medium else FontWeight.Normal,
            color = if (marcado) c.onPrimary else c.onSurface
        )
    }
}

@Composable
fun Contador(nome: String, n: Int, marcado: Boolean, alerta: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val colors = MaterialTheme.colorScheme
    val fundo = when {
        marcado -> colors.primary.copy(alpha = 0.28f)
        alerta && n > 0 -> colors.error.copy(alpha = 0.18f)
        else -> colors.surface
    }
    Card(
        colors = CardDefaults.cardColors(containerColor = fundo),
        modifier = modifier.clickable { onClick() }
    ) {
        Column(Modifier.padding(vertical = 8.dp, horizontal = 4.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                n.toString(), fontSize = 20.sp, fontWeight = FontWeight.Medium,
                color = if (alerta && n > 0) colors.error else colors.onSurface
            )
            Text(nome, fontSize = 11.sp, color = colors.onSurface.copy(alpha = 0.75f), maxLines = 1)
        }
    }
}

/** Quatro contadores da tela inicial: Hoje, Próximos, Atrasados e total de memórias. */
@Composable
fun ResumoInicio(vm: MemoriaVM, onLembretes: () -> Unit, onMemorias: () -> Unit) {
    val zone = ZoneId.systemDefault()
    val agora = System.currentTimeMillis()
    val d1 = LocalDate.now(zone).atStartOfDay(zone).toInstant().toEpochMilli() + 86_400_000L
    val abertos = todosLembretes(vm)
    Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Contador("Hoje", abertos.count { it.quando >= agora && it.quando < d1 }, false, false, Modifier.weight(1f)) { onLembretes() }
        Contador("Próximos", abertos.count { it.quando >= d1 }, false, false, Modifier.weight(1f)) { onLembretes() }
        Contador("Atrasados", abertos.count { it.quando < agora }, false, true, Modifier.weight(1f)) { onLembretes() }
        Contador("Memórias", vm.memories.size, false, false, Modifier.weight(1f)) { onMemorias() }
    }
}

@Composable
fun Cabecalho(titulo: String, acao: String, onAcao: () -> Unit) {
    val colors = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(titulo, fontSize = 16.sp, fontWeight = FontWeight.Medium, color = colors.onBackground, modifier = Modifier.weight(1f))
        TextButton(onClick = onAcao) { Text(acao, fontSize = 13.sp) }
    }
}

/** Linha compacta de lembrete: círculo para concluir, texto, data e menu ⋮. */
@Composable
fun LinhaLembrete(
    vm: MemoriaVM, it: LItem, agora: Long,
    onEditar: (Memory) -> Unit, onExcluir: (Memory) -> Unit, compacto: Boolean = false
) {
    val colors = MaterialTheme.colorScheme
    val atrasado = it.quando < agora
    var menu by remember { mutableStateOf(false) }
    Card(
        colors = CardDefaults.cardColors(containerColor = colors.surface),
        modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(start = 10.dp, top = 4.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(22.dp).clip(CircleShape)
                    .border(BorderStroke(1.5.dp, if (atrasado) colors.error else colors.outline), CircleShape)
                    .clickable { it.mem?.let { m -> vm.markDone(m.id) } }
            )
            Column(Modifier.weight(1f).padding(horizontal = 10.dp, vertical = 4.dp)) {
                Text(it.texto, fontSize = 14.sp, color = colors.onSurface, maxLines = if (compacto) 1 else 2, overflow = TextOverflow.Ellipsis)
                Text(
                    whenLabel(it.quando) + if (it.tag.isNotBlank()) "  ·  " + it.tag else "",
                    fontSize = 12.sp, color = if (atrasado) colors.error else colors.primary,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
            val m = it.mem
            if (m != null) {
                Box {
                    IconButton(onClick = { menu = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "Mais opções", tint = colors.onSurface.copy(alpha = 0.7f))
                    }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text("Concluir") }, onClick = { menu = false; vm.markDone(m.id) })
                        DropdownMenuItem(text = { Text("Editar") }, onClick = { menu = false; onEditar(m) })
                        DropdownMenuItem(text = { Text("Adiar 1 hora") }, onClick = {
                            menu = false; vm.snoozeId(m.id, System.currentTimeMillis() + 3_600_000L)
                        })
                        DropdownMenuItem(text = { Text("Adiar para amanhã 9h") }, onClick = {
                            menu = false
                            val z = ZoneId.systemDefault()
                            vm.snoozeId(m.id, LocalDate.now(z).plusDays(1).atTime(9, 0).atZone(z).toInstant().toEpochMilli())
                        })
                        DropdownMenuItem(text = { Text("Excluir", color = colors.error) }, onClick = { menu = false; onExcluir(m) })
                    }
                }
            } else {
                Box(Modifier.width(12.dp))
            }
        }
    }
}

/** Tela Lembretes: Hoje / Próximos / Atrasados, filtros que não cortam e lista em seções. */
@Composable
fun LembretesPainel(vm: MemoriaVM, onEditar: (Memory) -> Unit, onExcluir: (Memory) -> Unit) {
    val colors = MaterialTheme.colorScheme
    var tile by remember { mutableStateOf("todos") }
    var cat by remember { mutableStateOf("todos") }

    val zone = ZoneId.systemDefault()
    val agora = System.currentTimeMillis()
    val d1 = LocalDate.now(zone).atStartOfDay(zone).toInstant().toEpochMilli() + 86_400_000L

    val daCategoria = todosLembretes(vm).filter { cat == "todos" || it.tipo == cat }
    val atr = daCategoria.filter { it.quando < agora }
    val hoje = daCategoria.filter { it.quando >= agora && it.quando < d1 }
    val prox = daCategoria.filter { it.quando >= d1 }

    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Contador("Hoje", hoje.size, tile == "hoje", false, Modifier.weight(1f)) { tile = if (tile == "hoje") "todos" else "hoje" }
            Contador("Próximos", prox.size, tile == "prox", false, Modifier.weight(1f)) { tile = if (tile == "prox") "todos" else "prox" }
            Contador("Atrasados", atr.size, tile == "atr", true, Modifier.weight(1f)) { tile = if (tile == "atr") "todos" else "atr" }
        }
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            CATEGORIAS.forEach { (k, nome) -> Chip(nome, cat == k) { cat = k } }
        }

        if (daCategoria.isEmpty()) {
            Text(
                "Nenhum lembrete pendente. Toque em + para criar o primeiro.",
                color = colors.onBackground.copy(alpha = 0.7f), textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(vertical = 24.dp)
            )
        }
        if ((tile == "todos" || tile == "atr") && atr.isNotEmpty()) {
            Text("Atrasados", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = colors.error, modifier = Modifier.padding(bottom = 6.dp))
            atr.take(40).forEach { LinhaLembrete(vm, it, agora, onEditar, onExcluir) }
        }
        if ((tile == "todos" || tile == "hoje") && hoje.isNotEmpty()) {
            Text("Hoje", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = colors.primary, modifier = Modifier.padding(top = 6.dp, bottom = 6.dp))
            hoje.take(40).forEach { LinhaLembrete(vm, it, agora, onEditar, onExcluir) }
        }
        if ((tile == "todos" || tile == "prox") && prox.isNotEmpty()) {
            Text("Próximos", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = colors.onBackground, modifier = Modifier.padding(top = 6.dp, bottom = 6.dp))
            prox.take(60).forEach { LinhaLembrete(vm, it, agora, onEditar, onExcluir) }
        }
    }
}

/** "Seus lembretes" do Início: os três próximos. */
@Composable
fun ListaInicio(vm: MemoriaVM, onVerTodos: () -> Unit, onEditar: (Memory) -> Unit, onExcluir: (Memory) -> Unit) {
    val colors = MaterialTheme.colorScheme
    val proximos = todosLembretes(vm).take(3)
    val agora = System.currentTimeMillis()
    Column(Modifier.fillMaxWidth().padding(top = 6.dp)) {
        Cabecalho("Seus lembretes", "Ver todos", onVerTodos)
        if (proximos.isEmpty()) {
            Text("Nenhum lembrete pendente.", fontSize = 13.sp, color = colors.onBackground.copy(alpha = 0.7f))
        }
        proximos.forEach { LinhaLembrete(vm, it, agora, onEditar, onExcluir, compacto = true) }
    }
}

/** "Memórias recentes": cartões compactos na horizontal. */
@Composable
fun RecentesInicio(vm: MemoriaVM, onVerTodas: () -> Unit) {
    val colors = MaterialTheme.colorScheme
    val comuns = vm.memories.filter { it.remindAt == null }
    val recentes = (if (comuns.isEmpty()) vm.memories else comuns).sortedByDescending { it.ts }.take(6)
    Column(Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 12.dp)) {
        Cabecalho("Memórias recentes", "Ver todas", onVerTodas)
        if (recentes.isEmpty()) {
            Text("Nenhuma memória ainda. Fale ou escreva o que deseja guardar.", fontSize = 13.sp, color = colors.onBackground.copy(alpha = 0.7f))
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            recentes.forEach { m ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = colors.surface),
                    modifier = Modifier.width(140.dp).clickable { onVerTodas() }
                ) {
                    Column(Modifier.padding(10.dp)) {
                        if (m.subject.isNotBlank()) Text(m.subject, fontSize = 11.sp, color = colors.primary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(m.text, fontSize = 13.sp, color = colors.onSurface, maxLines = 3, overflow = TextOverflow.Ellipsis)
                        Text(whenLabel(m.ts), fontSize = 11.sp, color = colors.onSurface.copy(alpha = 0.6f), modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }
        }
    }
}

/** Diálogo para escrever uma nova memória ou lembrete (botão + › Escrever). */
@Composable
fun DialogEscrever(onFechar: () -> Unit, onSalvar: (String) -> Unit) {
    var texto by remember { mutableStateOf("") }
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onFechar,
        title = { Text("Escrever") },
        text = {
            Column {
                Text("Escreva o que quer guardar. Com dia e hora, vira lembrete. Ex.: amanhã às 9 comprar carregador de smartwatch", fontSize = 13.sp)
                OutlinedTextField(
                    value = texto, onValueChange = { texto = it },
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                )
            }
        },
        confirmButton = { TextButton(onClick = { if (texto.isNotBlank()) onSalvar(texto.trim()) }) { Text("Guardar") } },
        dismissButton = { TextButton(onClick = onFechar) { Text("Cancelar") } }
    )
}

/** Diálogo para editar texto e assunto de uma memória ou lembrete. */
@Composable
fun DialogEditar(m: Memory, onFechar: () -> Unit, onSalvar: (String, String) -> Unit) {
    var texto by remember { mutableStateOf(m.text) }
    var assunto by remember { mutableStateOf(m.subject) }
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onFechar,
        title = { Text("Editar") },
        text = {
            Column {
                OutlinedTextField(
                    value = texto, onValueChange = { texto = it }, label = { Text("Texto") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = assunto, onValueChange = { assunto = it }, label = { Text("Categoria") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                )
            }
        },
        confirmButton = { TextButton(onClick = { if (texto.isNotBlank()) onSalvar(texto, assunto) }) { Text("Salvar") } },
        dismissButton = { TextButton(onClick = onFechar) { Text("Cancelar") } }
    )
}

/** Confirmação antes de excluir. */
@Composable
fun DialogExcluir(m: Memory, onFechar: () -> Unit, onConfirmar: () -> Unit) {
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onFechar,
        title = { Text("Excluir?") },
        text = { Text(m.text.take(120), fontSize = 14.sp) },
        confirmButton = { TextButton(onClick = onConfirmar) { Text("Excluir", color = MaterialTheme.colorScheme.error) } },
        dismissButton = { TextButton(onClick = onFechar) { Text("Cancelar") } }
    )
}
