# Memória — versão de teste (Bloco A)

Aplicativo Android pessoal de apoio à memória. Uso exclusivamente pessoal, não publicado.

## Como compilar pelo GitHub (sem instalar nada)

1. Em github.com, crie um repositório **privado** chamado `memoria` (marque "Add a README file").
2. **Add file → Upload files** → envie `memoria-projeto.zip` → **Commit changes**.
3. **Add file → Create new file** → no nome, digite exatamente `.github/workflows/compilar.yml` → cole o conteúdo do arquivo `compilar.yml` → **Commit changes**.
4. Abra a aba **Actions**. A compilação leva cerca de 10 minutos. Círculo verde = pronto; vermelho = erro (envie o log para correção).
5. Na página inicial do repositório, abra **Releases** → baixe `Memoria-teste-N.apk` no celular → toque para instalar (o Android pedirá para permitir a instalação a partir do navegador).

**Atualizações:** substitua o `memoria-projeto.zip` pelo novo (Upload files, mesmo nome). Uma nova versão aparece em Releases. Instale por cima: **os dados são mantidos**, porque todas as versões usam a mesma chave de assinatura de teste.

## Como abrir no Android Studio (alternativa)

Descompacte o zip, abra a pasta no Android Studio e clique em Run.

## Decisões técnicas (reversíveis)

| Decisão | Motivo |
|---|---|
| Kotlin + Jetpack Compose + Material 3 | Padrão atual do Android; tema claro/escuro automático |
| Room (SQLite) local, esquema versionado, sem "apagar e recriar" | Funciona offline; mudanças futuras por migração, sem perda de dados |
| Coleções = filtros sobre os mesmos registros | Nenhum momento ou arquivo duplicado |
| Data do acontecimento (com fuso) separada da data de registro | Exigência central da especificação |
| Exclusão = mover para a Lixeira (recuperável) | Nada é apagado de vez sem confirmação |
| Injeção de dependências manual | Menos bibliotecas, menos pontos de falha |
| Chave de assinatura de teste fixa no projeto | Permite instalar versões novas por cima; não é segredo (senha padrão "android") |
| `allowBackup=false` | Evita cópia automática de dados sensíveis; backup controlado virá em etapa própria |
| Pessoas, lugares e eventos reconhecidos pelo nome (sem diferenciar maiúsculas/espaços) | "Helena" e "helena " são a mesma pessoa |

## Modelo de dados (versão 1 do banco)

- `moments`: id, título, texto, quando aconteceu + fuso, quando foi registrado, última alteração, tipo, favorito, marco, origem, transcrição, lugar, evento, estado de sincronização, demonstração, data de envio à Lixeira.
- `people`, `places`, `events`, `tags`: nome + chave normalizada única.
- `moment_people`, `moment_tags`: vínculos (um momento, várias pessoas/etiquetas).
- `media_refs`: referência a fotos, vídeos e áudios (preparada para o Bloco B).

As demais entidades da especificação (Saúde, Reconstrução, Agenda, Sincronização, Configurações) entram nos blocos seguintes, por migração.

## Permissões Android

Nenhuma nesta versão. Microfone e câmera serão pedidos no Bloco B, somente no momento de uso.

## Inventário de funções

| Função | Situação |
|---|---|
| Navegação pelas 5 áreas, com Guardar em destaque | Real |
| Tela Hoje (data, momentos do dia, atalhos) | Real |
| Guardar por texto, com data/hora do acontecimento, tipo, pessoas, lugar, evento, favorito e marco | Real, local |
| Editar momento, favoritar, marcar como marco | Real, local |
| Excluir com confirmação (Lixeira) | Real, local; a tela da Lixeira chega no Bloco B |
| Copiar legenda e compartilhar pelo menu do Android | Real (texto) |
| Linha do tempo Ano → Mês → Semana → Dia | Real |
| Coleções: Momentos, Eventos, Pessoas, Lugares, Ideias, Produções, Marcos, Favoritos | Real, sem duplicação |
| Dados fictícios de demonstração, com remover/restaurar | Real (menu ⋮ da tela Hoje) |
| Falar, Fotografar, Filmar | Pendente: Bloco B |
| Pesquisa e filtros; grade de fotos | Pendente: Bloco B |
| Reconstruir, pistas, exercício com fotos, agenda simulada | Pendente: Bloco C |
| Saúde completa e resumos | Pendente: Bloco D |
| Privacidade, bloqueio por biometria, configurações | Pendente: Bloco E |
| Google Calendar, Drive, Fotos, IA, backup | Pendente: após aprovação do MVP |

## Testes automáticos incluídos

- Linha do tempo: semanas recortadas pelo mês, ordem, fuso do próprio momento.
- Coleções: o mesmo momento aparece em várias coleções sem cópia; contagem por pessoa.
- Banco: salvar e reabrir (persistência); separação acontecimento × registro; edição preserva data de registro; mesma pessoa não duplica; favoritar; Lixeira.

## Como testar os fluxos desta versão

1. Abra o app: aparecem momentos fictícios marcados "Demonstração".
2. Hoje → Escrever → escreva algo → mude "Quando aconteceu" para ontem → Guardar. Abre o detalhe, com "Registrado em hoje (depois do acontecimento)".
3. No detalhe: coração (favorito), bandeira (marco), lápis (editar), ⋮ (copiar, compartilhar, excluir).
4. Memórias → Linha do tempo: abra e feche ano, mês, semana e dia.
5. Memórias → Coleções → Pessoas → Helena: os mesmos momentos aparecem também em Favoritos ou Lugares, sem cópia.
6. Feche o app completamente e reabra: tudo continua lá.
7. Hoje → ⋮ → Remover dados de demonstração: somem só os fictícios.

## Limitações conhecidas

- Este projeto não foi compilado no ambiente em que foi escrito (sem Android SDK disponível). A primeira compilação no GitHub é a verificação real; erros, se houver, serão corrigidos a partir do log.
- A virada de meia-noite com o app aberto só atualiza "Hoje" ao reabrir a tela.
