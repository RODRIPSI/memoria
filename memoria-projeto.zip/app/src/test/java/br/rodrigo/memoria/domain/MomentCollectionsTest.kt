package br.rodrigo.memoria.domain

import br.rodrigo.memoria.domain.CollectionKind.*
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Instant
import java.time.ZonedDateTime

class MomentCollectionsTest {

    private fun moment(
        id: String,
        fav: Boolean = false,
        milestone: Boolean = false,
        category: Category = Category.COTIDIANO,
        people: List<NamedRef> = emptyList(),
        place: NamedRef? = null,
        event: NamedRef? = null,
    ) = Moment(
        id = id, title = null, body = "texto", occurredAt = ZonedDateTime.now(),
        createdAt = Instant.now(), updatedAt = Instant.now(), category = category,
        isFavorite = fav, isMilestone = milestone, source = Source.TEXTO, transcript = null,
        people = people, place = place, event = event, tags = emptyList(), media = emptyList(),
        syncStatus = SyncStatus.LOCAL, isDemo = false,
    )

    private val helena = NamedRef("p1", "Helena")
    private val tomas = NamedRef("p2", "Tomás")
    private val cafe = NamedRef("l1", "Café Aurora")

    @Test
    fun mesmoMomentoApareceEmVariasColecoesSemCopia() {
        val m = moment("m1", fav = true, milestone = true, people = listOf(helena), place = cafe)
        val outro = moment("m2", category = Category.IDEIA)
        val todos = listOf(m, outro)

        for (kind in listOf(TODOS, FAVORITOS, MARCOS, PESSOAS, LUGARES)) {
            val encontrados = todos.filter { MomentCollections.matches(it, kind) }
            // O MESMO objeto (mesma instância), não uma cópia.
            assertSame(m, encontrados.single { it.id == "m1" })
        }
        assertTrue(MomentCollections.matches(m, PESSOAS, "p1"))
        assertTrue(MomentCollections.matches(m, LUGARES, "l1"))
        assertFalse(MomentCollections.matches(outro, FAVORITOS))
        assertTrue(MomentCollections.matches(outro, IDEIAS))
        assertEquals(1, todos.count { it.id == "m1" })
    }

    @Test
    fun agrupaPessoasContandoMomentos() {
        val list = listOf(
            moment("1", people = listOf(helena, tomas)),
            moment("2", people = listOf(helena)),
            moment("3"),
        )
        val grupos = MomentCollections.groups(list, PESSOAS)
        assertEquals(listOf("Helena" to 2, "Tomás" to 1), grupos.map { it.name to it.count })
        assertEquals("2 pessoas", MomentCollections.summary(list, PESSOAS))
        assertEquals("3 momentos", MomentCollections.summary(list, TODOS))
    }
}
