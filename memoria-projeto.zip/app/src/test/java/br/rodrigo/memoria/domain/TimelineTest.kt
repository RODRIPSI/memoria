package br.rodrigo.memoria.domain

import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.ZonedDateTime

class TimelineTest {
    private val sp = ZoneId.of("America/Sao_Paulo")
    private fun at(s: String) = ZonedDateTime.of(LocalDateTime.parse(s), sp)

    @Test
    fun semanasSaoRecortadasPeloMes() {
        assertEquals(1 to 6, Timeline.weekBounds(LocalDate.of(2026, 9, 1)))
        assertEquals(21 to 27, Timeline.weekBounds(LocalDate.of(2026, 9, 23)))
        assertEquals(28 to 30, Timeline.weekBounds(LocalDate.of(2026, 9, 30)))
        assertEquals(31 to 31, Timeline.weekBounds(LocalDate.of(2026, 8, 31)))
    }

    private data class Item(val id: String, val t: ZonedDateTime)

    @Test
    fun agrupaAnoMesSemanaDia() {
        val items = listOf(
            Item("a", at("2026-09-23T12:40")),
            Item("b", at("2026-09-23T08:10")),
            Item("c", at("2026-09-02T10:00")),
            Item("d", at("2025-12-31T23:00")),
        )
        val tree = Timeline.build(items) { it.t }

        assertEquals(listOf(2026, 2025), tree.map { it.year })
        val setembro = tree[0].months.single()
        assertEquals(9, setembro.month)
        assertEquals(listOf("Semana 21–27", "Semana 1–6"), setembro.weeks.map { it.label })
        val dia = setembro.weeks[0].days.single()
        assertEquals(LocalDate.of(2026, 9, 23), dia.date)
        // Dentro do dia, ordem cronológica.
        assertEquals(listOf("b", "a"), dia.items.map { it.id })
        assertEquals(4, tree.sumOf { it.count })
    }

    @Test
    fun usaOFusoDoProprioMomentoParaDefinirODia() {
        // 01:30 UTC do dia 24 ainda é dia 23 em São Paulo.
        val t = ZonedDateTime.of(LocalDateTime.parse("2026-09-24T01:30"), ZoneOffset.UTC).withZoneSameInstant(sp)
        val tree = Timeline.build(listOf(t)) { it }
        assertEquals(LocalDate.of(2026, 9, 23), tree[0].months[0].weeks[0].days[0].date)
    }
}
