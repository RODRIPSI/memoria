package br.rodrigo.memoria.data

import android.app.Application
import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import br.rodrigo.memoria.data.db.MemoriaDatabase
import br.rodrigo.memoria.domain.Category
import br.rodrigo.memoria.domain.MomentDraft
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.time.Instant
import java.time.ZoneId
import java.time.ZonedDateTime

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34], application = Application::class)
class MomentRepositoryTest {

    private lateinit var context: Context
    private var fakeNow = Instant.parse("2026-09-24T15:00:00Z").toEpochMilli()
    private val sp = ZoneId.of("America/Sao_Paulo")

    private fun openDb(): MemoriaDatabase =
        Room.databaseBuilder(context, MemoriaDatabase::class.java, DB).build()

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        context.deleteDatabase(DB)
    }

    @Test
    fun salvaEMantemAposFecharEReabrir() = runBlocking {
        val occurred = ZonedDateTime.of(2026, 9, 23, 12, 40, 0, 0, sp)
        val db1 = openDb()
        val id = MomentRepository(db1) { fakeNow }.save(
            MomentDraft(
                body = "Acabei de almoçar. Comi arroz, feijão e carne.",
                occurredAt = occurred,
                people = listOf("Helena", "helena ", "Tomás"),
                place = "Café Aurora",
                category = Category.COTIDIANO,
            ),
        )
        db1.close()

        val db2 = openDb()
        val m = MomentRepository(db2) { fakeNow }.observe(id).first()!!
        // Quando aconteceu x quando foi registrado: separados.
        assertEquals(occurred.toInstant(), m.occurredAt.toInstant())
        assertEquals("America/Sao_Paulo", m.occurredAt.zone.id)
        assertEquals(Instant.ofEpochMilli(fakeNow), m.createdAt)
        // "Helena" e "helena " são a mesma pessoa.
        assertEquals(listOf("Helena", "Tomás"), m.people.map { it.name })
        assertEquals("Café Aurora", m.place?.name)
        db2.close()
    }

    @Test
    fun editarPreservaDataDeRegistro() = runBlocking {
        val db = openDb()
        val repo = MomentRepository(db) { fakeNow }
        val occurred = ZonedDateTime.of(2026, 9, 20, 9, 0, 0, 0, sp)
        val id = repo.save(MomentDraft(body = "Primeira versão", occurredAt = occurred))
        val created = repo.observe(id).first()!!.createdAt

        fakeNow += 3_600_000
        repo.save(MomentDraft(id = id, body = "Versão corrigida", occurredAt = occurred.plusHours(1)))
        val edited = repo.observe(id).first()!!

        assertEquals("Versão corrigida", edited.body)
        assertEquals(created, edited.createdAt)
        assertNotEquals(edited.createdAt, edited.updatedAt)
        assertEquals(occurred.plusHours(1).toInstant(), edited.occurredAt.toInstant())
        db.close()
    }

    @Test
    fun mesmaPessoaEmMomentosDiferentesNaoDuplica() = runBlocking {
        val db = openDb()
        val repo = MomentRepository(db) { fakeNow }
        val t = ZonedDateTime.of(2026, 9, 1, 10, 0, 0, 0, sp)
        val a = repo.save(MomentDraft(body = "A", occurredAt = t, people = listOf("Carmem")))
        val b = repo.save(MomentDraft(body = "B", occurredAt = t.plusDays(1), people = listOf("carmem")))
        val pa = repo.observe(a).first()!!.people.single()
        val pb = repo.observe(b).first()!!.people.single()
        assertEquals(pa.id, pb.id)
        db.close()
    }

    @Test
    fun favoritarEMoverParaLixeira() = runBlocking {
        val db = openDb()
        val repo = MomentRepository(db) { fakeNow }
        val id = repo.save(MomentDraft(body = "Teste", occurredAt = ZonedDateTime.now(sp)))

        repo.setFavorite(id, true)
        assertTrue(repo.observe(id).first()!!.isFavorite)

        repo.moveToTrash(id)
        assertNull(repo.observe(id).first())
        assertFalse(repo.observeAll().first().any { it.id == id })
        db.close()
    }

    private companion object {
        const val DB = "teste-memoria.db"
    }
}
