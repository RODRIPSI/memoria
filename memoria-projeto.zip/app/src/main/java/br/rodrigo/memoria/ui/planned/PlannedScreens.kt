@file:OptIn(ExperimentalMaterial3Api::class)

package br.rodrigo.memoria.ui.planned

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun HealthPlaceholder() = PlannedScreen(
    title = "Saúde",
    intro = "Um espaço pessoal de acompanhamento, sem diagnósticos, para levar informações organizadas aos profissionais que cuidam de você.",
    block = "Bloco D",
    items = listOf(
        "Consultas e exames, com agendamento e realização separados",
        "Sintomas, dores e emoções, com intensidade de 0 a 10",
        "Medicamentos com histórico que nunca apaga o passado",
        "Vacinas, com confirmação de cada campo antes de salvar",
        "Resumos semanais e mensais para perceber recorrências",
    ),
)

@Composable
fun ReconstructPlaceholder() = PlannedScreen(
    title = "Reconstruir",
    intro = "Relembrar um período com perguntas. Você tenta lembrar primeiro; as pistas e o registro original só aparecem quando você pedir.",
    block = "Bloco C",
    items = listOf(
        "Escolher hoje, ontem, últimos 3 dias, última semana ou outro período",
        "Responder por texto ou voz",
        "Primeira pista, segunda pista e, se quiser, o registro original",
        "Resumo final: o que veio espontaneamente, com pistas ou pelo registro",
        "Exercício com fotografias",
    ),
)

@Composable
private fun PlannedScreen(title: String, intro: String, block: String, items: List<String>) {
    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = { TopAppBar(title = { Text(title) }) },
    ) { padding ->
        Column(
            Modifier
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text(intro, style = MaterialTheme.typography.bodyLarge)
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "Esta área ainda não está ativa nesta versão de teste. Ela chega no $block.",
                        style = MaterialTheme.typography.titleSmall,
                    )
                    items.forEach { line ->
                        Text("•  $line", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}
