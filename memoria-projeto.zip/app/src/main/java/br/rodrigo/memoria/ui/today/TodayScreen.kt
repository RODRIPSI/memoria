@file:OptIn(ExperimentalMaterial3Api::class)

package br.rodrigo.memoria.ui.today

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import br.rodrigo.memoria.AppContainer
import br.rodrigo.memoria.domain.Formats
import br.rodrigo.memoria.domain.Moment
import br.rodrigo.memoria.ui.components.EmptyState
import br.rodrigo.memoria.ui.components.MomentCard
import br.rodrigo.memoria.ui.components.appContainer
import br.rodrigo.memoria.ui.theme.DateSerif
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime

class TodayViewModel(private val container: AppContainer) : ViewModel() {
    val todayMoments: StateFlow<List<Moment>> = container.moments.observeAll()
        .map { list ->
            val today = LocalDate.now()
            list.filter { it.occurredAt.withZoneSameInstant(ZoneId.systemDefault()).toLocalDate() == today }
                .sortedBy { it.occurredAt.toInstant() }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun removeDemo() {
        viewModelScope.launch { container.removeDemo() }
    }

    fun restoreDemo() {
        viewModelScope.launch { container.restoreDemo() }
    }
}

private enum class DemoAction { REMOVE, RESTORE }

@Composable
fun TodayScreen(
    onWrite: () -> Unit,
    onOpenMoment: (String) -> Unit,
    onReconstruct: () -> Unit,
) {
    val container = appContainer()
    val vm: TodayViewModel = viewModel { TodayViewModel(container) }
    val moments by vm.todayMoments.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    var menuOpen by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf<DemoAction?>(null) }
    val now = remember { ZonedDateTime.now() }

    fun notYet(message: String) {
        scope.launch { snackbar.showSnackbar(message) }
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = {},
                actions = {
                    Box {
                        IconButton(onClick = { menuOpen = true }) {
                            Icon(Icons.Outlined.MoreVert, contentDescription = "Mais opções")
                        }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(
                                text = { Text("Remover dados de demonstração") },
                                onClick = { menuOpen = false; confirm = DemoAction.REMOVE },
                            )
                            DropdownMenuItem(
                                text = { Text("Restaurar dados de demonstração") },
                                onClick = { menuOpen = false; confirm = DemoAction.RESTORE },
                            )
                        }
                    }
                },
            )
        },
    ) { padding ->
        LazyColumn(
            contentPadding = PaddingValues(
                start = 20.dp,
                end = 20.dp,
                top = padding.calculateTopPadding(),
                bottom = 24.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item {
                Column {
                    Text(
                        Formats.greeting(now.hour),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Text(
                        Formats.longDate(now),
                        style = MaterialTheme.typography.displaySmall,
                        fontFamily = DateSerif,
                    )
                }
            }
            item {
                Button(
                    onClick = { notYet("O registro por voz chega no Bloco B.") },
                    modifier = Modifier.fillMaxWidth().height(72.dp),
                    shape = RoundedCornerShape(20.dp),
                ) {
                    Icon(Icons.Outlined.Mic, contentDescription = null, modifier = Modifier.size(28.dp))
                    Spacer(Modifier.width(12.dp))
                    Text("Falar", style = MaterialTheme.typography.titleLarge)
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Shortcut(Icons.Outlined.PhotoCamera, "Fotografar", Modifier.weight(1f)) {
                        notYet("Fotografar chega no Bloco B.")
                    }
                    Shortcut(Icons.Outlined.Videocam, "Filmar", Modifier.weight(1f)) {
                        notYet("Filmar chega no Bloco B.")
                    }
                    Shortcut(Icons.Outlined.EditNote, "Escrever", Modifier.weight(1f), onClick = onWrite)
                }
            }
            item {
                Card(
                    onClick = onReconstruct,
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.tertiaryContainer,
                        contentColor = MaterialTheme.colorScheme.onTertiaryContainer,
                    ),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.History, contentDescription = null, modifier = Modifier.size(28.dp))
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text("Reconstruir meu dia", style = MaterialTheme.typography.titleMedium)
                            Text("Relembrar com perguntas e pistas", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
            item {
                Text("Guardado hoje", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(top = 8.dp))
            }
            if (moments.isEmpty()) {
                item {
                    EmptyState(
                        icon = Icons.Outlined.WbSunny,
                        title = "Nada guardado ainda hoje",
                        body = "Toque em Escrever para guardar o primeiro momento do dia.",
                    )
                }
            } else {
                items(moments, key = { it.id }) { m ->
                    MomentCard(m, onClick = { onOpenMoment(m.id) })
                }
            }
        }
    }

    confirm?.let { action ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = {
                Text(if (action == DemoAction.REMOVE) "Remover demonstração?" else "Restaurar demonstração?")
            },
            text = {
                Text(
                    if (action == DemoAction.REMOVE) {
                        "Apaga apenas os registros fictícios marcados como Demonstração. Seus próprios momentos não são tocados."
                    } else {
                        "Recria os registros fictícios de demonstração. Seus próprios momentos não são tocados."
                    },
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (action == DemoAction.REMOVE) vm.removeDemo() else vm.restoreDemo()
                    confirm = null
                }) { Text(if (action == DemoAction.REMOVE) "Remover" else "Restaurar") }
            },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("Cancelar") } },
        )
    }
}

@Composable
private fun Shortcut(icon: ImageVector, label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    FilledTonalButton(
        onClick = onClick,
        modifier = modifier.height(80.dp),
        shape = RoundedCornerShape(18.dp),
        contentPadding = PaddingValues(4.dp),
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, contentDescription = null)
            Spacer(Modifier.height(4.dp))
            Text(label, style = MaterialTheme.typography.labelLarge)
        }
    }
}
