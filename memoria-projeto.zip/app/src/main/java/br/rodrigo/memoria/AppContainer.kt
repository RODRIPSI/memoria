package br.rodrigo.memoria

import android.content.Context
import br.rodrigo.memoria.data.MomentRepository
import br.rodrigo.memoria.data.db.MemoriaDatabase
import br.rodrigo.memoria.data.demo.DemoData
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/** Liga as peças do app (injeção de dependências manual, sem bibliotecas extras). */
class AppContainer(context: Context) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences("memoria_prefs", Context.MODE_PRIVATE)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val database: MemoriaDatabase = MemoriaDatabase.build(appContext)
    val moments = MomentRepository(database)

    fun seedDemoIfFirstRun() {
        if (prefs.getBoolean(KEY_DEMO_SEEDED, false)) return
        scope.launch {
            DemoData.seed(moments)
            prefs.edit().putBoolean(KEY_DEMO_SEEDED, true).apply()
        }
    }

    suspend fun removeDemo() = moments.deleteDemo()

    suspend fun restoreDemo() {
        moments.deleteDemo()
        DemoData.seed(moments)
    }

    private companion object {
        const val KEY_DEMO_SEEDED = "demo_seeded"
    }
}
