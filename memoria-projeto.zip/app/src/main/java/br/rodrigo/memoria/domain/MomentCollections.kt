package br.rodrigo.memoria.domain

enum class CollectionKind(val title: String, val grouped: Boolean, val singular: String, val plural: String) {
    TODOS("Momentos", false, "momento", "momentos"),
    EVENTOS("Eventos", true, "evento", "eventos"),
    PESSOAS("Pessoas", true, "pessoa", "pessoas"),
    LUGARES("Lugares", true, "lugar", "lugares"),
    IDEIAS("Ideias e pensamentos", false, "momento", "momentos"),
    PRODUCOES("Produções", false, "momento", "momentos"),
    MARCOS("Marcos", false, "momento", "momentos"),
    FAVORITOS("Favoritos", false, "momento", "momentos");

    companion object {
        fun fromKey(key: String?): CollectionKind =
            entries.firstOrNull { it.name.equals(key, ignoreCase = true) } ?: TODOS
    }
}

data class CollectionGroup(val id: String, val name: String, val count: Int)

/**
 * Coleções são FILTROS sobre o mesmo conjunto de Momentos.
 * Nenhum registro ou arquivo é copiado para aparecer em várias coleções.
 */
object MomentCollections {

    fun matches(m: Moment, kind: CollectionKind, ref: String? = null): Boolean = when (kind) {
        CollectionKind.TODOS -> true
        CollectionKind.FAVORITOS -> m.isFavorite
        CollectionKind.MARCOS -> m.isMilestone
        CollectionKind.IDEIAS -> m.category == Category.IDEIA
        CollectionKind.PRODUCOES -> m.category == Category.PRODUCAO
        CollectionKind.EVENTOS -> if (ref != null) m.event?.id == ref else m.event != null
        CollectionKind.PESSOAS -> if (ref != null) m.people.any { it.id == ref } else m.people.isNotEmpty()
        CollectionKind.LUGARES -> if (ref != null) m.place?.id == ref else m.place != null
    }

    private fun refsOf(m: Moment, kind: CollectionKind): List<NamedRef> = when (kind) {
        CollectionKind.PESSOAS -> m.people
        CollectionKind.LUGARES -> listOfNotNull(m.place)
        CollectionKind.EVENTOS -> listOfNotNull(m.event)
        else -> emptyList()
    }

    fun groups(list: List<Moment>, kind: CollectionKind): List<CollectionGroup> =
        list.flatMap { refsOf(it, kind) }
            .groupBy { it.id }
            .map { (id, refs) -> CollectionGroup(id, refs.first().name, refs.size) }
            .sortedBy { it.name.lowercase() }

    fun summary(list: List<Moment>, kind: CollectionKind): String {
        val n = if (kind.grouped) groups(list, kind).size else list.count { matches(it, kind) }
        return "$n ${if (n == 1) kind.singular else kind.plural}"
    }
}
