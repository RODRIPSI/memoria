@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package br.rodrigo.memoria.ui.detail

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import br.rodrigo.memoria.AppContainer
import br.rodrigo.memoria.domain.Category
import br.rodrigo.memoria.domain.CollectionKind
import br.rodrigo.memoria.domain.Formats
import br.rodrigo.memoria.domain.Moment
import br.rodrigo.memoria.ui.components.LoadingBox
import br.rodrigo.memoria.ui.components.appContainer
import br.rodrigo.memoria.ui.components.captionOf
import br.rodrigo.memoria.ui.components.shareText
import br.rodrigo.memoria.ui.theme.DateSerif
import br.rodrigo.memoria.ui.theme.favoriteColor
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.Duration
import java.time.ZoneId

sealed interface DetailState {
    data object Loading : DetailState
    data object Missing : DetailState
    data class Loaded(val moment: Moment) : DetailState
}

class MomentDetailViewModel(private val container: AppContainer, id: String) : ViewModel() {
    val state: StateFlow<DetailState> = container.moments.observe(id)
        .map { if (it == null) DetailState.Missing else DetailState.Loaded(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), DetailState.Loading)

    fun toggleFavorite(m: Moment) {
        viewModelScope.launch { container.moments.setFavorite(m.id, !m.isFavorite) }
    }

    fun toggleMilestone(m: Moment) {
        viewModelScope.launch { container.moments.setMilestone(m.id, !m.isMilestone) }
    }

    fun moveToTrash(id: String, done: () -> Unit) {
        viewModelScope.launch {
            container.moments.moveToTrash(id)
            done()
        }
    }
}

@Composable
fun MomentDetailScreen(
    id: String,
    onBack: () -> Unit,
    onEdit: (String) -> Unit,
    onOpenCollection: (CollectionKind, String?) -> Unit,
) {
    val container = appContainer()
    val vm: MomentDetailViewModel = viewModel(key = "detalhe-$id") { MomentDetailViewModel(container, id) }
    val state by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    var menuOpen by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    val moment = (state as? DetailState.Loaded)?.moment

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = {},
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar")
                    }
                },
                actions = {
                    if (moment != null) {
                        IconButton(onClick = { vm.toggleFavorite(moment) }) {
                            if (moment.isFavorite) {
                                Icon(Icons.Filled.Favorite, "Remover dos favoritos", tint = favoriteColor())
                            } else {
                                Icon(Icons.Filled.FavoriteBorder, "Marcar como favorito")
                            }
                        }
                        IconButton(onClick = { vm.toggleMilestone(moment) }) {
                            if (moment.isMilestone) {
                                Icon(Icons.Filled.Flag, "Desmarcar como marco", tint = MaterialTheme.colorScheme.tertiary)
                            } else {
                                Icon(Icons.Outlined.Flag, "Marcar como marco importante")
                            }
                        }
                        IconButton(onClick = { onEdit(moment.id) }) {
                            Icon(Icons.Outlined.Edit, contentDescription = "Editar")
                        }
                        Box {
                            IconButton(onClick = { menuOpen = true }) {
                                Icon(Icons.Outlined.MoreVert, contentDescription = "Mais opções")
                            }
                            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                                DropdownMenuItem(
                                    text = { Text("Copiar legenda") },
                                    leadingIcon = { Icon(Icons.Outlined.ContentCopy, contentDescription = null) },
                                    onClick = {
                                        menuOpen = false
                                        clipboard.setText(AnnotatedString(captionOf(moment)))
                                        scope.launch { snackbar.showSnackbar("Legenda copiada.") }
                                    },
                                )
                                DropdownMenuItem(
                                    text = { Text("Compartilhar") },
                                    leadingIcon = { Icon(Icons.Outlined.Share, contentDescription = null) },
                                    onClick = {
                                        menuOpen = false
                                        shareText(context, captionOf(moment))
                                    },
                                )
                                DropdownMenuItem(
                                    text = { Text("Excluir") },
                                    leadingIcon = { Icon(Icons.Outlined.Delete, contentDescription = null) },
                                    onClick = {
                                        menuOpen = false
                                        confirmDelete = true
                                    },
                                )
                            }
                        }
                    }
                },
            )
        },
    ) { padding ->
        when (val s = state) {
            DetailState.Loading -> LoadingBox(Modifier.padding(padding))
            DetailState.Missing -> Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Este momento não está mais disponível.", style = MaterialTheme.typography.bodyLarge)
            }
            is DetailState.Loaded -> DetailContent(s.moment, Modifier.padding(padding), onOpenCollection)
        }
    }

    if (confirmDelete && moment != null) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Mover para a Lixeira?") },
            text = {
                Text(
                    "O momento sai das listas, mas não é apagado de vez: poderá ser recuperado. " +
                        "(A tela da Lixeira chega no Bloco B.)",
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    vm.moveToTrash(moment.id) { onBack() }
                }) { Text("Mover para a Lixeira") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancelar") } },
        )
    }
}

@Composable
private fun DetailContent(m: Moment, modifier: Modifier, onOpenCollection: (CollectionKind, String?) -> Unit) {
    Column(
        modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
    ) {
        Column {
            Text(
                Formats.longDateYear(m.occurredAt),
                style = MaterialTheme.typography.titleMedium,
                fontFamily = DateSerif,
                color = MaterialTheme.colorScheme.primary,
            )
            Text(
                "às ${Formats.time(m.occurredAt)}",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        if (m.title != null) {
            Text(m.title, style = MaterialTheme.typography.headlineSmall)
        }
        Text(m.body, style = MaterialTheme.typography.bodyLarge)

        if (!m.transcript.isNullOrBlank() && m.transcript != m.body) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Transcrição", style = MaterialTheme.typography.labelLarge)
                Text(m.transcript, style = MaterialTheme.typography.bodyMedium)
            }
        }

        val hasLinks = m.people.isNotEmpty() || m.place != null || m.event != null || m.category != Category.COTIDIANO
        if (hasLinks) {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                m.people.forEach { p ->
                    LinkChip(Icons.Outlined.Person, p.name) { onOpenCollection(CollectionKind.PESSOAS, p.id) }
                }
                m.place?.let { pl ->
                    LinkChip(Icons.Outlined.Place, pl.name) { onOpenCollection(CollectionKind.LUGARES, pl.id) }
                }
                m.event?.let { ev ->
                    LinkChip(Icons.Outlined.Celebration, ev.name) { onOpenCollection(CollectionKind.EVENTOS, ev.id) }
                }
                when (m.category) {
                    Category.IDEIA -> LinkChip(Icons.Outlined.Lightbulb, m.category.label) {
                        onOpenCollection(CollectionKind.IDEIAS, null)
                    }
                    Category.PRODUCAO -> LinkChip(Icons.Outlined.Create, m.category.label) {
                        onOpenCollection(CollectionKind.PRODUCOES, null)
                    }
                    Category.COTIDIANO -> Unit
                }
            }
        }

        InfoCard(m)
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun LinkChip(icon: ImageVector, label: String, onClick: () -> Unit) {
    AssistChip(
        onClick = onClick,
        label = { Text(label) },
        leadingIcon = { Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp)) },
    )
}

@Composable
private fun InfoCard(m: Moment) {
    val created = m.createdAt.atZone(ZoneId.systemDefault())
    val registeredLater = Duration.between(m.occurredAt.toInstant(), m.createdAt).toMinutes() > 30
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            InfoRow(
                Icons.Outlined.Schedule,
                "Registrado em ${Formats.shortDate(created)} às ${Formats.time(created)}" +
                    if (registeredLater) " (depois do acontecimento)" else "",
            )
            InfoRow(Icons.Outlined.Info, "Origem: ${m.source.label}")
            InfoRow(Icons.Outlined.CloudOff, m.syncStatus.label)
            if (m.isDemo) InfoRow(Icons.Outlined.Science, "Registro fictício de demonstração")
        }
    }
}

@Composable
private fun InfoRow(icon: ImageVector, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.width(10.dp))
        Text(text, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
