@file:OptIn(ExperimentalMaterial3Api::class)

package br.rodrigo.memoria.ui.save

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

@Composable
fun SaveHubScreen(onWrite: () -> Unit) {
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    fun notYet(what: String) {
        scope.launch { snackbar.showSnackbar("$what chega no Bloco B.") }
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = { TopAppBar(title = { Text("Guardar um momento") }) },
    ) { padding ->
        Column(
            Modifier.padding(padding).padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text(
                "Como você quer guardar?",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                HubOption(Icons.Outlined.Mic, "Falar", "Bloco B", Modifier.weight(1f)) { notYet("Falar") }
                HubOption(Icons.Outlined.PhotoCamera, "Fotografar", "Bloco B", Modifier.weight(1f)) { notYet("Fotografar") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                HubOption(Icons.Outlined.Videocam, "Filmar", "Bloco B", Modifier.weight(1f)) { notYet("Filmar") }
                HubOption(Icons.Outlined.EditNote, "Escrever", null, Modifier.weight(1f), onClick = onWrite)
            }
        }
    }
}

@Composable
private fun HubOption(
    icon: ImageVector,
    label: String,
    pendingNote: String?,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val available = pendingNote == null
    Card(
        onClick = onClick,
        modifier = modifier.height(150.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (available) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainerHigh,
            contentColor = if (available) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
        ),
    ) {
        Column(
            Modifier.fillMaxSize().padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(40.dp))
            Spacer(Modifier.height(10.dp))
            Text(label, style = MaterialTheme.typography.titleMedium)
            if (pendingNote != null) {
                Text("Chega no $pendingNote", style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}
