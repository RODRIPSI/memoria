package br.rodrigo.memoria.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        MomentEntity::class,
        PersonEntity::class,
        PlaceEntity::class,
        EventEntity::class,
        TagEntity::class,
        MomentPersonCrossRef::class,
        MomentTagCrossRef::class,
        MediaReferenceEntity::class,
    ],
    version = 1,
    exportSchema = true,
)
abstract class MemoriaDatabase : RoomDatabase() {
    abstract fun momentDao(): MomentDao

    companion object {
        const val NAME = "memoria.db"

        // Sem "fallbackToDestructiveMigration": mudanças de esquema sempre por migração,
        // para nunca apagar dados do usuário.
        fun build(context: Context): MemoriaDatabase =
            Room.databaseBuilder(context, MemoriaDatabase::class.java, NAME).build()
    }
}
