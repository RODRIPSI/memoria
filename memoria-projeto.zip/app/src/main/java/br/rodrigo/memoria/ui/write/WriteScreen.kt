@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package br.rodrigo.memoria.ui.write

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import br.rodrigo.memoria.AppContainer
import br.rodrigo.memoria.domain.Category
import br.rodrigo.memoria.domain.Formats
import br.rodrigo.memoria.domain.MomentDraft
import br.rodrigo.memoria.domain.Source
import br.rodrigo.memoria.ui.components.appContainer
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.ZonedDateTime

class WriteViewModel(private val container: AppContainer, private val editId: String?) : ViewModel() {
    var title by mutableStateOf("")
    var body by mutableStateOf("")
    var occurredAt by mutableStateOf(ZonedDateTime.now())
        private set
    var occurredEdited by mutableStateOf(false)
        private set
    var category by mutableStateOf(Category.COTIDIANO)
    var people by mutableStateOf("")
    var place by mutableStateOf("")
    var event by mutableStateOf("")
    var isFavorite by mutableStateOf(false)
    var isMilestone by mutableStateOf(false)
    var showDetails by mutableStateOf(false)
    var loaded by mutableStateOf(editId == null)
        private set
    var saving by mutableStateOf(false)
        private set

    private var source = Source.TEXTO

    init {
        if (editId != null) {
            viewModelScope.launch {
                container.moments.observe(editId).first()?.let { m ->
                    title = m.title.orEmpty()
                    body = m.body
                    occurredAt = m.occurredAt
                    occurredEdited = true
                    category = m.category
                    people = m.people.joinToString(", ") { it.name }
                    place = m.place?.name.orEmpty()
                    event = m.event?.name.orEmpty()
                    isFavorite = m.isFavorite
                    isMilestone = m.isMilestone
                    source = m.source
                    showDetails = people.isNotBlank() || place.isNotBlank() || event.isNotBlank() ||
                        isFavorite || isMilestone
                }
                loaded = true
            }
        }
    }

    val canSave: Boolean get() = loaded && !saving && body.isNotBlank()

    fun setOccurred(value: ZonedDateTime) {
        occurredAt = value
        occurredEdited = true
    }

    fun save(onSaved: (String) -> Unit) {
        if (!canSave) return
        saving = true
        viewModelScope.launch {
            val id = container.moments.save(
                MomentDraft(
                    id = editId,
                    title = title,
                    body = body,
                    occurredAt = occurredAt,
                    category = category,
                    people = people.split(',', ';').map { it.trim() }.filter { it.isNotEmpty() },
                    place = place,
                    event = event,
                    isFavorite = isFavorite,
                    isMilestone = isMilestone,
                    source = source,
                ),
            )
            saving = false
            onSaved(id)
        }
    }
}

@Composable
fun WriteScreen(editId: String?, onClose: () -> Unit, onSaved: (String) -> Unit) {
    val container = appContainer()
    val vm: WriteViewModel = viewModel(key = "write-${editId ?: "novo"}") { WriteViewModel(container, editId) }
    var showDate by remember { mutableStateOf(false) }
    var showTime by remember { mutableStateOf(false) }
    var pendingDate by remember { mutableStateOf<LocalDate?>(null) }
    val focus = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        if (editId == null) runCatching { focus.requestFocus() }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (editId == null) "Escrever" else "Editar momento") },
                navigationIcon = {
                    IconButton(onClick = onClose) {
                        Icon(Icons.Outlined.Close, contentDescription = "Fechar sem guardar")
                    }
                },
                actions = {
                    TextButton(onClick = { vm.save(onSaved) }, enabled = vm.canSave) {
                        Text("Guardar")
                    }
                },
            )
        },
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .consumeWindowInsets(padding)
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            OutlinedTextField(
                value = vm.title,
                onValueChange = { vm.title = it },
                label = { Text("Título (opcional)") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = vm.body,
                onValueChange = { vm.body = it },
                label = { Text("O que aconteceu?") },
                minLines = 6,
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                modifier = Modifier.fillMaxWidth().focusRequester(focus),
            )

            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Quando aconteceu", style = MaterialTheme.typography.labelLarge)
                AssistChip(
                    onClick = { showDate = true },
                    label = {
                        Text(
                            if (!vm.occurredEdited) {
                                "Agora, ${Formats.time(vm.occurredAt)}"
                            } else {
                                "${Formats.longDate(vm.occurredAt)}, ${Formats.time(vm.occurredAt)}"
                            },
                        )
                    },
                    leadingIcon = { Icon(Icons.Outlined.Event, contentDescription = null) },
                )
                Text(
                    "A data em que você está registrando é guardada separadamente.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Tipo", style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Category.entries.forEach { c ->
                        FilterChip(
                            selected = vm.category == c,
                            onClick = { vm.category = c },
                            label = { Text(c.label) },
                        )
                    }
                }
            }

            TextButton(onClick = { vm.showDetails = !vm.showDetails }) {
                Icon(
                    if (vm.showDetails) Icons.Outlined.ExpandLess else Icons.Outlined.ExpandMore,
                    contentDescription = null,
                )
                Spacer(Modifier.width(6.dp))
                Text(if (vm.showDetails) "Menos detalhes" else "Pessoas, lugar e marcações")
            }

            AnimatedVisibility(visible = vm.showDetails) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = vm.people,
                        onValueChange = { vm.people = it },
                        label = { Text("Pessoas") },
                        supportingText = { Text("Separe os nomes por vírgula") },
                        leadingIcon = { Icon(Icons.Outlined.People, contentDescription = null) },
                        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = vm.place,
                        onValueChange = { vm.place = it },
                        label = { Text("Lugar") },
                        singleLine = true,
                        leadingIcon = { Icon(Icons.Outlined.Place, contentDescription = null) },
                        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = vm.event,
                        onValueChange = { vm.event = it },
                        label = { Text("Evento") },
                        placeholder = { Text("Ex.: Aniversário do Tomás") },
                        singleLine = true,
                        leadingIcon = { Icon(Icons.Outlined.Celebration, contentDescription = null) },
                        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                        modifier = Modifier.fillMaxWidth(),
                    )
                    ToggleRow("Favorito", vm.isFavorite) { vm.isFavorite = it }
                    ToggleRow("Marco importante", vm.isMilestone) { vm.isMilestone = it }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (showDate) {
        val state = rememberDatePickerState(
            initialSelectedDateMillis = vm.occurredAt.toLocalDate().atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli(),
        )
        DatePickerDialog(
            onDismissRequest = { showDate = false },
            confirmButton = {
                TextButton(onClick = {
                    pendingDate = state.selectedDateMillis?.let {
                        Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate()
                    }
                    showDate = false
                    showTime = true
                }) { Text("Próximo") }
            },
            dismissButton = { TextButton(onClick = { showDate = false }) { Text("Cancelar") } },
        ) {
            DatePicker(state = state)
        }
    }

    if (showTime) {
        val state = rememberTimePickerState(
            initialHour = vm.occurredAt.hour,
            initialMinute = vm.occurredAt.minute,
            is24Hour = true,
        )
        AlertDialog(
            onDismissRequest = { showTime = false },
            title = { Text("Horário") },
            text = { TimeInput(state = state) },
            confirmButton = {
                TextButton(onClick = {
                    val date = pendingDate ?: vm.occurredAt.toLocalDate()
                    vm.setOccurred(ZonedDateTime.of(date, LocalTime.of(state.hour, state.minute), ZoneId.systemDefault()))
                    showTime = false
                }) { Text("Confirmar") }
            },
            dismissButton = { TextButton(onClick = { showTime = false }) { Text("Cancelar") } },
        )
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
            .toggleable(value = checked, onValueChange = onChange, role = Role.Switch),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = null)
    }
}
