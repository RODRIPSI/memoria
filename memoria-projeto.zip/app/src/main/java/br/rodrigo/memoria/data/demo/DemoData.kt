package br.rodrigo.memoria.data.demo

import br.rodrigo.memoria.data.MomentRepository
import br.rodrigo.memoria.domain.Category
import br.rodrigo.memoria.domain.MomentDraft
import br.rodrigo.memoria.domain.Source
import java.time.LocalTime
import java.time.ZonedDateTime

/**
 * Dados 100% FICTÍCIOS, marcados como demonstração.
 * Podem ser removidos ou restaurados pelo menu da tela Hoje.
 */
object DemoData {

    suspend fun seed(repo: MomentRepository, now: ZonedDateTime = ZonedDateTime.now()) {
        val zone = now.zone
        val today = now.toLocalDate()
        fun at(daysAgo: Long, h: Int, m: Int): ZonedDateTime =
            ZonedDateTime.of(today.minusDays(daysAgo), LocalTime.of(h, m), zone)

        fun demo(
            occurred: ZonedDateTime,
            body: String,
            title: String? = null,
            category: Category = Category.COTIDIANO,
            people: List<String> = emptyList(),
            place: String? = null,
            event: String? = null,
            favorite: Boolean = false,
            milestone: Boolean = false,
            registeredMinutesLater: Long = 5,
        ) = MomentDraft(
            title = title,
            body = body,
            occurredAt = occurred,
            category = category,
            people = people,
            place = place,
            event = event,
            isFavorite = favorite,
            isMilestone = milestone,
            source = Source.DEMO,
            isDemo = true,
            createdAtOverride = occurred.plusMinutes(registeredMinutesLater).toInstant(),
        )

        val drafts = listOf(
            demo(
                now.minusHours(3),
                "Organizei a mesa de trabalho e separei os livros que vou usar nesta semana.",
                place = "Casa",
            ),
            demo(
                now.minusMinutes(50),
                "Acabei de almoçar. Comi arroz, feijão e carne. Depois vou trabalhar no site.",
                place = "Restaurante Sabor da Vila",
            ),
            demo(
                at(1, 15, 20),
                "Encontrei a Helena no café e conversamos sobre a viagem que ela está planejando para o fim do ano.",
                title = "Conversa com Helena",
                people = listOf("Helena"),
                place = "Café Aurora",
                favorite = true,
            ),
            demo(
                at(1, 21, 30),
                "Reunir as anotações soltas do semestre em grupos por tema, antes de começar a escrever.",
                title = "Organizar anotações por tema",
                category = Category.IDEIA,
            ),
            demo(
                at(3, 17, 0),
                "Terminei o primeiro rascunho do texto sobre memória e lembrança. Ainda falta revisar a conclusão.",
                title = "Rascunho concluído",
                category = Category.PRODUCAO,
                milestone = true,
            ),
            demo(
                at(5, 19, 30),
                "Jantar de aniversário do Tomás. Teve bolo de chocolate e muita conversa sobre os tempos de escola.",
                people = listOf("Tomás", "Helena"),
                place = "Casa do Tomás",
                event = "Aniversário do Tomás",
                favorite = true,
                registeredMinutesLater = 20 * 60, // registrado no dia seguinte
            ),
            demo(
                at(9, 7, 15),
                "Caminhada cedo na praça. O dia estava fresco e com pouco movimento.",
                place = "Praça das Mangueiras",
            ),
            demo(
                at(16, 13, 0),
                "Almoço de domingo na casa da Carmem. Ela contou histórias antigas da família.",
                people = listOf("Carmem"),
                place = "Casa da Carmem",
            ),
            demo(
                at(35, 9, 0),
                "Primeira aula do curso de fotografia. Aprendi sobre luz natural e enquadramento.",
                title = "Primeiro dia do curso de fotografia",
                event = "Curso de fotografia",
                milestone = true,
            ),
            demo(
                at(70, 11, 0),
                "Viagem curta para a serra. Frio, trilha leve e um almoço demorado.",
                title = "Fim de semana na serra",
                place = "Serra Azul",
                favorite = true,
            ),
        )
        drafts.forEach { repo.save(it) }
    }
}
