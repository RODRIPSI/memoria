@file:OptIn(ExperimentalMaterial3Api::class)

package br.rodrigo.memoria.ui.memories

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import br.rodrigo.memoria.AppContainer
import br.rodrigo.memoria.domain.CollectionKind
import br.rodrigo.memoria.domain.Formats
import br.rodrigo.memoria.domain.Moment
import br.rodrigo.memoria.domain.MomentCollections
import br.rodrigo.memoria.domain.Timeline
import br.rodrigo.memoria.ui.components.EmptyState
import br.rodrigo.memoria.ui.components.LoadingBox
import br.rodrigo.memoria.ui.components.MomentCard
import br.rodrigo.memoria.ui.components.appContainer
import br.rodrigo.memoria.ui.theme.DateHeading
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn

/** Todos os Momentos ativos. Linha do tempo e coleções são visões deste mesmo conjunto. */
class LibraryViewModel(container: AppContainer) : ViewModel() {
    val moments: StateFlow<List<Moment>?> = container.moments.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)
}

@Composable
private fun libraryMoments(): List<Moment>? {
    val container = appContainer()
    val vm: LibraryViewModel = viewModel { LibraryViewModel(container) }
    val list by vm.moments.collectAsStateWithLifecycle()
    return list
}

fun iconFor(kind: CollectionKind): ImageVector = when (kind) {
    CollectionKind.TODOS -> Icons.Outlined.Collections
    CollectionKind.EVENTOS -> Icons.Outlined.Celebration
    CollectionKind.PESSOAS -> Icons.Outlined.People
    CollectionKind.LUGARES -> Icons.Outlined.Place
    CollectionKind.IDEIAS -> Icons.Outlined.Lightbulb
    CollectionKind.PRODUCOES -> Icons.Outlined.Create
    CollectionKind.MARCOS -> Icons.Outlined.Flag
    CollectionKind.FAVORITOS -> Icons.Outlined.FavoriteBorder
}

@Composable
fun MemoriesScreen(
    onOpenMoment: (String) -> Unit,
    onOpenCollection: (CollectionKind, String?) -> Unit,
    onOpenGroups: (CollectionKind) -> Unit,
) {
    val moments = libraryMoments()
    var tab by rememberSaveable { mutableIntStateOf(0) }

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            Column {
                TopAppBar(title = { Text("Memórias") })
                TabRow(selectedTabIndex = tab) {
                    Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Linha do tempo") })
                    Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Coleções") })
                }
            }
        },
    ) { padding ->
        when {
            moments == null -> LoadingBox(Modifier.padding(padding))
            tab == 0 -> TimelineList(moments, padding, onOpenMoment)
            else -> CollectionsGrid(moments, padding, onOpenCollection, onOpenGroups)
        }
    }
}

@Composable
private fun TimelineList(moments: List<Moment>, padding: PaddingValues, onOpenMoment: (String) -> Unit) {
    if (moments.isEmpty()) {
        EmptyState(
            icon = Icons.Outlined.AutoStories,
            title = "Sua linha do tempo está vazia",
            body = "Os momentos que você guardar aparecem aqui, organizados por ano, mês, semana e dia.",
            modifier = Modifier.padding(padding),
        )
        return
    }
    val tree = remember(moments) { Timeline.build(moments) { it.occurredAt } }
    val defaults = remember(tree) {
        buildSet {
            val y = tree.firstOrNull() ?: return@buildSet
            add(y.key)
            val m = y.months.firstOrNull() ?: return@buildSet
            add(m.key)
            val w = m.weeks.firstOrNull() ?: return@buildSet
            add(w.key)
            w.days.firstOrNull()?.let { add(it.key) }
        }
    }
    val toggled = remember { mutableStateMapOf<String, Boolean>() }
    fun isOpen(key: String): Boolean = toggled[key] ?: (key in defaults)
    fun flip(key: String) {
        toggled[key] = !isOpen(key)
    }

    LazyColumn(
        contentPadding = PaddingValues(
            start = 12.dp,
            end = 16.dp,
            top = padding.calculateTopPadding() + 8.dp,
            bottom = 24.dp,
        ),
    ) {
        tree.forEach { year ->
            item(key = year.key) {
                LevelHeader(0, year.year.toString(), year.count, isOpen(year.key)) { flip(year.key) }
            }
            if (isOpen(year.key)) {
                year.months.forEach { month ->
                    item(key = month.key) {
                        LevelHeader(1, Formats.monthName(month.month), month.count, isOpen(month.key)) { flip(month.key) }
                    }
                    if (isOpen(month.key)) {
                        month.weeks.forEach { week ->
                            item(key = week.key) {
                                LevelHeader(2, week.label, week.count, isOpen(week.key)) { flip(week.key) }
                            }
                            if (isOpen(week.key)) {
                                week.days.forEach { day ->
                                    item(key = day.key) {
                                        LevelHeader(3, Formats.dayHeader(day.date), day.items.size, isOpen(day.key)) {
                                            flip(day.key)
                                        }
                                    }
                                    if (isOpen(day.key)) {
                                        items(day.items, key = { it.id }) { m ->
                                            MomentCard(
                                                m,
                                                onClick = { onOpenMoment(m.id) },
                                                modifier = Modifier.padding(start = 24.dp),
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LevelHeader(level: Int, text: String, count: Int, open: Boolean, onClick: () -> Unit) {
    val style = when (level) {
        0 -> MaterialTheme.typography.headlineSmall
        1 -> DateHeading
        2 -> MaterialTheme.typography.titleSmall
        else -> MaterialTheme.typography.labelLarge
    }
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 48.dp)
            .clickable(onClickLabel = if (open) "Recolher" else "Expandir", onClick = onClick)
            .padding(start = (level * 8).dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            if (open) Icons.Outlined.ExpandMore else Icons.Outlined.ChevronRight,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.width(6.dp))
        Text(text, style = style, modifier = Modifier.weight(1f))
        Text(
            count.toString(),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun CollectionsGrid(
    moments: List<Moment>,
    padding: PaddingValues,
    onOpenCollection: (CollectionKind, String?) -> Unit,
    onOpenGroups: (CollectionKind) -> Unit,
) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        contentPadding = PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = padding.calculateTopPadding() + 12.dp,
            bottom = 24.dp,
        ),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        items(CollectionKind.entries) { kind ->
            Card(
                onClick = { if (kind.grouped) onOpenGroups(kind) else onOpenCollection(kind, null) },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                modifier = Modifier.fillMaxWidth().height(116.dp),
            ) {
                Column(Modifier.padding(16.dp).fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
                    Icon(iconFor(kind), contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Column {
                        Text(kind.title, style = MaterialTheme.typography.titleSmall)
                        Text(
                            MomentCollections.summary(moments, kind),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
        item(span = { GridItemSpan(maxLineSpan) }) {
            Text(
                "Cada momento é guardado uma única vez. As coleções são formas diferentes de encontrá-lo.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 8.dp),
            )
        }
    }
}

@Composable
fun GroupsScreen(kind: CollectionKind, onBack: () -> Unit, onOpenGroup: (CollectionKind, String?) -> Unit) {
    val moments = libraryMoments()
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(kind.title) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar")
                    }
                },
            )
        },
    ) { padding ->
        if (moments == null) {
            LoadingBox(Modifier.padding(padding))
            return@Scaffold
        }
        val groups = remember(moments, kind) { MomentCollections.groups(moments, kind) }
        if (groups.isEmpty()) {
            EmptyState(
                icon = iconFor(kind),
                title = "Nenhum registro ainda",
                body = "Ao escrever um momento, use \"Pessoas, lugar e marcações\" para preencher esta coleção.",
                modifier = Modifier.padding(padding),
            )
            return@Scaffold
        }
        LazyColumn(contentPadding = padding) {
            items(groups, key = { it.id }) { g ->
                ListItem(
                    headlineContent = { Text(g.name) },
                    supportingContent = { Text("${g.count} ${if (g.count == 1) "momento" else "momentos"}") },
                    leadingContent = { Icon(iconFor(kind), contentDescription = null) },
                    modifier = Modifier.clickable { onOpenGroup(kind, g.id) },
                )
            }
        }
    }
}

@Composable
fun CollectionScreen(kind: CollectionKind, ref: String?, onBack: () -> Unit, onOpenMoment: (String) -> Unit) {
    val moments = libraryMoments()
    val title = remember(moments, kind, ref) {
        if (ref == null || moments == null) {
            kind.title
        } else {
            MomentCollections.groups(moments, kind).firstOrNull { it.id == ref }?.name ?: kind.title
        }
    }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar")
                    }
                },
            )
        },
    ) { padding ->
        if (moments == null) {
            LoadingBox(Modifier.padding(padding))
            return@Scaffold
        }
        val filtered = remember(moments, kind, ref) { moments.filter { MomentCollections.matches(it, kind, ref) } }
        if (filtered.isEmpty()) {
            EmptyState(
                icon = iconFor(kind),
                title = "Nada aqui por enquanto",
                body = "Momentos marcados assim aparecerão nesta coleção.",
                modifier = Modifier.padding(padding),
            )
            return@Scaffold
        }
        LazyColumn(
            contentPadding = PaddingValues(
                start = 12.dp,
                end = 16.dp,
                top = padding.calculateTopPadding() + 8.dp,
                bottom = padding.calculateBottomPadding() + 16.dp,
            ),
        ) {
            items(filtered, key = { it.id }) { m ->
                MomentCard(m, onClick = { onOpenMoment(m.id) }, showDate = true)
            }
        }
    }
}
