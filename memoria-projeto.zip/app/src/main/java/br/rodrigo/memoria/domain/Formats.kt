package br.rodrigo.memoria.domain

import java.time.LocalDate
import java.time.Month
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.time.temporal.TemporalAccessor
import java.util.Locale

object Formats {
    val ptBR: Locale = Locale.forLanguageTag("pt-BR")

    private val longDateF = DateTimeFormatter.ofPattern("EEEE, d 'de' MMMM", ptBR)
    private val longDateYearF = DateTimeFormatter.ofPattern("EEEE, d 'de' MMMM 'de' yyyy", ptBR)
    private val dayHeaderF = DateTimeFormatter.ofPattern("EEEE, d", ptBR)
    private val timeF = DateTimeFormatter.ofPattern("HH:mm", ptBR)
    private val shortDateF = DateTimeFormatter.ofPattern("dd/MM/yyyy", ptBR)

    fun cap(s: String): String = s.replaceFirstChar { if (it.isLowerCase()) it.titlecase(ptBR) else it.toString() }

    fun longDate(t: TemporalAccessor): String = cap(longDateF.format(t))
    fun longDateYear(t: TemporalAccessor): String = cap(longDateYearF.format(t))
    fun dayHeader(d: LocalDate): String = cap(dayHeaderF.format(d))
    fun time(t: TemporalAccessor): String = timeF.format(t)
    fun shortDate(t: TemporalAccessor): String = shortDateF.format(t)
    fun monthName(month: Int): String = cap(Month.of(month).getDisplayName(TextStyle.FULL, ptBR))

    fun greeting(hour: Int): String = when {
        hour < 5 -> "Boa noite"
        hour < 12 -> "Bom dia"
        hour < 18 -> "Boa tarde"
        else -> "Boa noite"
    }
}
