package br.rodrigo.memoria.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import br.rodrigo.memoria.domain.CollectionKind
import br.rodrigo.memoria.ui.detail.MomentDetailScreen
import br.rodrigo.memoria.ui.memories.CollectionScreen
import br.rodrigo.memoria.ui.memories.GroupsScreen
import br.rodrigo.memoria.ui.memories.MemoriesScreen
import br.rodrigo.memoria.ui.planned.HealthPlaceholder
import br.rodrigo.memoria.ui.planned.ReconstructPlaceholder
import br.rodrigo.memoria.ui.save.SaveHubScreen
import br.rodrigo.memoria.ui.today.TodayScreen
import br.rodrigo.memoria.ui.write.WriteScreen

object Routes {
    const val TODAY = "hoje"
    const val MEMORIES = "memorias"
    const val SAVE = "guardar"
    const val HEALTH = "saude"
    const val RECONSTRUCT = "reconstruir"
    const val WRITE = "escrever?id={id}"
    const val DETAIL = "momento/{id}"
    const val COLLECTION = "colecao/{kind}?ref={ref}"
    const val GROUPS = "grupos/{kind}"

    val tabs = setOf(TODAY, MEMORIES, SAVE, HEALTH, RECONSTRUCT)

    fun write(id: String? = null) = if (id == null) "escrever" else "escrever?id=$id"
    fun detail(id: String) = "momento/$id"
    fun collection(kind: CollectionKind, ref: String?) =
        if (ref == null) "colecao/${kind.name}" else "colecao/${kind.name}?ref=$ref"
    fun groups(kind: CollectionKind) = "grupos/${kind.name}"
}

private data class NavTab(val route: String, val label: String, val icon: ImageVector, val selectedIcon: ImageVector)

private val tabs = listOf(
    NavTab(Routes.TODAY, "Hoje", Icons.Outlined.WbSunny, Icons.Filled.WbSunny),
    NavTab(Routes.MEMORIES, "Memórias", Icons.Outlined.AutoStories, Icons.Filled.AutoStories),
    NavTab(Routes.SAVE, "Guardar", Icons.Filled.Add, Icons.Filled.Add),
    NavTab(Routes.HEALTH, "Saúde", Icons.Outlined.HealthAndSafety, Icons.Filled.HealthAndSafety),
    NavTab(Routes.RECONSTRUCT, "Reconstruir", Icons.Outlined.Extension, Icons.Filled.Extension),
)

@Composable
fun MemoriaRoot() {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val current = entry?.destination?.route

    val goTab: (String) -> Unit = { route ->
        nav.navigate(route) {
            popUpTo(nav.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }
    val openMoment: (String) -> Unit = { nav.navigate(Routes.detail(it)) }
    val openCollection: (CollectionKind, String?) -> Unit = { k, ref -> nav.navigate(Routes.collection(k, ref)) }
    val openGroups: (CollectionKind) -> Unit = { nav.navigate(Routes.groups(it)) }

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = { if (current in Routes.tabs) MemoriaBottomBar(current, goTab) },
    ) { padding ->
        NavHost(
            navController = nav,
            startDestination = Routes.TODAY,
            modifier = Modifier.padding(bottom = padding.calculateBottomPadding()),
        ) {
            composable(Routes.TODAY) {
                TodayScreen(
                    onWrite = { nav.navigate(Routes.write()) },
                    onOpenMoment = openMoment,
                    onReconstruct = { goTab(Routes.RECONSTRUCT) },
                )
            }
            composable(Routes.MEMORIES) {
                MemoriesScreen(onOpenMoment = openMoment, onOpenCollection = openCollection, onOpenGroups = openGroups)
            }
            composable(Routes.SAVE) {
                SaveHubScreen(onWrite = { nav.navigate(Routes.write()) })
            }
            composable(Routes.HEALTH) { HealthPlaceholder() }
            composable(Routes.RECONSTRUCT) { ReconstructPlaceholder() }

            composable(
                Routes.WRITE,
                arguments = listOf(navArgument("id") { type = NavType.StringType; nullable = true; defaultValue = null }),
            ) { e ->
                val editId = e.arguments?.getString("id")
                WriteScreen(
                    editId = editId,
                    onClose = { nav.popBackStack() },
                    onSaved = { savedId ->
                        if (editId == null) {
                            nav.navigate(Routes.detail(savedId)) { popUpTo(Routes.WRITE) { inclusive = true } }
                        } else {
                            nav.popBackStack()
                        }
                    },
                )
            }
            composable(Routes.DETAIL, arguments = listOf(navArgument("id") { type = NavType.StringType })) { e ->
                MomentDetailScreen(
                    id = e.arguments?.getString("id").orEmpty(),
                    onBack = { nav.popBackStack() },
                    onEdit = { nav.navigate(Routes.write(it)) },
                    onOpenCollection = openCollection,
                )
            }
            composable(
                Routes.COLLECTION,
                arguments = listOf(
                    navArgument("kind") { type = NavType.StringType },
                    navArgument("ref") { type = NavType.StringType; nullable = true; defaultValue = null },
                ),
            ) { e ->
                CollectionScreen(
                    kind = CollectionKind.fromKey(e.arguments?.getString("kind")),
                    ref = e.arguments?.getString("ref"),
                    onBack = { nav.popBackStack() },
                    onOpenMoment = openMoment,
                )
            }
            composable(Routes.GROUPS, arguments = listOf(navArgument("kind") { type = NavType.StringType })) { e ->
                GroupsScreen(
                    kind = CollectionKind.fromKey(e.arguments?.getString("kind")),
                    onBack = { nav.popBackStack() },
                    onOpenGroup = openCollection,
                )
            }
        }
    }
}

@Composable
private fun MemoriaBottomBar(current: String?, onSelect: (String) -> Unit) {
    Surface(color = MaterialTheme.colorScheme.surfaceContainer) {
        Row(
            Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .height(80.dp)
                .selectableGroup(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            tabs.forEach { tab ->
                val selected = current == tab.route
                Column(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .selectable(selected = selected, onClick = { onSelect(tab.route) }, role = Role.Tab),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    if (tab.route == Routes.SAVE) {
                        Box(
                            Modifier
                                .size(52.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                tab.icon,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.size(30.dp),
                            )
                        }
                        Spacer(Modifier.height(2.dp))
                        Text(
                            tab.label,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary,
                        )
                    } else {
                        Box(
                            Modifier
                                .size(width = 56.dp, height = 30.dp)
                                .clip(RoundedCornerShape(15.dp))
                                .background(if (selected) MaterialTheme.colorScheme.secondaryContainer else Color.Transparent),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(if (selected) tab.selectedIcon else tab.icon, contentDescription = null)
                        }
                        Spacer(Modifier.height(4.dp))
                        Text(
                            tab.label,
                            style = MaterialTheme.typography.labelMedium,
                            color = if (selected) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }
        }
    }
}
