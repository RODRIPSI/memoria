package br.rodrigo.memoria.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface MomentDao {

    /** Upsert = inserir ou atualizar SEM apagar antes (preserva mídias e vínculos). */
    @Upsert
    suspend fun upsertMoment(moment: MomentEntity)

    @Query("SELECT * FROM moments WHERE id = :id")
    suspend fun getMoment(id: String): MomentEntity?

    @Transaction
    @Query("SELECT * FROM moments WHERE deletedAt IS NULL ORDER BY occurredAt DESC")
    fun observeAll(): Flow<List<MomentFull>>

    @Transaction
    @Query("SELECT * FROM moments WHERE id = :id AND deletedAt IS NULL")
    fun observeFull(id: String): Flow<MomentFull?>

    @Query("UPDATE moments SET isFavorite = :value, updatedAt = :now WHERE id = :id")
    suspend fun setFavorite(id: String, value: Boolean, now: Long)

    @Query("UPDATE moments SET isMilestone = :value, updatedAt = :now WHERE id = :id")
    suspend fun setMilestone(id: String, value: Boolean, now: Long)

    @Query("UPDATE moments SET deletedAt = :now, updatedAt = :now WHERE id = :id")
    suspend fun moveToTrash(id: String, now: Long)

    @Query("DELETE FROM moment_people WHERE momentId = :momentId")
    suspend fun clearPeople(momentId: String)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertPersonRef(ref: MomentPersonCrossRef)

    @Query("SELECT * FROM people WHERE nameKey = :key LIMIT 1")
    suspend fun findPerson(key: String): PersonEntity?

    @Insert
    suspend fun insertPerson(person: PersonEntity)

    @Query("SELECT * FROM places WHERE nameKey = :key LIMIT 1")
    suspend fun findPlace(key: String): PlaceEntity?

    @Insert
    suspend fun insertPlace(place: PlaceEntity)

    @Query("SELECT * FROM events WHERE nameKey = :key LIMIT 1")
    suspend fun findEvent(key: String): EventEntity?

    @Insert
    suspend fun insertEvent(event: EventEntity)

    @Query("DELETE FROM moments WHERE isDemo = 1")
    suspend fun deleteDemoMoments()

    @Query("DELETE FROM people WHERE id NOT IN (SELECT personId FROM moment_people)")
    suspend fun deleteOrphanPeople()

    @Query("DELETE FROM places WHERE id NOT IN (SELECT placeId FROM moments WHERE placeId IS NOT NULL)")
    suspend fun deleteOrphanPlaces()

    @Query("DELETE FROM events WHERE id NOT IN (SELECT eventId FROM moments WHERE eventId IS NOT NULL)")
    suspend fun deleteOrphanEvents()

    @Query("SELECT COUNT(*) FROM moments WHERE isDemo = 1")
    suspend fun countDemo(): Int
}
