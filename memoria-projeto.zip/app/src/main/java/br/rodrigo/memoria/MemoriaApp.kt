package br.rodrigo.memoria

import android.app.Application

class MemoriaApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        container.seedDemoIfFirstRun()
    }
}
