package br.rodrigo.memoria.data

import androidx.room.withTransaction
import br.rodrigo.memoria.data.db.EventEntity
import br.rodrigo.memoria.data.db.MemoriaDatabase
import br.rodrigo.memoria.data.db.MomentEntity
import br.rodrigo.memoria.data.db.MomentFull
import br.rodrigo.memoria.data.db.MomentPersonCrossRef
import br.rodrigo.memoria.data.db.PersonEntity
import br.rodrigo.memoria.data.db.PlaceEntity
import br.rodrigo.memoria.domain.Category
import br.rodrigo.memoria.domain.MediaRef
import br.rodrigo.memoria.domain.Moment
import br.rodrigo.memoria.domain.MomentDraft
import br.rodrigo.memoria.domain.NamedRef
import br.rodrigo.memoria.domain.Source
import br.rodrigo.memoria.domain.SyncStatus
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.Instant
import java.time.ZoneId
import java.util.Locale
import java.util.UUID

class MomentRepository(
    private val db: MemoriaDatabase,
    private val clock: () -> Long = { System.currentTimeMillis() },
) {
    private val dao = db.momentDao()

    fun observeAll(): Flow<List<Moment>> = dao.observeAll().map { list -> list.map { it.toDomain() } }

    fun observe(id: String): Flow<Moment?> = dao.observeFull(id).map { it?.toDomain() }

    /** Cria ou atualiza. Ao editar, a data de registro original é preservada. */
    suspend fun save(draft: MomentDraft): String = db.withTransaction {
        val now = clock()
        val existing = draft.id?.let { dao.getMoment(it) }
        val id = existing?.id ?: draft.id ?: UUID.randomUUID().toString()

        val placeId = draft.place.cleanName()?.let { resolvePlace(it) }
        val eventId = draft.event.cleanName()?.let { resolveEvent(it) }

        dao.upsertMoment(
            MomentEntity(
                id = id,
                title = draft.title.cleanName(),
                body = draft.body.trim(),
                occurredAt = draft.occurredAt.toInstant().toEpochMilli(),
                occurredZone = draft.occurredAt.zone.id,
                createdAt = existing?.createdAt ?: draft.createdAtOverride?.toEpochMilli() ?: now,
                updatedAt = now,
                category = draft.category.name,
                isFavorite = draft.isFavorite,
                isMilestone = draft.isMilestone,
                source = existing?.source ?: draft.source.name,
                transcript = draft.transcript ?: existing?.transcript,
                placeId = placeId,
                eventId = eventId,
                syncStatus = existing?.syncStatus ?: SyncStatus.LOCAL.name,
                isDemo = existing?.isDemo ?: draft.isDemo,
                deletedAt = existing?.deletedAt,
            ),
        )

        dao.clearPeople(id)
        draft.people.mapNotNull { it.cleanName() }
            .distinctBy { keyOf(it) }
            .forEach { name -> dao.insertPersonRef(MomentPersonCrossRef(id, resolvePerson(name))) }
        id
    }

    suspend fun setFavorite(id: String, value: Boolean) = dao.setFavorite(id, value, clock())

    suspend fun setMilestone(id: String, value: Boolean) = dao.setMilestone(id, value, clock())

    /** Exclusão recuperável: o Momento vai para a Lixeira. */
    suspend fun moveToTrash(id: String) = dao.moveToTrash(id, clock())

    suspend fun deleteDemo() = db.withTransaction {
        dao.deleteDemoMoments()
        dao.deleteOrphanPeople()
        dao.deleteOrphanPlaces()
        dao.deleteOrphanEvents()
    }

    suspend fun countDemo(): Int = dao.countDemo()

    private suspend fun resolvePerson(name: String): String {
        val key = keyOf(name)
        dao.findPerson(key)?.let { return it.id }
        val id = UUID.randomUUID().toString()
        dao.insertPerson(PersonEntity(id, name, key))
        return id
    }

    private suspend fun resolvePlace(name: String): String {
        val key = keyOf(name)
        dao.findPlace(key)?.let { return it.id }
        val id = UUID.randomUUID().toString()
        dao.insertPlace(PlaceEntity(id, name, key))
        return id
    }

    private suspend fun resolveEvent(name: String): String {
        val key = keyOf(name)
        dao.findEvent(key)?.let { return it.id }
        val id = UUID.randomUUID().toString()
        dao.insertEvent(EventEntity(id, name, key))
        return id
    }

    companion object {
        fun keyOf(name: String): String = name.trim().replace(Regex("\\s+"), " ").lowercase(Locale.ROOT)

        private fun String?.cleanName(): String? =
            this?.trim()?.replace(Regex("\\s+"), " ")?.takeIf { it.isNotEmpty() }

        private fun zoneOf(id: String): ZoneId = runCatching { ZoneId.of(id) }.getOrDefault(ZoneId.systemDefault())

        fun MomentFull.toDomain(): Moment = Moment(
            id = moment.id,
            title = moment.title,
            body = moment.body,
            occurredAt = Instant.ofEpochMilli(moment.occurredAt).atZone(zoneOf(moment.occurredZone)),
            createdAt = Instant.ofEpochMilli(moment.createdAt),
            updatedAt = Instant.ofEpochMilli(moment.updatedAt),
            category = Category.fromKey(moment.category),
            isFavorite = moment.isFavorite,
            isMilestone = moment.isMilestone,
            source = Source.fromKey(moment.source),
            transcript = moment.transcript,
            people = people.map { NamedRef(it.id, it.name) }.sortedBy { it.name.lowercase() },
            place = place?.let { NamedRef(it.id, it.name) },
            event = event?.let { NamedRef(it.id, it.name) },
            tags = tags.map { NamedRef(it.id, it.name) },
            media = media.map {
                MediaRef(it.id, it.kind, it.localPath, it.remoteId, it.mimeType, SyncStatus.fromKey(it.syncStatus))
            },
            syncStatus = SyncStatus.fromKey(moment.syncStatus),
            isDemo = moment.isDemo,
        )
    }
}
