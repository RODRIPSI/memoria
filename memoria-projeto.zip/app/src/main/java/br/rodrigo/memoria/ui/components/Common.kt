@file:OptIn(ExperimentalLayoutApi::class)

package br.rodrigo.memoria.ui.components

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import br.rodrigo.memoria.AppContainer
import br.rodrigo.memoria.MemoriaApp
import br.rodrigo.memoria.domain.Category
import br.rodrigo.memoria.domain.Formats
import br.rodrigo.memoria.domain.Moment
import br.rodrigo.memoria.ui.theme.favoriteColor
import androidx.compose.ui.platform.LocalContext

@Composable
fun appContainer(): AppContainer = (LocalContext.current.applicationContext as MemoriaApp).container

/** Cartão de um Momento com a hora à esquerda e um fio vertical (linha do tempo). */
@Composable
fun MomentCard(
    moment: Moment,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    showDate: Boolean = false,
) {
    Row(modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
        Column(
            Modifier.width(56.dp).fillMaxHeight(),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                Formats.time(moment.occurredAt),
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(top = 14.dp),
            )
            Spacer(Modifier.height(6.dp))
            Box(
                Modifier
                    .width(2.dp)
                    .weight(1f)
                    .background(MaterialTheme.colorScheme.outlineVariant),
            )
        }
        Card(
            onClick = onClick,
            modifier = Modifier.weight(1f).padding(bottom = 12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (showDate) {
                    Text(
                        Formats.longDateYear(moment.occurredAt),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                if (moment.title != null) {
                    Text(
                        moment.title,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                    if (moment.body.isNotBlank()) {
                        Text(
                            moment.body,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                } else {
                    Text(
                        moment.body,
                        style = MaterialTheme.typography.bodyLarge,
                        maxLines = 4,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                MomentMeta(moment)
            }
        }
    }
}

@Composable
private fun MomentMeta(m: Moment) {
    val hasMeta = m.isFavorite || m.isMilestone || m.place != null || m.people.isNotEmpty() ||
        m.event != null || m.category != Category.COTIDIANO || m.isDemo
    if (!hasMeta) return
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
        modifier = Modifier.padding(top = 4.dp),
    ) {
        if (m.isFavorite) MetaLabel(Icons.Filled.Favorite, "Favorito", favoriteColor())
        if (m.isMilestone) MetaLabel(Icons.Filled.Flag, "Marco", MaterialTheme.colorScheme.tertiary)
        if (m.category != Category.COTIDIANO) MetaLabel(null, m.category.label)
        m.event?.let { MetaLabel(Icons.Outlined.Event, it.name) }
        m.place?.let { MetaLabel(Icons.Outlined.Place, it.name) }
        if (m.people.isNotEmpty()) MetaLabel(Icons.Outlined.People, m.people.joinToString(", ") { it.name })
        if (m.isDemo) MetaLabel(Icons.Outlined.Science, "Demonstração")
    }
}

@Composable
fun MetaLabel(icon: ImageVector?, text: String, tint: Color = MaterialTheme.colorScheme.onSurfaceVariant) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (icon != null) {
            Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(4.dp))
        }
        Text(text, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun EmptyState(icon: ImageVector, title: String, body: String, modifier: Modifier = Modifier) {
    Column(
        modifier.fillMaxWidth().padding(vertical = 32.dp, horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(40.dp))
        Text(title, style = MaterialTheme.typography.titleMedium)
        Text(
            body,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
fun LoadingBox(modifier: Modifier = Modifier) {
    Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
}

fun shareText(context: Context, text: String) {
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, text)
    }
    context.startActivity(Intent.createChooser(send, "Compartilhar momento"))
}

fun captionOf(m: Moment): String = buildString {
    m.title?.let { append(it).append("\n\n") }
    append(m.body)
    append("\n\n").append(Formats.longDateYear(m.occurredAt))
}
