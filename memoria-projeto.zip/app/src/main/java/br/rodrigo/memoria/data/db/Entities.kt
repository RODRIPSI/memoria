package br.rodrigo.memoria.data.db

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.Junction
import androidx.room.PrimaryKey
import androidx.room.Relation

@Entity(
    tableName = "moments",
    indices = [Index("occurredAt"), Index("placeId"), Index("eventId"), Index("isDemo")],
)
data class MomentEntity(
    @PrimaryKey val id: String,
    val title: String?,
    val body: String,
    /** Instante do acontecimento (epoch ms, UTC). */
    val occurredAt: Long,
    /** Fuso horário onde aconteceu, ex.: America/Sao_Paulo. */
    val occurredZone: String,
    /** Instante em que o registro foi criado (epoch ms). */
    val createdAt: Long,
    val updatedAt: Long,
    val category: String,
    val isFavorite: Boolean = false,
    val isMilestone: Boolean = false,
    val source: String,
    val transcript: String? = null,
    val placeId: String? = null,
    val eventId: String? = null,
    val syncStatus: String = "LOCAL",
    val isDemo: Boolean = false,
    /** Preenchido quando vai para a Lixeira (recuperável). */
    val deletedAt: Long? = null,
)

@Entity(tableName = "people", indices = [Index(value = ["nameKey"], unique = true)])
data class PersonEntity(@PrimaryKey val id: String, val name: String, val nameKey: String)

@Entity(tableName = "places", indices = [Index(value = ["nameKey"], unique = true)])
data class PlaceEntity(@PrimaryKey val id: String, val name: String, val nameKey: String)

@Entity(tableName = "events", indices = [Index(value = ["nameKey"], unique = true)])
data class EventEntity(@PrimaryKey val id: String, val name: String, val nameKey: String)

@Entity(tableName = "tags", indices = [Index(value = ["nameKey"], unique = true)])
data class TagEntity(@PrimaryKey val id: String, val name: String, val nameKey: String)

@Entity(
    tableName = "moment_people",
    primaryKeys = ["momentId", "personId"],
    indices = [Index("personId")],
    foreignKeys = [
        ForeignKey(
            entity = MomentEntity::class,
            parentColumns = ["id"],
            childColumns = ["momentId"],
            onDelete = ForeignKey.CASCADE,
        ),
        ForeignKey(
            entity = PersonEntity::class,
            parentColumns = ["id"],
            childColumns = ["personId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
)
data class MomentPersonCrossRef(val momentId: String, val personId: String)

@Entity(
    tableName = "moment_tags",
    primaryKeys = ["momentId", "tagId"],
    indices = [Index("tagId")],
    foreignKeys = [
        ForeignKey(
            entity = MomentEntity::class,
            parentColumns = ["id"],
            childColumns = ["momentId"],
            onDelete = ForeignKey.CASCADE,
        ),
        ForeignKey(
            entity = TagEntity::class,
            parentColumns = ["id"],
            childColumns = ["tagId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
)
data class MomentTagCrossRef(val momentId: String, val tagId: String)

/** Referência a um arquivo (foto, vídeo, áudio). O arquivo nunca é duplicado. */
@Entity(
    tableName = "media_refs",
    indices = [Index("momentId")],
    foreignKeys = [
        ForeignKey(
            entity = MomentEntity::class,
            parentColumns = ["id"],
            childColumns = ["momentId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
)
data class MediaReferenceEntity(
    @PrimaryKey val id: String,
    val momentId: String,
    val kind: String,
    val localPath: String?,
    val remoteId: String?,
    val mimeType: String,
    val syncStatus: String,
    val createdAt: Long,
)

data class MomentFull(
    @Embedded val moment: MomentEntity,
    @Relation(
        parentColumn = "id",
        entityColumn = "id",
        associateBy = Junction(
            value = MomentPersonCrossRef::class,
            parentColumn = "momentId",
            entityColumn = "personId",
        ),
    )
    val people: List<PersonEntity>,
    @Relation(parentColumn = "placeId", entityColumn = "id")
    val place: PlaceEntity?,
    @Relation(parentColumn = "eventId", entityColumn = "id")
    val event: EventEntity?,
    @Relation(
        parentColumn = "id",
        entityColumn = "id",
        associateBy = Junction(
            value = MomentTagCrossRef::class,
            parentColumn = "momentId",
            entityColumn = "tagId",
        ),
    )
    val tags: List<TagEntity>,
    @Relation(parentColumn = "id", entityColumn = "momentId")
    val media: List<MediaReferenceEntity>,
)
