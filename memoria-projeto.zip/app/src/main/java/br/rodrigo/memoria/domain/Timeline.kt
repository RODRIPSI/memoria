package br.rodrigo.memoria.domain

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.ZonedDateTime
import java.time.temporal.TemporalAdjusters

data class DayGroup<T>(val date: LocalDate, val items: List<T>) {
    val key: String get() = "d$date"
}

data class WeekGroup<T>(
    val year: Int,
    val month: Int,
    val startDay: Int,
    val endDay: Int,
    val days: List<DayGroup<T>>,
) {
    val key: String get() = "w$year-$month-$startDay"
    val label: String get() = if (startDay == endDay) "Dia $startDay" else "Semana $startDay–$endDay"
    val count: Int get() = days.sumOf { it.items.size }
}

data class MonthGroup<T>(val year: Int, val month: Int, val weeks: List<WeekGroup<T>>) {
    val key: String get() = "m$year-$month"
    val count: Int get() = weeks.sumOf { it.count }
}

data class YearGroup<T>(val year: Int, val months: List<MonthGroup<T>>) {
    val key: String get() = "y$year"
    val count: Int get() = months.sumOf { it.count }
}

/**
 * Organiza itens em Ano → Mês → Semana → Dia.
 * Semanas começam na segunda-feira e são recortadas pelo mês
 * (ex.: 31/ago a 6/set aparece como "Semana 1–6" em setembro).
 * O dia de cada item é o dia local do lugar onde aconteceu.
 */
object Timeline {

    fun weekBounds(date: LocalDate): Pair<Int, Int> {
        val monday = date.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        val sunday = monday.plusDays(6)
        val start = if (monday.month == date.month) monday.dayOfMonth else 1
        val end = if (sunday.month == date.month) sunday.dayOfMonth else date.lengthOfMonth()
        return start to end
    }

    fun <T> build(items: List<T>, dateTimeOf: (T) -> ZonedDateTime): List<YearGroup<T>> {
        val days = items
            .groupBy { dateTimeOf(it).toLocalDate() }
            .entries
            .sortedByDescending { it.key }
            .map { (date, list) -> DayGroup(date, list.sortedBy { dateTimeOf(it).toInstant() }) }

        return days.groupBy { it.date.year }
            .toSortedMap(reverseOrder())
            .map { (year, yearDays) ->
                val months = yearDays.groupBy { it.date.monthValue }
                    .toSortedMap(reverseOrder())
                    .map { (month, monthDays) ->
                        val weeks = monthDays.groupBy { weekBounds(it.date) }
                            .map { (bounds, weekDays) ->
                                WeekGroup(year, month, bounds.first, bounds.second, weekDays)
                            }
                            .sortedByDescending { it.startDay }
                        MonthGroup(year, month, weeks)
                    }
                YearGroup(year, months)
            }
    }
}
