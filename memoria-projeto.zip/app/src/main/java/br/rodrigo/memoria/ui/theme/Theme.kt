package br.rodrigo.memoria.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/** Cor dos favoritos (coração). */
val FavoriteRose = Color(0xFFB4506A)
val FavoriteRoseDark = Color(0xFFF0A3B6)

private val LightColors = lightColorScheme(
    primary = Color(0xFF1F5E5B),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFCFE7E2),
    onPrimaryContainer = Color(0xFF062A27),
    secondary = Color(0xFF4F6360),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFD9E6E3),
    onSecondaryContainer = Color(0xFF0D1F1D),
    tertiary = Color(0xFF8C5510),
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFFFE2C0),
    onTertiaryContainer = Color(0xFF2E1700),
    background = Color(0xFFF4F6F5),
    onBackground = Color(0xFF191C1C),
    surface = Color(0xFFF4F6F5),
    onSurface = Color(0xFF191C1C),
    surfaceVariant = Color(0xFFDDE4E2),
    onSurfaceVariant = Color(0xFF3F4947),
    outline = Color(0xFF6F7977),
    outlineVariant = Color(0xFFBFC8C6),
    surfaceContainerLowest = Color.White,
    surfaceContainerLow = Color(0xFFEEF2F1),
    surfaceContainer = Color(0xFFE8EDEC),
    surfaceContainerHigh = Color(0xFFE2E8E6),
    surfaceContainerHighest = Color(0xFFDCE3E1),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF93D2CA),
    onPrimary = Color(0xFF003733),
    primaryContainer = Color(0xFF0F4F4B),
    onPrimaryContainer = Color(0xFFCFE7E2),
    secondary = Color(0xFFB6CBC7),
    onSecondary = Color(0xFF213532),
    secondaryContainer = Color(0xFF374B48),
    onSecondaryContainer = Color(0xFFD9E6E3),
    tertiary = Color(0xFFF2BC7A),
    onTertiary = Color(0xFF4A2800),
    tertiaryContainer = Color(0xFF6A3F00),
    onTertiaryContainer = Color(0xFFFFE2C0),
    background = Color(0xFF101413),
    onBackground = Color(0xFFE0E3E2),
    surface = Color(0xFF101413),
    onSurface = Color(0xFFE0E3E2),
    surfaceVariant = Color(0xFF3F4947),
    onSurfaceVariant = Color(0xFFBEC9C6),
    outline = Color(0xFF899391),
    outlineVariant = Color(0xFF3F4947),
    surfaceContainerLowest = Color(0xFF0B0F0E),
    surfaceContainerLow = Color(0xFF181D1C),
    surfaceContainer = Color(0xFF1C2120),
    surfaceContainerHigh = Color(0xFF262B2A),
    surfaceContainerHighest = Color(0xFF313635),
)

/** Datas em serifa: o toque de "caderno de memórias". O resto em fonte do sistema. */
val DateSerif = FontFamily.Serif

private val base = Typography()
private val MemoriaTypography = base.copy(
    displaySmall = base.displaySmall.copy(fontFamily = DateSerif, fontWeight = FontWeight.Normal),
    headlineSmall = base.headlineSmall.copy(fontFamily = DateSerif),
    bodyLarge = base.bodyLarge.copy(fontSize = 17.sp, lineHeight = 26.sp),
)

val DateHeading = TextStyle(fontFamily = DateSerif, fontSize = 20.sp, lineHeight = 26.sp)

@Composable
fun MemoriaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        typography = MemoriaTypography,
        content = content,
    )
}

@Composable
fun favoriteColor(): Color = if (isSystemInDarkTheme()) FavoriteRoseDark else FavoriteRose
