package br.rodrigo.memoria.domain

import java.time.Instant
import java.time.ZonedDateTime

/** Assunto principal do Momento. Eventos, pessoas e lugares são marcações à parte. */
enum class Category(val label: String) {
    COTIDIANO("Cotidiano"),
    IDEIA("Ideia ou pensamento"),
    PRODUCAO("Produção");

    companion object {
        fun fromKey(key: String?): Category = entries.firstOrNull { it.name == key } ?: COTIDIANO
    }
}

/** Como o Momento foi registrado. */
enum class Source(val label: String) {
    TEXTO("Texto"),
    VOZ("Voz"),
    FOTO("Fotografia"),
    VIDEO("Vídeo"),
    DEMO("Demonstração");

    companion object {
        fun fromKey(key: String?): Source = entries.firstOrNull { it.name == key } ?: TEXTO
    }
}

enum class SyncStatus(val label: String) {
    LOCAL("Somente neste aparelho"),
    PENDENTE("Envio pendente"),
    ENVIADO("Sincronizado"),
    ERRO("Erro ao sincronizar");

    companion object {
        fun fromKey(key: String?): SyncStatus = entries.firstOrNull { it.name == key } ?: LOCAL
    }
}

data class NamedRef(val id: String, val name: String)

data class MediaRef(
    val id: String,
    val kind: String,
    val localPath: String?,
    val remoteId: String?,
    val mimeType: String,
    val syncStatus: SyncStatus,
)

/**
 * Unidade central de memória.
 * [occurredAt] = quando aconteceu (com o fuso onde aconteceu);
 * [createdAt]  = quando foi registrado. Os dois nunca se confundem.
 */
data class Moment(
    val id: String,
    val title: String?,
    val body: String,
    val occurredAt: ZonedDateTime,
    val createdAt: Instant,
    val updatedAt: Instant,
    val category: Category,
    val isFavorite: Boolean,
    val isMilestone: Boolean,
    val source: Source,
    val transcript: String?,
    val people: List<NamedRef>,
    val place: NamedRef?,
    val event: NamedRef?,
    val tags: List<NamedRef>,
    val media: List<MediaRef>,
    val syncStatus: SyncStatus,
    val isDemo: Boolean,
)

/** Dados para criar ou editar um Momento. [id] nulo = novo. */
data class MomentDraft(
    val id: String? = null,
    val title: String? = null,
    val body: String,
    val occurredAt: ZonedDateTime,
    val category: Category = Category.COTIDIANO,
    val people: List<String> = emptyList(),
    val place: String? = null,
    val event: String? = null,
    val isFavorite: Boolean = false,
    val isMilestone: Boolean = false,
    val source: Source = Source.TEXTO,
    val transcript: String? = null,
    val isDemo: Boolean = false,
    /** Só para dados de demonstração: simula um registro feito no passado. */
    val createdAtOverride: Instant? = null,
)
