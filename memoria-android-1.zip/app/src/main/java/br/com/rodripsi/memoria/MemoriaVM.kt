package br.com.rodripsi.memoria

import android.app.Application
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.UUID

private enum class Pending { SAVE, DELETE }

class MemoriaVM(app: Application) : AndroidViewModel(app) {

    private val store = Store(app)
    private val config = Config(app)
    private val main = Handler(Looper.getMainLooper())

    var memories by mutableStateOf(store.load())
        private set
    var status by mutableStateOf("Toque para falar")
        private set
    var heard by mutableStateOf("")
        private set
    var answerHead by mutableStateOf<String?>(null)
        private set
    var answerItems by mutableStateOf<List<Memory>>(emptyList())
        private set
    var listening by mutableStateOf(false)
        private set
    var speaking by mutableStateOf(false)
        private set
    var loop by mutableStateOf(false)

    // voz do ElevenLabs
    var apiKey: String = config.apiKey
        private set
    var voiceId: String = config.voiceId
        private set
    var model: String = config.model
        private set
    var useMyVoice by mutableStateOf(config.useMyVoice)
        private set
    var voiceNote by mutableStateOf<String?>(null)
        private set

    private var pending: Pending? = null
    private var lastError = false
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var currentUtt: String? = null
    private var player: MediaPlayer? = null

    init {
        tts = TextToSpeech(app) { st ->
            if (st == TextToSpeech.SUCCESS) {
                val res = tts?.setLanguage(Locale("pt", "BR"))
                ttsReady = res != TextToSpeech.LANG_MISSING_DATA && res != TextToSpeech.LANG_NOT_SUPPORTED
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        main.post { if (utteranceId == currentUtt) { speaking = true; status = "Falando…" } }
                    }
                    override fun onDone(utteranceId: String?) {
                        main.post { if (utteranceId == currentUtt) finishSpeaking() }
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        main.post { if (utteranceId == currentUtt) finishSpeaking() }
                    }
                })
            }
        }
    }

    // ---------- configuração da voz ----------

    fun saveVoice(key: String, id: String, mdl: String) {
        apiKey = key.trim()
        voiceId = id.trim()
        model = mdl
        config.apiKey = apiKey
        config.voiceId = voiceId
        config.model = mdl
        if (apiKey.isNotEmpty() && voiceId.isNotEmpty()) {
            setUseMyVoice(true)
            voiceNote = null
            status = "Configuração salva."
        } else {
            voiceNote = "Preencha a chave da API e o ID da voz."
        }
    }

    fun setUseMyVoice(v: Boolean) {
        useMyVoice = v
        config.useMyVoice = v
        voiceNote = if (v && (apiKey.isBlank() || voiceId.isBlank()))
            "Preencha a chave da API e o ID da voz, no quadro Minha voz, e toque em Salvar." else null
    }

    fun testVoice() {
        if (apiKey.isBlank() || voiceId.isBlank()) {
            voiceNote = "Preencha a chave da API e o ID da voz."
            return
        }
        stopSpeaking()
        speak("Olá! Esta é a minha voz no aplicativo Memória.", true)
    }

    // ---------- voz: saída ----------

    private fun speak(text: String, forceEleven: Boolean = false) {
        val id = "u" + System.nanoTime()
        currentUtt = id
        speaking = true
        if ((useMyVoice || forceEleven) && apiKey.isNotBlank() && voiceId.isNotBlank()) {
            status = "Gerando voz…"
            speakEleven(text, id)
        } else {
            speakAndroid(text, id)
        }
    }

    private fun speakAndroid(text: String, id: String) {
        if (!ttsReady) {
            speaking = false
            currentUtt = null
            status = "Toque para falar"
            return
        }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
    }

    private fun speakEleven(text: String, id: String) {
        val key = apiKey
        val voice = voiceId
        val mdl = model
        val cache = File(getApplication<Application>().cacheDir, "voz.mp3")
        Thread {
            var err: String? = null
            try {
                val url = URL(
                    "https://api.elevenlabs.io/v1/text-to-speech/" +
                        URLEncoder.encode(voice, "UTF-8") + "?output_format=mp3_44100_128"
                )
                val c = url.openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.connectTimeout = 15000
                c.readTimeout = 40000
                c.doOutput = true
                c.setRequestProperty("xi-api-key", key)
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("Accept", "audio/mpeg")
                val body = JSONObject().put("text", text).put("model_id", mdl).toString()
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                val code = c.responseCode
                if (code == 200) {
                    c.inputStream.use { input -> cache.outputStream().use { out -> input.copyTo(out) } }
                } else {
                    err = when (code) {
                        401 -> "Chave do ElevenLabs inválida ou sem créditos."
                        429 -> "Limite do ElevenLabs atingido. Tente de novo em instantes."
                        400, 404, 422 -> "ID da voz ou modelo inválido (código $code)."
                        else -> "O ElevenLabs recusou o pedido (código $code)."
                    }
                }
                c.disconnect()
            } catch (e: Exception) {
                err = "Sem conexão com o ElevenLabs."
            }
            main.post {
                if (id == currentUtt) {
                    if (err != null) {
                        voiceNote = err + " Usei a voz do Android."
                        speakAndroid(text, id)
                    } else {
                        voiceNote = null
                        playFile(cache, id, text)
                    }
                }
            }
        }.start()
    }

    private fun releasePlayer() {
        try { player?.release() } catch (e: Exception) { }
        player = null
    }

    private fun playFile(f: File, id: String, text: String) {
        releasePlayer()
        try {
            val p = MediaPlayer()
            p.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            p.setDataSource(f.absolutePath)
            p.setOnPreparedListener { mp ->
                if (id == currentUtt) { status = "Falando…"; mp.start() }
            }
            p.setOnCompletionListener {
                releasePlayer()
                if (id == currentUtt) finishSpeaking()
            }
            p.setOnErrorListener { _, _, _ ->
                releasePlayer()
                if (id == currentUtt) {
                    voiceNote = "Não consegui tocar o áudio. Usei a voz do Android."
                    speakAndroid(text, id)
                }
                true
            }
            player = p
            p.prepareAsync()
        } catch (e: Exception) {
            releasePlayer()
            speakAndroid(text, id)
        }
    }

    private fun finishSpeaking() {
        if (!speaking) return
        speaking = false
        currentUtt = null
        status = "Toque para falar"
        if (loop && !lastError) startListening()
    }

    private fun stopSpeaking() {
        currentUtt = null
        speaking = false
        releasePlayer()
        tts?.stop()
    }

    // ---------- voz: entrada ----------

    fun toggleListening() {
        if (listening) recognizer?.stopListening() else startListening()
    }

    fun permissionDenied() {
        status = "Sem permissão do microfone. Libere em Configurações > Apps > Memória > Permissões."
    }

    private fun startListening() {
        val ctx = getApplication<Application>()
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            status = "Este aparelho não tem reconhecimento de voz disponível."
            return
        }
        stopSpeaking()
        lastError = false
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { listening = true; status = "Ouvindo…"; heard = "" }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onPartialResults(partialResults: Bundle?) {
                val p = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!p.isNullOrBlank()) heard = p
            }
            override fun onResults(results: Bundle?) {
                listening = false
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t.isNullOrBlank()) status = "Não entendi. Toque e tente de novo." else handle(t)
            }
            override fun onError(error: Int) {
                listening = false
                lastError = true
                status = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                        "Não ouvi nada. Toque e tente de novo."
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                        "Sem permissão do microfone."
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                        "Sem internet e sem pacote de voz offline em português. Baixe-o nas configurações de voz do Google."
                    else -> "Erro de reconhecimento (código $error). Tente de novo."
                }
            }
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        recognizer = r
        r.startListening(intent)
    }

    // ---------- lógica ----------

    private fun reply(r: Reply) {
        answerHead = r.head
        answerItems = r.items
        speak(r.spoken)
    }

    private fun addMemory(raw: String) {
        val t = raw.trim().replaceFirstChar { it.uppercase() }
        val m = Memory(UUID.randomUUID().toString(), t, System.currentTimeMillis())
        memories = memories + m
        store.save(memories)
        reply(Reply("Guardado.", "Guardado.", listOf(m)))
    }

    fun handle(raw: String) {
        val text = raw.trim()
        if (text.isEmpty()) return
        heard = text
        val n = norm(text)

        if (pending == Pending.DELETE) {
            pending = null
            if (Regex("^(sim|pode|confirma|confirmo|isso)\\b").containsMatchIn(n) && memories.isNotEmpty()) {
                val gone = memories.last()
                memories = memories.dropLast(1)
                store.save(memories)
                reply(Reply("Apaguei a última memória.", "Apaguei: " + gone.text))
            } else {
                reply(Reply("Tudo bem, não apaguei nada."))
            }
            return
        }
        if (pending == Pending.SAVE) {
            pending = null
            if (Regex("^(cancela|cancelar|deixa|esquece|nao)\\b").containsMatchIn(n)) reply(Reply("Cancelado."))
            else addMemory(text)
            return
        }

        when (val cmd = parseCommand(text)) {
            is Command.Save -> addMemory(cmd.text)
            is Command.AskSave -> { pending = Pending.SAVE; reply(Reply("O que devo guardar?")) }
            is Command.AskDelete -> {
                if (memories.isEmpty()) reply(Reply("Não há memórias para apagar."))
                else {
                    pending = Pending.DELETE
                    reply(Reply("Apagar a última memória: " + memories.last().text + ". Confirma? Diga sim ou não."))
                }
            }
            is Command.Help -> reply(Reply(
                "Para guardar, diga: guarda que, e o que quer lembrar. " +
                "Para perguntar, diga por exemplo: o que eu guardei ontem, ou: quando eu comprei pão. " +
                "Para apagar, diga: apaga a última."
            ))
            is Command.ListRecent -> reply(recent(memories))
            is Command.Ask -> reply(search(memories, cmd.text))
        }
    }

    fun delete(id: String) {
        memories = memories.filter { it.id != id }
        store.save(memories)
    }

    fun backupJson(): String = Store.toJson(memories)

    fun note(t: String) { status = t }

    override fun onCleared() {
        releasePlayer()
        recognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onCleared()
    }
}
