package br.com.rodripsi.memoria

import java.text.Normalizer
import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.TextStyle
import java.time.temporal.ChronoUnit
import java.util.Locale

data class Memory(val id: String, val text: String, val ts: Long)

class Reply(
    val spoken: String,
    val head: String = spoken,
    val items: List<Memory> = emptyList()
)

sealed interface Command {
    data class Save(val text: String) : Command
    data object AskSave : Command
    data object AskDelete : Command
    data object Help : Command
    data object ListRecent : Command
    data class Ask(val text: String) : Command
}

private val PT = Locale("pt", "BR")

private val STOP: Set<String> = """
    a o as os um uma uns umas de do da dos das em no na nos nas por para com sem sobre que qual quais quem
    quando onde como eu me meu minha meus minhas voce vc se foi fui era ser estar tem tinha ter ja e ou mas
    ao aos pra pro isso isto esse essa aquele aquela mais muito fiz fez falei falou disse guardei guardou
    anotei lembra lembro lembrar memoria memorias algo alguma coisa tudo todas todos ultima ultimas ultimo
    recente recentes hoje ontem anteontem semana mes passada passado esta este neste nesta nessa nesse feira
    domingo segunda terca quarta quinta sexta sabado estou estava vez mostra mostre diga fale quero saber
""".trim().split(Regex("\\s+")).toSet()

private val SAVE_RE = Regex(
    """^\s*(guarda|guardar|guarde|anota|anotar|anote|registra|registrar|registre|salva|salvar|salve|memoriza|memorizar|memorize|lembra que|lembre que|lembre-se que)\b[\s,:.\-]*(?:que\s+|isso[\s,:.\-]*)?([\s\S]*)$""",
    RegexOption.IGNORE_CASE
)

fun norm(s: String): String =
    Normalizer.normalize(s, Normalizer.Form.NFD)
        .replace(Regex("\\p{M}+"), "")
        .lowercase(Locale.ROOT)
        .replace(Regex("[^a-z0-9\\s]"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

fun whenLabel(ts: Long): String {
    val zone = ZoneId.systemDefault()
    val dt = Instant.ofEpochMilli(ts).atZone(zone)
    val today = LocalDate.now(zone)
    val diff = ChronoUnit.DAYS.between(dt.toLocalDate(), today)
    val rel = when {
        diff == 0L -> "Hoje"
        diff == 1L -> "Ontem"
        diff == 2L -> "Anteontem"
        diff in 3L..6L -> "Na " + dt.dayOfWeek.getDisplayName(TextStyle.FULL, PT)
        else -> "Dia " + dt.dayOfMonth + " de " + dt.month.getDisplayName(TextStyle.FULL, PT)
    }
    return rel + " às " + String.format("%02d:%02d", dt.hour, dt.minute)
}

private fun dayStart(d: LocalDate, zone: ZoneId): Long =
    d.atStartOfDay(zone).toInstant().toEpochMilli()

/** Intervalo [de, até) citado na frase, ou null. */
fun parseRange(n: String): LongRange? {
    val zone = ZoneId.systemDefault()
    val today = LocalDate.now(zone)
    fun r(a: LocalDate, b: LocalDate): LongRange = dayStart(a, zone) until dayStart(b, zone)
    val monday = today.minusDays((today.dayOfWeek.value - 1).toLong())

    if (Regex("\\banteontem\\b").containsMatchIn(n)) return r(today.minusDays(2), today.minusDays(1))
    if (Regex("\\bontem\\b").containsMatchIn(n)) return r(today.minusDays(1), today)
    if (Regex("\\bhoje\\b").containsMatchIn(n)) return r(today, today.plusDays(1))
    if ("semana passada" in n) return r(monday.minusDays(7), monday)
    if (Regex("\\b(esta|essa|nesta|nessa) semana\\b").containsMatchIn(n)) return r(monday, today.plusDays(1))
    if ("mes passado" in n) {
        val first = today.withDayOfMonth(1)
        return r(first.minusMonths(1), first)
    }
    if (Regex("\\b(este|esse|neste|nesse) mes\\b").containsMatchIn(n)) return r(today.withDayOfMonth(1), today.plusDays(1))

    val names = mapOf(
        "domingo" to DayOfWeek.SUNDAY, "segunda" to DayOfWeek.MONDAY, "terca" to DayOfWeek.TUESDAY,
        "quarta" to DayOfWeek.WEDNESDAY, "quinta" to DayOfWeek.THURSDAY, "sexta" to DayOfWeek.FRIDAY,
        "sabado" to DayOfWeek.SATURDAY
    )
    for ((k, dow) in names) {
        if (Regex("\\b$k\\b").containsMatchIn(n)) {
            val back = ((today.dayOfWeek.value - dow.value) + 7) % 7
            val d = today.minusDays(back.toLong())
            return r(d, d.plusDays(1))
        }
    }
    return null
}

fun parseCommand(text: String): Command {
    val n = norm(text)
    val m = SAVE_RE.find(text)
    if (m != null) {
        val rest = m.groupValues[2].trim()
        return if (rest.isNotEmpty()) Command.Save(rest) else Command.AskSave
    }
    if (Regex("^(apaga|apague|exclui|exclua|deleta|delete|remove|remova)\\b.*\\b(ultima|ultimo)\\b").containsMatchIn(n))
        return Command.AskDelete
    if (Regex("^(ajuda|socorro|o que voce faz|como funciona)").containsMatchIn(n)) return Command.Help
    if (Regex("^(ler|le|leia|lista|liste)\\b.*\\b(tudo|todas|memorias)\\b").containsMatchIn(n))
        return Command.ListRecent
    return Command.Ask(text)
}

fun search(mems: List<Memory>, text: String): Reply {
    if (mems.isEmpty())
        return Reply("Ainda não há memórias guardadas. Diga: guarda que, e depois o que quer lembrar.")

    val n = norm(text)
    val range = parseRange(n)
    val tokens = n.split(" ").filter { it.length > 2 && it !in STOP }
    val pool = mems.filter { range == null || it.ts in range }

    val res: List<Memory> = if (tokens.isEmpty()) {
        pool.sortedByDescending { it.ts }.take(if (range != null) 5 else 3)
    } else {
        pool.map { m ->
            val words = norm(m.text).split(" ")
            val score = tokens.count { t ->
                words.any { w -> w == t || (t.length >= 5 && w.length >= 5 && w.take(5) == t.take(5)) }
            }
            Pair(m, score)
        }
            .filter { it.second > 0 }
            .sortedWith(compareByDescending<Pair<Memory, Int>> { it.second }.thenByDescending { it.first.ts })
            .take(3)
            .map { it.first }
    }

    if (res.isEmpty()) {
        return Reply(
            if (range != null) "Não achei nada guardado nesse período sobre isso."
            else "Não encontrei nada sobre isso nas suas memórias."
        )
    }
    val head = if (res.size == 1) "Encontrei uma memória." else "Encontrei ${res.size} memórias."
    val spoken = head + " " + res.joinToString(" ") { whenLabel(it.ts) + ": " + it.text + "." }
    return Reply(spoken, head, res)
}

fun recent(mems: List<Memory>, n: Int = 5): Reply {
    val last = mems.takeLast(n).reversed()
    if (last.isEmpty()) return Reply("Ainda não há memórias guardadas.")
    return Reply(
        "Suas últimas memórias. " + last.joinToString(" ") { whenLabel(it.ts) + ": " + it.text + "." },
        "Últimas memórias",
        last
    )
}
