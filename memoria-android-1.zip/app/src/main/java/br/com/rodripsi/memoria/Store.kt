package br.com.rodripsi.memoria

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Guarda as memórias num arquivo privado do app (não sai do aparelho). */
class Store(ctx: Context) {
    private val file = File(ctx.filesDir, "memorias.json")

    fun load(): List<Memory> = try {
        if (!file.exists()) emptyList() else {
            val arr = JSONArray(file.readText())
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                Memory(o.getString("id"), o.getString("text"), o.getLong("ts"))
            }
        }
    } catch (e: Exception) {
        emptyList()
    }

    fun save(list: List<Memory>) {
        try {
            file.writeText(toJson(list))
        } catch (e: Exception) {
            // sem espaço ou erro de disco: ignora nesta versão
        }
    }

    companion object {
        fun toJson(list: List<Memory>): String {
            val arr = JSONArray()
            list.forEach { arr.put(JSONObject().put("id", it.id).put("text", it.text).put("ts", it.ts)) }
            return arr.toString(2)
        }
    }
}
