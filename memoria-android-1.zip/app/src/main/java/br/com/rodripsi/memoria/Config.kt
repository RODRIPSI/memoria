package br.com.rodripsi.memoria

import android.content.Context

/** Configurações guardadas só no aparelho (armazenamento privado do app). */
class Config(ctx: Context) {
    private val sp = ctx.getSharedPreferences("config", Context.MODE_PRIVATE)

    var apiKey: String
        get() = sp.getString("apiKey", "") ?: ""
        set(v) { sp.edit().putString("apiKey", v).apply() }

    var voiceId: String
        get() = sp.getString("voiceId", "") ?: ""
        set(v) { sp.edit().putString("voiceId", v).apply() }

    var model: String
        get() = sp.getString("model", "eleven_flash_v2_5") ?: "eleven_flash_v2_5"
        set(v) { sp.edit().putString("model", v).apply() }

    var useMyVoice: Boolean
        get() = sp.getBoolean("useMyVoice", false)
        set(v) { sp.edit().putBoolean("useMyVoice", v).apply() }
}
