package br.com.rodripsi.memoria

import java.text.Normalizer
import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.TextStyle
import java.time.temporal.ChronoUnit
import java.util.Locale

data class Memory(
    val id: String,
    val text: String,
    val ts: Long,
    val subject: String = "",
    val people: List<String> = emptyList(),
    val type: String = "fato",
    val remindAt: Long? = null,
    val done: Boolean = false
)

class Reply(
    val spoken: String,
    val head: String = spoken,
    val items: List<Memory> = emptyList(),
    val lines: List<String> = emptyList(),
    val sensitive: Boolean = false
)

data class AgendaItem(
    val title: String,
    val start: Long,
    val end: Long,
    val allDay: Boolean,
    val busy: Boolean = true
)

sealed interface Command {
    data class Save(val text: String, val subject: String = "") : Command
    data object AskSave : Command
    data object AskDelete : Command
    data object Help : Command
    data object ListRecent : Command
    data object MyDay : Command
    data class Ask(val text: String) : Command
}

private val PT = Locale("pt", "BR")

private val STOP: Set<String> = """
    a o as os um uma uns umas de do da dos das em no na nos nas por para com sem sobre que qual quais quem
    quando onde como eu me meu minha meus minhas voce vc se foi fui era ser estar tem tinha ter ja e ou mas
    ao aos pra pro isso isto esse essa aquele aquela mais muito fiz fez falei falou disse guardei guardou
    anotei lembra lembro lembrar memoria memorias algo alguma coisa tudo todas todos ultima ultimas ultimo
    recente recentes hoje ontem anteontem semana mes passada passado esta este neste nesta nessa nesse feira
    domingo segunda terca quarta quinta sexta sabado estou estava vez mostra mostre diga fale quero saber
    tenho temos tive havia ha
""".trim().split(Regex("\\s+")).toSet()

private val SAVE_RE = Regex(
    """^\s*(guarda|guardar|guarde|anota|anotar|anote|registra|registrar|registre|salva|salvar|salve|memoriza|memorizar|memorize|lembra que|lembre que|lembre-se que)\b[\s,:.\-]*(?:que\s+|isso[\s,:.\-]*)?([\s\S]*)$""",
    RegexOption.IGNORE_CASE
)

private val SUBJECT_RE = Regex(
    """^(?:em|no|na|sobre)\s+([\p{L}0-9 ]{2,40}?)\s*(?:,|:|\bque\b)\s*([\s\S]+)$""",
    RegexOption.IGNORE_CASE
)

private val MYDAY_RE = Regex(
    "\\b(meu dia|minha agenda|agenda de hoje|agenda hoje|compromissos de hoje|compromissos hoje|o que (eu )?(vou|tenho que) fazer hoje|o que tenho hoje|o que eu tenho hoje)\\b"
)

/** Palavras que sempre tornam um texto sigiloso (não vai à IA nem ao ElevenLabs). */
private val SIGILO_PALAVRAS = listOf(
    "paciente", "pacientes", "atendimento", "atendimentos", "analisando", "analisanda",
    "consultorio", "prontuario", "sessao", "sessoes"
)

fun norm(s: String): String =
    Normalizer.normalize(s, Normalizer.Form.NFD)
        .replace(Regex("\\p{M}+"), "")
        .lowercase(Locale.ROOT)
        .replace(Regex("[^a-z0-9\\s]"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

fun isSigiloso(text: String, subjects: List<String>): Boolean {
    val n = norm(text)
    if (n.isEmpty()) return false
    val words = (SIGILO_PALAVRAS + subjects.map { norm(it) }).filter { it.isNotBlank() }
    return words.any { w -> Regex("\\b" + Regex.escape(w) + "\\b").containsMatchIn(n) }
}

fun isSigilosoMemory(m: Memory, subjects: List<String>): Boolean =
    isSigiloso(m.text + " " + m.subject, subjects)

fun whenLabel(ts: Long): String {
    val zone = ZoneId.systemDefault()
    val dt = Instant.ofEpochMilli(ts).atZone(zone)
    val today = LocalDate.now(zone)
    val diff = ChronoUnit.DAYS.between(dt.toLocalDate(), today)
    val rel = when {
        diff == 0L -> "Hoje"
        diff == 1L -> "Ontem"
        diff == 2L -> "Anteontem"
        diff == -1L -> "Amanhã"
        diff in 3L..6L -> "Na " + dt.dayOfWeek.getDisplayName(TextStyle.FULL, PT)
        else -> "Dia " + dt.dayOfMonth + " de " + dt.month.getDisplayName(TextStyle.FULL, PT)
    }
    return rel + " às " + String.format("%02d:%02d", dt.hour, dt.minute)
}

private fun dayStart(d: LocalDate, zone: ZoneId): Long =
    d.atStartOfDay(zone).toInstant().toEpochMilli()

/** Intervalo [de, até) citado na frase, ou null. */
fun parseRange(n: String): LongRange? {
    val zone = ZoneId.systemDefault()
    val today = LocalDate.now(zone)
    fun r(a: LocalDate, b: LocalDate): LongRange = dayStart(a, zone) until dayStart(b, zone)
    val monday = today.minusDays((today.dayOfWeek.value - 1).toLong())

    if (Regex("\\banteontem\\b").containsMatchIn(n)) return r(today.minusDays(2), today.minusDays(1))
    if (Regex("\\bontem\\b").containsMatchIn(n)) return r(today.minusDays(1), today)
    if (Regex("\\bhoje\\b").containsMatchIn(n)) return r(today, today.plusDays(1))
    if ("semana passada" in n) return r(monday.minusDays(7), monday)
    if (Regex("\\b(esta|essa|nesta|nessa) semana\\b").containsMatchIn(n)) return r(monday, today.plusDays(1))
    if ("mes passado" in n) {
        val first = today.withDayOfMonth(1)
        return r(first.minusMonths(1), first)
    }
    if (Regex("\\b(este|esse|neste|nesse) mes\\b").containsMatchIn(n)) return r(today.withDayOfMonth(1), today.plusDays(1))

    val names = mapOf(
        "domingo" to DayOfWeek.SUNDAY, "segunda" to DayOfWeek.MONDAY, "terca" to DayOfWeek.TUESDAY,
        "quarta" to DayOfWeek.WEDNESDAY, "quinta" to DayOfWeek.THURSDAY, "sexta" to DayOfWeek.FRIDAY,
        "sabado" to DayOfWeek.SATURDAY
    )
    for ((k, dow) in names) {
        if (Regex("\\b$k\\b").containsMatchIn(n)) {
            val back = ((today.dayOfWeek.value - dow.value) + 7) % 7
            val d = today.minusDays(back.toLong())
            return r(d, d.plusDays(1))
        }
    }
    return null
}

fun parseCommand(text: String): Command {
    val n = norm(text)
    val m = SAVE_RE.find(text)
    if (m != null) {
        val rest = m.groupValues[2].trim()
        if (rest.isEmpty()) return Command.AskSave
        val s = SUBJECT_RE.find(rest)
        if (s != null) {
            val subj = s.groupValues[1].trim().replaceFirstChar { it.uppercase() }
            return Command.Save(s.groupValues[2].trim(), subj)
        }
        return Command.Save(rest)
    }
    if (Regex("^(apaga|apague|exclui|exclua|deleta|delete|remove|remova)\\b.*\\b(ultima|ultimo)\\b").containsMatchIn(n))
        return Command.AskDelete
    if (Regex("^(ajuda|socorro|o que voce faz|como funciona)").containsMatchIn(n)) return Command.Help
    if (Regex("^(ler|le|leia|lista|liste)\\b.*\\b(tudo|todas|memorias)\\b").containsMatchIn(n))
        return Command.ListRecent
    if (MYDAY_RE.containsMatchIn(n)) return Command.MyDay
    return Command.Ask(text)
}

private fun searchableWords(m: Memory): List<String> =
    norm(m.text + " " + m.subject + " " + m.people.joinToString(" ")).split(" ")

/** Memórias que combinam com a frase (busca local). */
fun searchList(mems: List<Memory>, text: String, limit: Int = 3): List<Memory> {
    val n = norm(text)
    val range = parseRange(n)
    val subjects = mems.map { it.subject }.filter { it.isNotBlank() }.distinct()
    val sub = subjects.firstOrNull { Regex("\\b" + Regex.escape(norm(it)) + "\\b").containsMatchIn(n) }
    val subWords = if (sub != null) norm(sub).split(" ").toSet() else emptySet()
    val tokens = n.split(" ").filter { it.length > 2 && it !in STOP && it !in subWords }
    val pool = mems.filter {
        (range == null || it.ts in range) && (sub == null || norm(it.subject) == norm(sub))
    }
    if (tokens.isEmpty()) {
        return pool.sortedByDescending { it.ts }.take(if (range != null || sub != null) 5 else limit)
    }
    return pool.map { m ->
        val words = searchableWords(m)
        val score = tokens.count { t ->
            words.any { w -> w == t || (t.length >= 5 && w.length >= 5 && w.take(5) == t.take(5)) }
        }
        Pair(m, score)
    }
        .filter { it.second > 0 }
        .sortedWith(compareByDescending<Pair<Memory, Int>> { it.second }.thenByDescending { it.first.ts })
        .take(limit)
        .map { it.first }
}

fun search(mems: List<Memory>, text: String): Reply {
    if (mems.isEmpty())
        return Reply("Ainda não há memórias guardadas. Diga: guarda que, e depois o que quer lembrar.")
    val n = norm(text)
    val res = searchList(mems, text)
    if (res.isEmpty()) {
        return Reply(
            if (parseRange(n) != null) "Não achei nada guardado nesse período sobre isso."
            else "Não encontrei nada sobre isso nas suas memórias."
        )
    }
    val head = if (res.size == 1) "Encontrei uma memória." else "Encontrei ${res.size} memórias."
    val spoken = head + " " + res.joinToString(" ") { whenLabel(it.ts) + ": " + it.text + "." }
    return Reply(spoken, head, res)
}

fun recent(mems: List<Memory>, n: Int = 5): Reply {
    val last = mems.takeLast(n).reversed()
    if (last.isEmpty()) return Reply("Ainda não há memórias guardadas.")
    return Reply(
        "Suas últimas memórias. " + last.joinToString(" ") { whenLabel(it.ts) + ": " + it.text + "." },
        "Últimas memórias",
        last
    )
}

private fun hourSpoken(ts: Long): String {
    val dt = Instant.ofEpochMilli(ts).atZone(ZoneId.systemDefault())
    return if (dt.minute == 0) "às ${dt.hour} horas" else "às ${dt.hour}:" + String.format("%02d", dt.minute)
}

private fun hourShort(ts: Long): String {
    val dt = Instant.ofEpochMilli(ts).atZone(ZoneId.systemDefault())
    return String.format("%d:%02d", dt.hour, dt.minute)
}

/** Resumo falado do dia: agenda, lembretes, atrasos e promessas pendentes. */
fun buildDay(
    nowMs: Long,
    events: List<AgendaItem>,
    mems: List<Memory>,
    calendarOn: Boolean,
    sigilo: List<String>
): Reply {
    val zone = ZoneId.systemDefault()
    val now = Instant.ofEpochMilli(nowMs).atZone(zone)
    val today = now.toLocalDate()
    val from = dayStart(today, zone)
    val to = dayStart(today.plusDays(1), zone)
    val greet = when {
        now.hour < 12 -> "Bom dia."
        now.hour < 18 -> "Boa tarde."
        else -> "Boa noite."
    }

    val evs = events.filter { it.start < to && it.end > from }.sortedBy { it.start }.take(8)
    val open = mems.filter { !it.done }
    val hoje = open.filter { it.remindAt != null && it.remindAt >= from && it.remindAt < to }
        .sortedBy { it.remindAt }.take(6)
    val atrasados = open.filter { it.remindAt != null && it.remindAt < from }
        .sortedBy { it.remindAt }.take(3)
    val listed = (hoje + atrasados).map { it.id }.toSet()
    val promessas = open.filter { it.type == "promessa" && it.id !in listed }.take(5)

    val parts = ArrayList<String>()
    val lines = ArrayList<String>()
    parts.add(greet)

    if (calendarOn) {
        if (evs.isEmpty()) {
            parts.add("Você não tem compromissos na agenda hoje.")
        } else {
            val n = if (evs.size == 1) "um compromisso" else "${evs.size} compromissos"
            parts.add(
                "Na agenda de hoje, $n: " + evs.joinToString("; ") {
                    (if (it.allDay) "o dia todo" else hourSpoken(it.start)) + ", " + it.title
                } + "."
            )
            evs.forEach { lines.add((if (it.allDay) "Dia todo" else hourShort(it.start)) + " – " + it.title) }
        }
    } else {
        parts.add("A agenda do Google ainda não está ligada.")
    }

    if (hoje.isNotEmpty()) {
        parts.add("Lembretes de hoje: " + hoje.joinToString("; ") { hourSpoken(it.remindAt!!) + ", " + it.text } + ".")
        hoje.forEach { lines.add("Lembrete " + hourShort(it.remindAt!!) + " – " + it.text) }
    }
    if (atrasados.isNotEmpty()) {
        parts.add("Atrasado: " + atrasados.joinToString("; ") { it.text } + ".")
        atrasados.forEach { lines.add("Atrasado – " + it.text) }
    }
    if (promessas.isNotEmpty()) {
        parts.add(
            "Você prometeu: " + promessas.joinToString("; ") {
                (if (it.people.isNotEmpty()) "para " + it.people.joinToString(" e ") + ", " else "") + it.text
            } + "."
        )
        promessas.forEach { lines.add("Promessa – " + it.text) }
    }
    if (calendarOn && evs.isEmpty() && hoje.isEmpty() && atrasados.isEmpty() && promessas.isEmpty()) {
        parts.clear()
        parts.add(greet)
        parts.add("Hoje está livre. Nenhum compromisso, lembrete ou promessa pendente.")
    }

    val sensitive = evs.any { isSigiloso(it.title, sigilo) } ||
        (hoje + atrasados + promessas).any { isSigilosoMemory(it, sigilo) }
    return Reply(parts.joinToString(" "), "$greet Seu dia", emptyList(), lines, sensitive)
}

/** Compromisso com horário que já ocupa o intervalo pedido (dia inteiro e "livre" não contam). */
fun findConflict(events: List<AgendaItem>, startMs: Long, endMs: Long): AgendaItem? =
    events.firstOrNull { !it.allDay && it.busy && it.start < endMs && it.end > startMs }

fun clockLabel(ts: Long): String = hourShort(ts)
