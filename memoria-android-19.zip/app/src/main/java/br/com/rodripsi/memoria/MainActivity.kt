package br.com.rodripsi.memoria

import android.Manifest
import android.content.ClipData
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PersistableBundle
import android.provider.Settings
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private val vm: MemoriaVM by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MemoriaTheme { Screen(vm) } }
        handleIntent(intent)
        addOnNewIntentListener { handleIntent(it) }
    }

    override fun onResume() {
        super.onResume()
        vm.reload()
    }

    private fun handleIntent(i: Intent?) {
        if (i != null && i.action == Intent.ACTION_SEND) {
            val t = i.getStringExtra(Intent.EXTRA_TEXT)
            val mime = i.type ?: ""
            @Suppress("DEPRECATION")
            val stream: Uri? = if (Build.VERSION.SDK_INT >= 33)
                i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java) else i.getParcelableExtra(Intent.EXTRA_STREAM)
            i.action = null
            if (stream != null && (mime.startsWith("image/") || mime.startsWith("video/"))) {
                vm.attachMedia(null, listOf(stream))
            } else if (!t.isNullOrBlank()) {
                if (Spotify.extractUrl(t) != null) vm.attachSong(null, t) else vm.handle(t)
            }
        }
        val id = i?.getStringExtra(Notifier.EXTRA_FOCUS)
        if (id != null) {
            vm.focusReminder(id)
            i?.removeExtra(Notifier.EXTRA_FOCUS)
        }
    }
}

private fun copySensitive(ctx: Context, text: String) {
    val cm = ctx.getSystemService(ClipboardManager::class.java)
    val clip = ClipData.newPlainText("Memória", text)
    if (Build.VERSION.SDK_INT >= 33) {
        clip.description.extras = PersistableBundle().apply {
            putBoolean(ClipDescription.EXTRA_IS_SENSITIVE, true)
        }
    }
    cm.setPrimaryClip(clip)
}

private fun readClipboard(ctx: Context): String? {
    val cm = ctx.getSystemService(ClipboardManager::class.java)
    val clip = cm.primaryClip ?: return null
    if (clip.itemCount == 0) return null
    return clip.getItemAt(0).coerceToText(ctx)?.toString()
}

private fun openExact(ctx: Context) {
    try {
        if (Build.VERSION.SDK_INT >= 31) {
            ctx.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + ctx.packageName)))
        }
    } catch (e: Exception) {
        // tela indisponível neste aparelho
    }
}

private fun openBattery(ctx: Context) {
    try {
        ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
    } catch (e: Exception) {
        // tela indisponível neste aparelho
    }
}

@Composable
fun MemoriaTheme(content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        primary = Color(0xFFE2B857), onPrimary = Color(0xFF0B1630),
        primaryContainer = Color(0xFF3A2F10), onPrimaryContainer = Color(0xFFF3E3B4),
        secondary = Color(0xFF8FA0C4), onSecondary = Color(0xFF0B1630),
        secondaryContainer = Color(0xFF22346A), onSecondaryContainer = Color(0xFFE8EDF7),
        tertiary = Color(0xFFE2B857),
        background = Color(0xFF0B1630), onBackground = Color(0xFFE8EDF7),
        surface = Color(0xFF0F1D40), onSurface = Color(0xFFE8EDF7),
        surfaceVariant = Color(0xFF16285A), onSurfaceVariant = Color(0xFFB4C0DC),
        surfaceTint = Color(0xFFE2B857),
        outline = Color(0xFF2B3F78), outlineVariant = Color(0xFF22346A),
        error = Color(0xFFF08A80)
    )
    MaterialTheme(colorScheme = scheme, content = content)
}

private fun metaLine(m: Memory): String {
    val parts = ArrayList<String>()
    if (m.subject.isNotBlank()) parts.add(m.subject)
    if (m.people.isNotEmpty()) parts.add(m.people.joinToString(", "))
    if (m.type != "fato") parts.add(m.type)
    val r = m.remindAt
    if (r != null) parts.add("lembrete " + whenLabel(r).lowercase())
    if (m.done) parts.add("feito")
    return parts.joinToString(" · ")
}

@Composable
fun Screen(vm: MemoriaVM) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var typed by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf(0) }
    var consulta by remember { mutableStateOf("") }
    var fabMenu by remember { mutableStateOf(false) }
    var escrever by remember { mutableStateOf(false) }
    var editando by remember { mutableStateOf<Memory?>(null) }
    var excluindo by remember { mutableStateOf<Memory?>(null) }
    var novaCat by remember { mutableStateOf(false) }
    var novaCatTxt by remember { mutableStateOf("") }
    var busca1 by remember { mutableStateOf("") }
    var antigasPrimeiro by remember { mutableStateOf(false) }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { vm.exportBackup(it) }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { vm.importBackup(it) }
    var showCals by remember { mutableStateOf(false) }
    var mediaTarget by remember { mutableStateOf<String?>(null) }
    var songTarget by remember { mutableStateOf<String?>(null) }
    var songText by remember { mutableStateOf("") }
    val mediaLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        vm.attachMedia(mediaTarget, uris)
    }
    var keyField by remember { mutableStateOf(vm.apiKey) }
    var idField by remember { mutableStateOf(vm.voiceId) }
    var modelField by remember { mutableStateOf(vm.model) }
    var aiKeyField by remember { mutableStateOf(vm.aiKey) }
    var aiModelField by remember { mutableStateOf(vm.aiModel) }
    var sigField by remember { mutableStateOf(vm.sigilos) }

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) vm.toggleListening() else vm.permissionDenied()
    }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
    val calLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        vm.changeCalendar(res.values.all { it })
    }

    fun onMic() {
        val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (granted) vm.toggleListening() else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    fun send() {
        val t = typed
        typed = ""
        if (t.isNotBlank()) vm.handle(t)
    }

    fun doSave() {
        vm.saveAll(keyField, idField, modelField, aiKeyField, aiModelField, sigField)
    }

    val colors = MaterialTheme.colorScheme
    val micColor = when {
        vm.listening -> colors.secondary
        vm.speaking -> colors.onBackground
        else -> colors.primary
    }
    val subjects = (vm.memories.map { it.subject } + vm.catsExtras)
        .filter { it.isNotBlank() }
        .distinctBy { it.lowercase() }
        .sortedBy { it.lowercase() }
    val termos1 = norm(busca1).split(" ").filter { it.isNotBlank() }
    val shown = vm.memories
        .filter { vm.filter == null || it.subject.equals(vm.filter, ignoreCase = true) }
        .filter { m ->
            if (termos1.isEmpty()) true else {
                val alvo = norm(m.text + " " + m.subject + " " + m.people.joinToString(" "))
                termos1.all { alvo.contains(it) }
            }
        }
        .let { l -> if (antigasPrimeiro) l.sortedBy { it.ts } else l.sortedByDescending { it.ts } }

    if (songTarget != null) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { songTarget = null },
            title = { Text("Música desta memória") },
            text = {
                Column {
                    Text("No Spotify, toque em ⋯ da música › Compartilhar › Copiar link, e cole aqui. Ou compartilhe direto para o Memória (ele liga à memória mais recente).", fontSize = 13.sp)
                    OutlinedTextField(
                        value = songText, onValueChange = { songText = it },
                        placeholder = { Text("https://open.spotify.com/track/…") },
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { vm.attachSong(songTarget, songText); songTarget = null }) { Text("Ligar") }
            },
            dismissButton = {
                TextButton(onClick = { openUrl(ctx, "https://open.spotify.com/search") }) { Text("Abrir Spotify") }
            }
        )
    }

    val abas = listOf(
        Triple("Início", Icons.Default.Home, 0),
        Triple("Memórias", Icons.Default.List, 1),
        Triple("Lembretes", Icons.Default.DateRange, 2),
        Triple("Buscar", Icons.Default.Search, 3)
    )
    if (escrever) DialogEscrever(onFechar = { escrever = false }, onSalvar = { vm.handle(it); escrever = false })
    val ed = editando
    if (ed != null) DialogEditar(ed, onFechar = { editando = null }, onSalvar = { t, a -> vm.editar(ed.id, t, a); editando = null })
    val ex = excluindo
    if (ex != null) DialogExcluir(ex, onFechar = { excluindo = null }, onConfirmar = { vm.delete(ex.id); excluindo = null })
    if (novaCat) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { novaCat = false },
            title = { Text("Nova categoria") },
            text = {
                OutlinedTextField(
                    value = novaCatTxt, onValueChange = { novaCatTxt = it }, singleLine = true,
                    label = { Text("Nome") }, modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(onClick = { vm.addCategoria(novaCatTxt); vm.filter = novaCatTxt.trim().ifEmpty { null }; novaCatTxt = ""; novaCat = false }) { Text("Criar") }
            },
            dismissButton = { TextButton(onClick = { novaCat = false }) { Text("Cancelar") } }
        )
    }
    if (fabMenu) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { fabMenu = false },
            title = { Text("Guardar") },
            text = {
                Column {
                    TextButton(onClick = { fabMenu = false; escrever = true }, modifier = Modifier.fillMaxWidth()) {
                        Text("Escrever", fontSize = 16.sp, modifier = Modifier.fillMaxWidth())
                    }
                    TextButton(onClick = { fabMenu = false; onMic() }, modifier = Modifier.fillMaxWidth()) {
                        Text("Gravar áudio", fontSize = 16.sp, modifier = Modifier.fillMaxWidth())
                    }
                    TextButton(onClick = {
                        fabMenu = false
                        mediaTarget = null
                        mediaLauncher.launch(arrayOf("image/*", "video/*"))
                    }, modifier = Modifier.fillMaxWidth()) {
                        Text("Anexar arquivo", fontSize = 16.sp, modifier = Modifier.fillMaxWidth())
                    }
                }
            },
            confirmButton = { TextButton(onClick = { fabMenu = false }) { Text("Fechar") } }
        )
    }
    Scaffold(
        containerColor = colors.background,
        floatingActionButton = {
            if (tab == 1 || tab == 2) {
                FloatingActionButton(
                    onClick = { fabMenu = true },
                    containerColor = colors.primary, contentColor = colors.onPrimary
                ) { Icon(Icons.Default.Add, contentDescription = "Novo registro") }
            }
        },
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF0A1429), contentColor = colors.onBackground) {
                abas.forEach { (nome, ic, n) ->
                    NavigationBarItem(
                        selected = tab == n,
                        onClick = { tab = n },
                        icon = { Icon(ic, contentDescription = nome) },
                        label = { Text(nome, fontSize = 11.sp, maxLines = 1) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = colors.primary, selectedTextColor = colors.primary,
                            indicatorColor = colors.primary.copy(alpha = 0.18f),
                            unselectedIconColor = Color(0xFF8FA0C4), unselectedTextColor = Color(0xFF8FA0C4)
                        )
                    )
                }
            }
        }
    ) { pad ->
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(pad).background(colors.background),
        contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 10.dp, bottom = 88.dp)
    ) {
        val aviso = vm.notice
        if (aviso != null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = colors.error.copy(alpha = 0.18f)),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Text(aviso, fontSize = 14.sp, color = colors.onBackground)
                        TextButton(onClick = { vm.dismissNotice() }) { Text("Entendi") }
                    }
                }
            }
        }

        if (tab == 0) {
            item {
                Column(Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Memória", fontSize = 28.sp, fontFamily = FontFamily.Serif, color = colors.primary)
                            Text(
                                "Registre, lembre e encontre tudo o que importa.",
                                fontSize = 12.sp, color = colors.onBackground.copy(alpha = 0.7f)
                            )
                        }
                        IconButton(onClick = { tab = 5 }) { Icon(Icons.Default.Settings, contentDescription = "Configurações", tint = colors.onBackground) }
                        Image(
                            painter = painterResource(R.drawable.banner),
                            contentDescription = null,
                            modifier = Modifier.size(width = 64.dp, height = 44.dp).clip(RoundedCornerShape(12.dp)),
                            contentScale = ContentScale.Crop
                        )
                    }
                    OutlinedTextField(
                        value = typed,
                        onValueChange = { typed = it },
                        placeholder = { Text("Fale ou escreva o que deseja guardar…", fontSize = 14.sp) },
                        leadingIcon = {
                            Box(
                                Modifier.size(40.dp).clip(CircleShape)
                                    .background(if (vm.listening) colors.error else colors.primary)
                                    .clickable { onMic() },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    painterResource(R.drawable.ic_mic),
                                    contentDescription = if (vm.listening) "Parar de ouvir" else "Falar",
                                    tint = colors.onPrimary,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        },
                        trailingIcon = {
                            Icon(
                                Icons.AutoMirrored.Filled.Send,
                                contentDescription = "Enviar",
                                tint = colors.primary,
                                modifier = Modifier.clickable { send() }
                            )
                        },
                        shape = RoundedCornerShape(28.dp),
                        singleLine = false,
                        maxLines = 3,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(onSend = { send() }),
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                    )
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            vm.status, fontSize = 12.sp,
                            color = colors.onBackground.copy(alpha = 0.75f), modifier = Modifier.weight(1f)
                        )
                        TextButton(onClick = { vm.myDay() }) { Text("Meu dia", fontSize = 13.sp) }
                    }
                    val vn = vm.voiceNote
                    if (vn != null) Text(vn, color = colors.error, fontSize = 13.sp)
                    if (vm.heard.isNotEmpty()) {
                        Text(vm.heard, color = colors.onBackground.copy(alpha = 0.7f), fontSize = 13.sp)
                    }
                }
            }
            item { ResumoInicio(vm, onLembretes = { tab = 2 }, onMemorias = { tab = 1 }) }
        }

        val head = vm.answerHead
        if (head != null && (tab == 0 || tab == 3)) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = colors.surface),
                    modifier = Modifier.fillMaxWidth().padding(top = 18.dp)
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text(head, color = colors.onSurface, fontSize = 17.sp)
                        vm.answerLines.forEach { line ->
                            Text(line, color = colors.onSurface, fontSize = 16.sp, modifier = Modifier.padding(top = 8.dp))
                        }
                        if (vm.importing) {
                            Row(Modifier.padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { vm.confirmImport() }) { Text("Lançar na agenda") }
                                OutlinedButton(onClick = { vm.cancelImport() }) { Text("Cancelar") }
                            }
                        }
                        vm.answerItems.forEach { m ->
                            Text(
                                whenLabel(m.ts),
                                color = colors.primary, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(top = 12.dp)
                            )
                            val meta = metaLine(m)
                            if (meta.isNotEmpty()) Text(meta, color = colors.primary, fontSize = 13.sp)
                            Text(m.text, color = colors.onSurface, fontSize = 17.sp)
                        }
                    }
                }
            }
        }

        if (tab == 0) {
            item { ListaInicio(vm, onVerTodos = { tab = 2 }, onEditar = { editando = it }, onExcluir = { excluindo = it }) }
            item { RecentesInicio(vm, onVerTodas = { tab = 1 }) }
        }
        if (tab == 2) item { LembretesPainel(vm, onEditar = { editando = it }, onExcluir = { excluindo = it }) }

        if (tab == 5) item { AppsConectados(vm) }

        if (tab == 5) item {
            Column {
                Text("Ajustes", fontSize = 22.sp, fontWeight = FontWeight.SemiBold, color = colors.onBackground)
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = vm.loop, onCheckedChange = { vm.loop = it })
                    Text("Continuar ouvindo depois de responder", color = colors.onBackground)
                }
                Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = vm.useAi, onCheckedChange = { vm.changeAi(it) })
                    Text("  Usar IA para organizar", color = colors.onBackground)
                }
                Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = vm.useMyVoice, onCheckedChange = { vm.changeMyVoice(it) })
                    Text("  Usar minha voz (ElevenLabs)", color = colors.onBackground)
                }
                Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Switch(
                        checked = vm.useCalendar,
                        onCheckedChange = { on ->
                            if (!on) vm.changeCalendar(false)
                            else if (Agenda.hasPermission(ctx)) vm.changeCalendar(true)
                            else calLauncher.launch(
                                arrayOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR)
                            )
                        }
                    )
                    Text("  Ligar com o Google Agenda", color = colors.onBackground)
                }
                Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Switch(
                        checked = vm.useCentral,
                        onCheckedChange = { on ->
                            if (!on || Agenda.hasPermission(ctx)) vm.changeCentral(on)
                            else calLauncher.launch(
                                arrayOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR)
                            )
                        }
                    )
                    Text("  Enviar lembretes para a Central (agenda Lembretes)", color = colors.onBackground)
                }
                if (vm.useCentral && Agenda.hasPermission(ctx) && !Agenda.hasLembreteCalendar(ctx)) {
                    Text(
                        "Falta criar uma agenda chamada Lembretes no Google Agenda. Quando ela existir, os lembretes vão para a Central.",
                        fontSize = 13.sp, color = colors.error, modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        }

        if (tab == 1) item {
            Column(Modifier.fillMaxWidth()) {
                Text(
                    "Memórias" + if (vm.memories.isNotEmpty()) " (${vm.memories.size})" else "",
                    fontSize = 20.sp, fontWeight = FontWeight.Medium, color = colors.onBackground
                )
                OutlinedTextField(
                    value = busca1, onValueChange = { busca1 = it },
                    placeholder = { Text("Buscar nas memórias", fontSize = 14.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    shape = RoundedCornerShape(24.dp), singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                )
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Chip("Todas", vm.filter == null) { vm.filter = null }
                    subjects.forEach { sj -> Chip(sj, vm.filter.equals(sj, ignoreCase = true)) { vm.filter = sj } }
                    Chip("+ Categoria", false) { novaCat = true }
                }
                Text(
                    if (antigasPrimeiro) "Mais antigas primeiro" else "Mais recentes primeiro",
                    fontSize = 12.sp, color = colors.primary,
                    modifier = Modifier.clickable { antigasPrimeiro = !antigasPrimeiro }.padding(bottom = 8.dp)
                )
                if (vm.memories.isEmpty()) {
                    Column(Modifier.fillMaxWidth().padding(vertical = 40.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Nada guardado ainda", fontSize = 16.sp, color = colors.onBackground)
                        Text(
                            "Fale ou escreva o que quiser lembrar.",
                            fontSize = 13.sp, color = colors.onBackground.copy(alpha = 0.7f),
                            modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                        )
                        Button(onClick = { escrever = true }) { Text("Guardar primeira memória") }
                    }
                } else if (shown.isEmpty()) {
                    Text("Nenhuma memória nesse filtro.", fontSize = 13.sp, color = colors.onBackground.copy(alpha = 0.7f))
                }
            }
        }

        if (tab == 1) items(shown, key = { it.id }) { m ->
            var menu by remember { mutableStateOf(false) }
            Card(
                colors = CardDefaults.cardColors(containerColor = colors.surface),
                modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp)
            ) {
                Row(Modifier.fillMaxWidth().padding(start = 12.dp, top = 8.dp, bottom = 6.dp), verticalAlignment = Alignment.Top) {
                    Column(Modifier.weight(1f)) {
                        val meta = metaLine(m)
                        Text(
                            whenLabel(m.ts) + if (meta.isNotEmpty()) "  ·  " + meta else "",
                            fontSize = 12.sp, color = colors.primary, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                        )
                        Text(
                            m.text, fontSize = 15.sp, color = colors.onSurface, maxLines = 4,
                            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                        if (m.media.isNotEmpty() || m.song != null) {
                            Row(
                                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(top = 6.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                m.media.forEachIndexed { idx, r ->
                                    val bmp = remember(r.thumb) { Thumbs.load(ctx, r.thumb) }
                                    Box(
                                        Modifier.size(64.dp).clip(RoundedCornerShape(10.dp))
                                            .background(colors.background)
                                            .clickable { openMedia(ctx, r) }
                                    ) {
                                        if (bmp != null) Image(
                                            bitmap = bmp.asImageBitmap(),
                                            contentDescription = if (r.kind == "video") "Vídeo" else "Foto",
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                        if (r.kind == "video") Text("▶", color = Color.White, fontSize = 20.sp,
                                            modifier = Modifier.align(Alignment.Center))
                                        Text("✕", color = Color.White, fontSize = 12.sp,
                                            modifier = Modifier.align(Alignment.TopEnd).clickable { vm.removeMedia(m.id, idx) }
                                                .background(Color(0x99000000)).padding(horizontal = 5.dp, vertical = 1.dp))
                                    }
                                }
                                val sg = m.song
                                if (sg != null) {
                                    Row(
                                        Modifier.height(64.dp).clip(RoundedCornerShape(10.dp)).background(colors.background)
                                            .clickable { openUrl(ctx, sg.url) }.padding(horizontal = 10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("♪ " + sg.title, color = colors.primary, fontSize = 13.sp, maxLines = 2,
                                            modifier = Modifier.widthIn(max = 160.dp))
                                        Text("  ✕", color = colors.onBackground.copy(alpha = 0.6f),
                                            modifier = Modifier.clickable { vm.removeSong(m.id) })
                                    }
                                }
                            }
                        }
                    }
                    Box {
                        IconButton(onClick = { menu = true }) {
                            Icon(Icons.Default.MoreVert, contentDescription = "Mais opções", tint = colors.onSurface.copy(alpha = 0.7f))
                        }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DropdownMenuItem(text = { Text("Editar") }, onClick = { menu = false; editando = m })
                            if ((m.type == "tarefa" || m.type == "promessa" || m.type == "aguardando") && !m.done) {
                                DropdownMenuItem(text = { Text("Concluir") }, onClick = { menu = false; vm.markDone(m.id) })
                            }
                            DropdownMenuItem(text = { Text("Anexar foto ou vídeo") }, onClick = {
                                menu = false
                                mediaTarget = m.id
                                mediaLauncher.launch(arrayOf("image/*", "video/*"))
                            })
                            DropdownMenuItem(text = { Text("Ligar música") }, onClick = {
                                menu = false
                                songTarget = m.id
                                songText = readClipboard(ctx)?.takeIf { Spotify.extractUrl(it) != null } ?: ""
                            })
                            DropdownMenuItem(text = { Text("Excluir", color = colors.error) }, onClick = { menu = false; excluindo = m })
                        }
                    }
                }
            }
        }

        if (tab == 3) {
            item {
                Column(Modifier.fillMaxWidth()) {
                    Text("Buscar", fontSize = 22.sp, fontWeight = FontWeight.SemiBold, color = colors.onBackground)
                    OutlinedTextField(
                        value = consulta, onValueChange = { consulta = it },
                        placeholder = { Text("Pergunte ou procure uma memória") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        shape = RoundedCornerShape(28.dp), singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { if (consulta.isNotBlank()) vm.handle(consulta) }),
                        modifier = Modifier.fillMaxWidth().padding(top = 10.dp)
                    )
                    OutlinedButton(
                        onClick = { if (consulta.isNotBlank()) vm.handle(consulta) },
                        modifier = Modifier.padding(top = 8.dp)
                    ) { Text("Perguntar") }
                }
            }
            val termos = norm(consulta).split(" ").filter { it.isNotBlank() }
            val achados = if (termos.isEmpty()) emptyList() else vm.memories.filter { m ->
                val alvo = norm(m.text + " " + m.subject + " " + m.people.joinToString(" "))
                termos.all { alvo.contains(it) }
            }.sortedByDescending { it.ts }.take(40)
            if (termos.isNotEmpty() && achados.isEmpty()) {
                item { Text("Nada encontrado com essas palavras.", color = colors.onBackground.copy(alpha = 0.7f), modifier = Modifier.padding(top = 14.dp)) }
            }
            items(achados, key = { it.id }) { m ->
                Column(Modifier.fillMaxWidth().padding(top = 12.dp)) {
                    Text(whenLabel(m.ts) + if (m.subject.isNotBlank()) "  ·  " + m.subject else "", fontSize = 13.sp, color = colors.primary)
                    Text(m.text, fontSize = 16.sp, color = colors.onBackground)
                }
            }
        }

        if (tab == 5) item {
            Column {
                if (true) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = colors.surface),
                        modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Text("Minha voz (ElevenLabs)", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = colors.onSurface)
                            Text(
                                "O texto de cada resposta é enviado ao ElevenLabs para virar áudio.",
                                fontSize = 13.sp, color = colors.onSurface.copy(alpha = 0.7f),
                                modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                            )
                            OutlinedTextField(
                                value = keyField, onValueChange = { keyField = it },
                                label = { Text("Chave da API (ElevenLabs)") }, singleLine = true,
                                visualTransformation = PasswordVisualTransformation(),
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(Modifier.height(8.dp))
                            OutlinedTextField(
                                value = idField, onValueChange = { idField = it },
                                label = { Text("ID da voz") }, singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                if (modelField == "eleven_flash_v2_5") {
                                    Button(onClick = { }) { Text("Rápido") }
                                } else {
                                    OutlinedButton(onClick = { modelField = "eleven_flash_v2_5" }) { Text("Rápido") }
                                }
                                if (modelField == "eleven_multilingual_v2") {
                                    Button(onClick = { }) { Text("Mais natural") }
                                } else {
                                    OutlinedButton(onClick = { modelField = "eleven_multilingual_v2" }) { Text("Mais natural") }
                                }
                            }

                            Text(
                                "IA (OpenAI)", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = colors.onSurface,
                                modifier = Modifier.padding(top = 24.dp)
                            )
                            Text(
                                "O que você diz (fora dos assuntos sigilosos) é enviado à OpenAI para organizar memórias e agenda.",
                                fontSize = 13.sp, color = colors.onSurface.copy(alpha = 0.7f),
                                modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                            )
                            OutlinedTextField(
                                value = aiKeyField, onValueChange = { aiKeyField = it },
                                label = { Text("Chave da API (OpenAI)") }, singleLine = true,
                                visualTransformation = PasswordVisualTransformation(),
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(Modifier.height(8.dp))
                            OutlinedTextField(
                                value = aiModelField, onValueChange = { aiModelField = it },
                                label = { Text("Modelo da IA") }, singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )

                            Text(
                                "Agenda", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = colors.onSurface,
                                modifier = Modifier.padding(top = 24.dp)
                            )
                            Text(
                                "Escolha em qual agenda os compromissos novos são criados.",
                                fontSize = 13.sp, color = colors.onSurface.copy(alpha = 0.7f),
                                modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                            )
                            OutlinedButton(onClick = { vm.loadCalendars(); showCals = !showCals }) {
                                Text(if (showCals) "Fechar lista" else "Escolher agenda")
                            }
                            if (showCals) {
                                if (vm.calendarOptions.isEmpty()) {
                                    Text(
                                        "Nenhuma agenda com escrita encontrada. Ligue o Google Agenda primeiro.",
                                        fontSize = 13.sp, color = colors.error, modifier = Modifier.padding(top = 8.dp)
                                    )
                                }
                                vm.calendarOptions.forEach { o ->
                                    if (o.id == vm.calendarId) {
                                        Button(onClick = { }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp)) { Text(o.label) }
                                    } else {
                                        OutlinedButton(
                                            onClick = { vm.pickCalendar(o.id) },
                                            modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
                                        ) { Text(o.label) }
                                    }
                                }
                            }

                            Text(
                                "Lembretes", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = colors.onSurface,
                                modifier = Modifier.padding(top = 24.dp)
                            )
                            Text(
                                "Para o aviso tocar na hora certa, permita alarmes exatos e libere o Memória da economia de bateria.",
                                fontSize = 13.sp, color = colors.onSurface.copy(alpha = 0.7f),
                                modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { openExact(ctx) }) { Text("Alarmes exatos") }
                                OutlinedButton(onClick = { openBattery(ctx) }) { Text("Bateria") }
                            }

                            Text(
                                "Sigilo", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = colors.onSurface,
                                modifier = Modifier.padding(top = 24.dp)
                            )
                            Text(
                                "Assuntos que nunca vão à IA, ao ElevenLabs nem à agenda. Separe por vírgula. Palavras como paciente e atendimento já valem sempre.",
                                fontSize = 13.sp, color = colors.onSurface.copy(alpha = 0.7f),
                                modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                            )
                            OutlinedTextField(
                                value = sigField, onValueChange = { sigField = it },
                                label = { Text("Assuntos sigilosos") }, singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )

                            Text(
                                "Backup das configurações", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = colors.onSurface,
                                modifier = Modifier.padding(top = 24.dp)
                            )
                            Text(
                                "Copia as suas chaves e ajustes num texto, para colar de volta depois de reinstalar o app. Guarde esse texto num lugar seguro e não o envie a ninguém.",
                                fontSize = 13.sp, color = colors.onSurface.copy(alpha = 0.7f),
                                modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = {
                                    copySensitive(ctx, vm.exportSettings())
                                    vm.note("Configurações copiadas. Guarde num lugar seguro.")
                                }) { Text("Copiar configurações") }
                                OutlinedButton(onClick = {
                                    val t = readClipboard(ctx)
                                    if (t != null && vm.importSettings(t)) {
                                        keyField = vm.apiKey
                                        idField = vm.voiceId
                                        modelField = vm.model
                                        aiKeyField = vm.aiKey
                                        aiModelField = vm.aiModel
                                        sigField = vm.sigilos
                                    } else {
                                        vm.note("Não achei configurações válidas na área de transferência.")
                                    }
                                }) { Text("Colar configurações") }
                            }

                            Row(Modifier.padding(top = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { doSave() }) { Text("Salvar") }
                                OutlinedButton(onClick = { doSave(); vm.testVoice() }) { Text("Testar voz") }
                                OutlinedButton(onClick = { vm.testAgenda() }) { Text("Testar agenda") }
                            }
                            var cacheTxt by remember { mutableStateOf(vm.cacheInfo()) }
                            Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(cacheTxt, fontSize = 12.sp, color = colors.onSurface.copy(alpha = 0.7f), modifier = Modifier.weight(1f))
                                TextButton(onClick = { vm.clearCache(); cacheTxt = vm.cacheInfo() }) { Text("Limpar áudios guardados", fontSize = 12.sp) }
                            }
                        }
                    }
                }
                Row(Modifier.padding(top = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        copySensitive(ctx, vm.backupJson())
                        vm.note("Backup das memórias copiado. Guarde num lugar seguro.")
                    }) { Text("Copiar backup") }
                    OutlinedButton(onClick = {
                        val t = readClipboard(ctx)
                        val n = if (t == null) -1 else vm.restoreBackup(t)
                        vm.note(if (n >= 0) "Memórias restauradas: " + n + "." else "Não achei um backup válido na área de transferência.")
                    }) { Text("Restaurar backup") }
                }
                Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        exportLauncher.launch("memoria-backup-" + java.time.LocalDate.now().toString() + ".json")
                    }) { Text("Salvar backup em arquivo") }
                    OutlinedButton(onClick = { importLauncher.launch(arrayOf("*/*")) }) { Text("Restaurar de arquivo") }
                }
                Text(
                    "Em “Salvar backup em arquivo”, escolha o Google Drive como destino. O app também guarda sozinho uma cópia por dia, no aparelho.",
                    fontSize = 12.sp, color = colors.onBackground.copy(alpha = 0.7f), modifier = Modifier.padding(top = 6.dp)
                )
                Text(
                    "As memórias ficam só neste aparelho. Comandos: “guarda que…”, “o que guardei ontem?”, “meu dia”, “apaga a última”, “ajuda”.",
                    fontSize = 13.sp, color = colors.onBackground.copy(alpha = 0.7f),
                    modifier = Modifier.padding(top = 20.dp)
                )
            }
        }
    }
    }
}

private fun openUrl(ctx: Context, url: String) {
    try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        Toast.makeText(ctx, "Não consegui abrir o link.", Toast.LENGTH_SHORT).show()
    }
}

private fun openMedia(ctx: Context, r: MediaRef) {
    try {
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(Uri.parse(r.uri), if (r.kind == "video") "video/*" else "image/*")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    } catch (e: Exception) {
        Toast.makeText(ctx, "O original não está mais na galeria.", Toast.LENGTH_SHORT).show()
    }
}
