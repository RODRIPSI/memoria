package br.com.rodripsi.memoria

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private val vm: MemoriaVM by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MemoriaTheme { Screen(vm) } }
    }
}

@Composable
fun MemoriaTheme(content: @Composable () -> Unit) {
    val scheme = if (isSystemInDarkTheme()) {
        darkColorScheme(
            primary = Color(0xFF9AA0FF), onPrimary = Color(0xFF12151F),
            secondary = Color(0xFF4FD1C5), onSecondary = Color(0xFF12151F),
            background = Color(0xFF12151F), onBackground = Color(0xFFE8EAF2),
            surface = Color(0xFF1B2030), onSurface = Color(0xFFE8EAF2),
            error = Color(0xFFF2B8B5)
        )
    } else {
        lightColorScheme(
            primary = Color(0xFF3E44A8), onPrimary = Color.White,
            secondary = Color(0xFF0E7C86), onSecondary = Color.White,
            background = Color(0xFFEEF0F5), onBackground = Color(0xFF1C2237),
            surface = Color.White, onSurface = Color(0xFF1C2237),
            error = Color(0xFFB3261E)
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun Screen(vm: MemoriaVM) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var typed by remember { mutableStateOf("") }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) vm.toggleListening() else vm.permissionDenied()
    }

    fun onMic() {
        val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (granted) vm.toggleListening() else launcher.launch(Manifest.permission.RECORD_AUDIO)
    }

    fun send() {
        val t = typed
        typed = ""
        if (t.isNotBlank()) vm.handle(t)
    }

    val colors = MaterialTheme.colorScheme
    val micColor = when {
        vm.listening -> colors.secondary
        vm.speaking -> colors.onBackground
        else -> colors.primary
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(colors.background),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 28.dp)
    ) {
        item {
            Column {
                Text("Memória", fontSize = 32.sp, fontWeight = FontWeight.SemiBold, color = colors.onBackground)
                Text(
                    "Fale e eu guardo. Pergunte e eu respondo em voz alta.",
                    color = colors.onBackground.copy(alpha = 0.7f),
                    modifier = Modifier.padding(top = 4.dp, bottom = 28.dp)
                )
            }
        }

        item {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    modifier = Modifier
                        .size(148.dp)
                        .clip(CircleShape)
                        .background(micColor)
                        .semantics { contentDescription = if (vm.listening) "Parar de ouvir" else "Falar" }
                        .clickable { onMic() },
                    contentAlignment = Alignment.Center
                ) {
                    Text("🎤", fontSize = 56.sp)
                }
                Spacer(Modifier.height(16.dp))
                Text(vm.status, fontWeight = FontWeight.Bold, color = colors.onBackground, textAlign = TextAlign.Center)
                if (vm.heard.isNotEmpty()) {
                    Text(
                        vm.heard,
                        color = colors.onBackground.copy(alpha = 0.7f),
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }
            }
        }

        val head = vm.answerHead
        if (head != null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = colors.surface),
                    modifier = Modifier.fillMaxWidth().padding(top = 18.dp)
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text(head, color = colors.onSurface, fontSize = 17.sp)
                        vm.answerItems.forEach { m ->
                            Text(
                                whenLabel(m.ts),
                                color = colors.primary, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(top = 12.dp)
                            )
                            Text(m.text, color = colors.onSurface, fontSize = 17.sp)
                        }
                    }
                }
            }
        }

        item {
          Column {
            Row(
                Modifier.fillMaxWidth().padding(top = 22.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = typed,
                    onValueChange = { typed = it },
                    placeholder = { Text("Ou escreva aqui") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { send() }),
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(8.dp))
                Button(onClick = { send() }) { Text("Enviar") }
            }
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(top = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(onClick = { vm.handle("Guarda que comprei pão e leite na padaria") }) { Text("Guarda que comprei pão…") }
                OutlinedButton(onClick = { vm.handle("O que eu guardei hoje?") }) { Text("O que guardei hoje?") }
                OutlinedButton(onClick = { vm.handle("Quando eu comprei pão?") }) { Text("Quando comprei pão?") }
            }
            Row(
                Modifier.fillMaxWidth().padding(top = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Checkbox(checked = vm.loop, onCheckedChange = { vm.loop = it })
                Text("Continuar ouvindo depois de responder", color = colors.onBackground)
            }
          }
        }

        item {
          Column {
            Text(
                "Memórias guardadas" + if (vm.memories.isNotEmpty()) " (${vm.memories.size})" else "",
                fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = colors.onBackground,
                modifier = Modifier.padding(top = 32.dp, bottom = 8.dp)
            )
            if (vm.memories.isEmpty()) {
                Text(
                    "Nenhuma memória ainda. Toque no microfone e diga: “guarda que…”.",
                    color = colors.onBackground.copy(alpha = 0.7f)
                )
            }
          }
        }

        items(vm.memories.reversed(), key = { it.id }) { m ->
          Column {
            HorizontalDivider(color = colors.onBackground.copy(alpha = 0.12f))
            Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.Top) {
                Column(Modifier.weight(1f)) {
                    Text(whenLabel(m.ts), fontSize = 13.sp, color = colors.onBackground.copy(alpha = 0.7f))
                    Text(m.text, fontSize = 17.sp, color = colors.onBackground)
                }
                TextButton(onClick = { vm.delete(m.id) }) { Text("Apagar", color = colors.error) }
            }
          }
        }

        item {
          Column {
            OutlinedButton(
                onClick = {
                    clipboard.setText(AnnotatedString(vm.backupJson()))
                    vm.note("Backup copiado. Cole num lugar seguro.")
                },
                modifier = Modifier.padding(top = 16.dp)
            ) { Text("Copiar backup") }
            Text(
                "As memórias ficam só neste aparelho. Comandos: “guarda que…”, “o que guardei ontem?”, “apaga a última”, “ajuda”.",
                fontSize = 13.sp, color = colors.onBackground.copy(alpha = 0.7f),
                modifier = Modifier.padding(top = 20.dp)
            )
          }
        }
    }
}
